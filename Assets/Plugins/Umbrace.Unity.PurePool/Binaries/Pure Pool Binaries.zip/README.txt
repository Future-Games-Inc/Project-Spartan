Conditional compilation can be used to conditionally include or exclude portions of a source file. In the case of Pure Pool, it can enable or disable specific features. You may wish to disable features that you don't use, especially for your final release builds, to ensure maximum performance.

Pure Pool is distributed with several binaries, which have each been built with different conditional compilation symbols defined, to help you choose the most appropriate features. The table below shows which symbols were defined for each build.

* Debug Configuration
	CONTRACTS_FULL; POOL_STATISTICS; LOG_MESSAGING

	The Debug configuration defines CONTRACTS_FULL to include full contract pre-condition checking. It also defines POOL_STATISTICS to record general operational statistics about the pools at runtime. It defines LOG_MESSAGING to include log messaging in the built assemblies.

	This configuration is most suited to testing your game outside of the Unity Editor, in one of the available players.

* Release Configuration
	POOL_STATISTICS

	The Release configuration defines POOL_STATISTICS to record general operational statistics about the pools at runtime.

	This configuration is most suited to releasing your game, and building for one of the available players.