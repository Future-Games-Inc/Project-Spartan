﻿using Umbrace.Unity.PurePool.ForEditor;

using UnityEditor;

namespace Umbrace.Unity.PurePool.Editor {

	[InitializeOnLoad]
	internal static class EditorOnLoad {

		static EditorOnLoad() {
			EditorApplication.playmodeStateChanged += EditorOnLoad.PlayModeChanged;
		}

		private static void PlayModeChanged() {
			// Check if we're leaving play mode in the editor. This allows the non-Editor library to check if object destruction was occurring due to exiting play mode.
			if (!EditorApplication.isPlayingOrWillChangePlaymode && EditorApplication.isPlaying) {
				EditorState.IsEditorApplicationExitingPlayMode = true;
			}
		}

	}

}