﻿using System;

using UnityEditor;

namespace Umbrace.Unity.PurePool.Editor {

	public class HierarchyModeGroup : IDisposable {

		private readonly bool previousHierarchyMode;

		public HierarchyModeGroup(bool newHierarchyMode) {
			this.previousHierarchyMode = EditorGUIUtility.hierarchyMode;
			EditorGUIUtility.hierarchyMode = newHierarchyMode;
		}

		public void Dispose() {
			EditorGUIUtility.hierarchyMode = this.previousHierarchyMode;
		}
	}

}