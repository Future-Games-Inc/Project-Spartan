﻿using System.Collections.Generic;
using System.Linq;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class PoolSearch {

		public IList<TPool> Search<TPool>(IList<TPool> pools, string regexPattern) where TPool : Component {
			return pools.TextSearch(pool => pool.transform.GetPath(), regexPattern).ToList();
		}

	}

}