﻿using System;
using System.Collections.Generic;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEditor;
using UnityEngine;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal abstract class Helper<TManager, TManagerSettings, TManagerEditorSettings, TPool, TPoolSettings, TSource, TInstance>
		where TManagerSettings : PoolManagerSettings<TPoolSettings, TSource>
		where TManagerEditorSettings : ManagerEditorSettings<TPool, TSource, TInstance, TPoolSettings>
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TPool : PoolBase<TSource, TInstance, TPoolSettings>
		where TManager : PoolManagerBase<TManagerSettings, TPool, TPoolSettings, TSource, TInstance>
		where TSource : class {

		[SerializeField, HideInInspector]
		private TManager manager;

		private TManagerEditorSettings settings;
		
		protected Helper(TManager manager) {
			Contract.RequiresNotNull(manager, nameof(manager));

			this.manager = manager;
		}

		public bool ChangeSourceObject(TPool pool, TSource sourceObject) {
			Contract.Requires(pool != null);

			// Only need to change the source object if it's different.
			if (sourceObject == pool.Source) return true;

			// Disallow changing of the source object after the pool has been initialised.
			if (pool.IsInitialised) {
				Debug.LogWarning("The source object cannot be changed once the pool has been initialised.");
				return false;
			}

			// Ensure no other pool is using the same source object.
			if (sourceObject != null && this.IsSourceInUse(sourceObject)) {
				Debug.LogWarning($"The source object could not be changed, as the source object ('{this.GetSourceName(sourceObject)}') is already assigned to another pool.");
				return false;
			}

			// Change the source object, and update the name of the container that the pool resides on.
			Undo.RecordObjects(new Object[] { pool, pool.gameObject }, "Set Pool Source Object");
			pool.Source = sourceObject;
			pool.gameObject.name = this.GenerateContainerName(sourceObject);

			return true;
		}
		
		public bool IsSourceInUse(TSource source) {
			Contract.RequiresNotNull(source, nameof(source));

			// In play mode, check with the manager if it already has a pool handling the source.
			if (EditorApplication.isPlaying) {
				return this.manager.HasPool(source);
			}

			// In edit mode, look at the children of the manager.
			return this.manager.FindChildPools().Any(p => p.Source == source);
		}

		/// <summary>
		/// Generates a container name for the specified source object.
		/// </summary>
		/// <param name="sourceObject">The pooled object that is assigned to the pool on the container.</param>
		/// <returns>The generated name of the container, based on the pooled object.</returns>
		public string GenerateContainerName(TSource sourceObject) {
			if (sourceObject == null) {
				return "Empty Pool";
			}

			string sourceName = this.GetSourceName(sourceObject);
			if (!string.IsNullOrEmpty(sourceName)) {
				return sourceName + " Pool";
			}

			return sourceObject.GetType().Name + " Pool";
		}

		/// <summary>
		/// Gets the manager's editor settings component.
		/// </summary>
		/// <returns>The manager's editor settings component, <typeparamref name="TManagerEditorSettings"/>.</returns>
		public TManagerEditorSettings GetSettingsComponent() {
			if (this.settings != null) return this.settings;

			this.settings = GetHiddenComponent<TManagerEditorSettings>(this.manager.gameObject, $"{typeof(TManager).Name} Settings (Editor Only)");

			return this.settings;
		}

		public static T GetHiddenComponent<T>(GameObject parent, string gameObjectName = null) where T : MonoBehaviour {
			var component = parent.GetComponentInChildren<T>(true);

			if (component == null) {
				// Create a GameObject that will hold the component. This object will not exist in builds due to the EditorOnly tag.
				var go = new GameObject(gameObjectName ?? $"{typeof(T).Name} (Editor Only)");
				go.SetActive(false);
				go.transform.SetParent(parent.transform, false);
				go.transform.SetAsFirstSibling();
				go.tag = "EditorOnly";
				go.hideFlags = HideFlags.HideAndDontSave;
				component = go.AddComponent<T>();
			}

			return component;
		}

		public static T GetHiddenComponent<T>(string gameObjectName = null) where T : MonoBehaviour {
			var component = Resources.FindObjectsOfTypeAll<T>().FirstOrDefault();
			
			if (component == null) {
				// Create a GameObject that will hold the component. This object will not exist in builds due to the EditorOnly tag.
				var go = new GameObject(gameObjectName ?? $"{typeof(T).Name} (Editor Only)");
				go.SetActive(false);
				go.transform.SetAsFirstSibling();
				go.tag = "EditorOnly";
				go.hideFlags = HideFlags.HideAndDontSave;
				component = go.AddComponent<T>();
			}
			
			return component;
		}

		public PoolDisplaySettings GetPoolSettings(TPool pool) {
			Contract.RequiresNotNull(pool, nameof(pool));

			return this.GetSettingsComponent().GetDisplaySettings(pool);
		}

		public ContainerSettings GetContainerSettings(GameObject container) {
			Contract.RequiresNotNull(container, nameof(container));

			return this.GetSettingsComponent().GetDisplaySettings(container);
		}

		public ContainerSettings GetContainerSettings(Transform container) {
			Contract.RequiresNotNull(container, nameof(container));

			return this.GetContainerSettings(container.gameObject);
		}

		public void SetFoldoutStateRecursive(GameObject container, bool foldoutState) {
			while (container != null && container != this.manager.gameObject) {
				this.GetContainerSettings(container).FoldoutOpen.TargetValue = foldoutState;

				container = container.transform.parent.gameObject;
			}
		}

		public void SetFoldoutStateRecursiveDownwards(GameObject container, bool foldoutState) {
			Contract.RequiresNotNull(container, nameof(container));

			this.GetContainerSettings(container).FoldoutOpen.TargetValue = foldoutState;

			foreach (Transform childTransform in container.transform) {
				this.SetFoldoutStateRecursiveDownwards(childTransform.gameObject, foldoutState);
			}
		}

		/// <summary>
		/// Creates a new container beneath the specified parent object.
		/// </summary>
		/// <param name="parent">The <see cref="Transform"/> of the object that the new container should be parented to.</param>
		/// <param name="name">The name of the container. The default value is "Unnamed".</param>
		public void CreateContainer(Transform parent, string name = "Unnamed") {
			Contract.RequiresNotNull(name, nameof(name));

			var container = new GameObject(name);
			container.transform.parent = parent;

			// TODO: Fix the renaming/editing. Currently unable to start editing with focus in the text field.
			//EditorGUIUtility.editingTextField = true;
			//EditorGUI.FocusTextInControl("ContainerName" + container.transform.GetHashCode());
			//this.containerNameBeingEdited = container.transform;
			this.SetFoldoutStateRecursive(container, true);
		}

		/// <summary>
		/// Deletes the specified container game objects.
		/// </summary>
		/// <param name="containers"></param>
		/// <remarks>This method is delayed until the next <see cref="EventType.Layout"/> pass.</remarks>
		public void DeleteContainers(params GameObject[] containers) {
			Contract.RequiresNotNull(containers, nameof(containers));

			Undo.IncrementCurrentGroup();
			Undo.SetCurrentGroupName("Delete Pool Container(s)");
			int group = Undo.GetCurrentGroup();

			foreach (GameObject container in containers) {
				if (EditorApplication.isPlaying) {
					Object.Destroy(container);
				} else {
					Undo.DestroyObjectImmediate(container);
				}
			}

			Undo.CollapseUndoOperations(group);
		}

		/// <summary>
		/// Gets the child containers of the specified parent transform.
		/// </summary>
		/// <param name="parent">The parent whose child containers should be retrieved.</param>
		/// <param name="sortAlphabetically">A value indicating whether to sort the containers alphabetically by name.</param>
		/// <returns>A list of <see cref="Transform"/> components belonging to the child containers of the specified parent.</returns>
		public IList<Transform> GetContainers(Transform parent, bool sortAlphabetically) {
			var children = parent.Cast<Transform>().Where(t => t.gameObject.hideFlags == HideFlags.None && t.GetComponent(this.GetPoolableObjectType()) == null).ToList();

			if (sortAlphabetically) {
				children.Sort((d1, d2) => string.Compare(d1.name, d2.name, StringComparison.Ordinal));
			}

			return children;
		}

		/// <summary>
		/// Gets the containers beneath the manager that have a pool on them.
		/// </summary>
		/// <param name="sortAlphabetically">A value indicating whether to sort the containers alphabetically by name.</param>
		/// <returns>A list of <see cref="Transform"/> components belonging to the containers that have a pool on them.</returns>
		public IList<Transform> GetContainersWithPools(bool sortAlphabetically) {
			var poolContainers = this.manager.FindChildPools(true).Select(p => p.transform).ToList();

			if (sortAlphabetically) {
				poolContainers.Sort((d1, d2) => string.Compare(d1.name, d2.name, StringComparison.Ordinal));
			}

			return poolContainers;
		}

		public IList<Transform> GetContainers(IEnumerable<TPool> pools, bool sortAlphabetically) {
			var poolContainers = pools.Select(p => p.transform).ToList();

			if (sortAlphabetically) {
				poolContainers.Sort((d1, d2) => string.Compare(d1.name, d2.name, StringComparison.Ordinal));
			}

			return poolContainers;
		}

		/// <summary>
		/// When implemented in a derived class, gets the display name for the specified source.
		/// </summary>
		/// <param name="source">The source to get the name of.</param>
		/// <returns>The display name for the specified source.</returns>
		public abstract string GetSourceName(TSource source);

		/// <summary>
		/// When implemented in a derived class, gets the derived type of <see cref="PoolableObject{T}"/>.
		/// </summary>
		/// <returns>The derived type of <see cref="PoolableObject{T}"/>.</returns>
		protected abstract Type GetPoolableObjectType();

	}

}