using System;

using UnityEditor;

namespace Umbrace.Unity.PurePool.Editor {

	public class UndoGroup : IDisposable {

		private readonly int previousGroupID;

		public UndoGroup(string name) {
			this.previousGroupID = Undo.GetCurrentGroup();
			Undo.IncrementCurrentGroup();
			Undo.SetCurrentGroupName(name);
		}

		public void Dispose() {
			Undo.CollapseUndoOperations(this.previousGroupID);
		}

	}

}