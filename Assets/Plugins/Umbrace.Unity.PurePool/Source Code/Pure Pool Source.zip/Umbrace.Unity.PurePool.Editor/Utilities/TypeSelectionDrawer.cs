﻿using System;
using System.Collections.Generic;
using System.Linq;

using UnityEditor;
using UnityEditor.IMGUI.Controls;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class TypeSelectionDrawer {

		#region Fields.
		private bool allowEmptyComponentMenu = true;

		private Type[] types;
		private GUIContent[] typeNames;
		private GUIContent[] filteredTypeNames;
		private Type[] filteredTypes;

		private Vector2 scrollPos;
		private string searchText;
		private SearchField searchField;
		#endregion

		#region Properties.
		protected GUIContent[] FilteredNames {
			get {
				if (string.IsNullOrEmpty(this.searchText)) return this.typeNames;
				return this.filteredTypeNames;
			}
		}

		protected Type[] FilteredTypes {
			get {
				if (string.IsNullOrEmpty(this.searchText)) return this.types;
				return this.filteredTypes;
			}
		}

		public string SearchText => this.searchText;

		/// <summary>
		/// Gets or sets a value indicating whether to show the component type if its <see cref="AddComponentMenu"/> attribute specifies an empty
		/// component menu name, meaning the component won't show up in the Add Component menu.
		/// </summary>
		public bool AllowEmptyComponentMenu {
			get { return this.allowEmptyComponentMenu; }
			set {
				if (this.allowEmptyComponentMenu == value) return;
				this.allowEmptyComponentMenu = value;
				this.RefreshComponentTypes();
			}
		}
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="TypeSelectionDrawer"/> class.
		/// </summary>
		public TypeSelectionDrawer() {
			this.RefreshComponentTypes();
			this.searchField = new SearchField();
		}
		#endregion

		#region Methods.
		public Type Draw(Type currentType) {
			bool changed = GUI.changed;

			string newSearchText = this.searchField.OnToolbarGUI(this.searchText);
			if (newSearchText != this.searchText) {
				this.searchText = newSearchText;
				this.RefreshFilteredTypes();
			}

			int currentSelection = this.GetSelectionIndex(currentType);

			float minHeight = (this.FilteredNames.Length * EditorGUIUtility.singleLineHeight) + (3 * EditorGUIUtility.singleLineHeight);
			if (minHeight > 400) minHeight = 400;

			this.scrollPos = EditorGUILayout.BeginScrollView(this.scrollPos, false, false, GUILayout.Height(minHeight));
			int newSelection = GUILayout.SelectionGrid(currentSelection, this.FilteredNames, 1);
			EditorGUILayout.EndScrollView();

			// Ignore the changes made by any controls drawn in this method.
			GUI.changed = changed;
			
			if (newSelection != currentSelection && newSelection != -1) {
				GUI.changed = true;
				return this.FilteredTypes[newSelection];
			}

			return currentType;
		}

		public Type Draw(Type currentType, float width) {
			bool changed = GUI.changed;

			this.searchField.SetFocus();
			string newSearchText = this.searchField.OnGUI(this.searchText);
			if (newSearchText != this.searchText) {
				this.searchText = newSearchText;
				this.RefreshFilteredTypes();
			}

			EditorGUILayout.BeginHorizontal();
			GUILayout.FlexibleSpace();
			EditorGUILayout.LabelField("Component", new GUIStyle(EditorStyles.boldLabel) { wordWrap = true });
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();

			int currentSelection = this.GetSelectionIndex(currentType);
			
			this.scrollPos = EditorGUILayout.BeginScrollView(this.scrollPos, false, false);
			var style = new GUIStyle {
				hover = {
					background = new Texture2D(1, 1),
					textColor = Color.white
				},
				padding = new RectOffset(15, 0, 5, 5),
				fontSize = 11
			};
			style.hover.background.SetPixel(0, 0, GUI.skin.settings.selectionColor);
			style.hover.background.Apply();
			int newSelection = GUILayout.SelectionGrid(currentSelection, this.FilteredNames, 1, style, GUILayout.Width(width - GUI.skin.verticalScrollbar.fixedWidth - GUI.skin.verticalScrollbar.margin.left - style.margin.left - style.margin.right));
			EditorGUILayout.EndScrollView();

			// Ignore the changes made by any controls drawn in this method.
			GUI.changed = changed;

			if (newSelection != currentSelection && newSelection != -1) {
				GUI.changed = true;
				return this.FilteredTypes[newSelection];
			}

			return currentType;
		}

		public void RefreshComponentTypes() {
			this.types = TypeHelper.FindComponentTypes(this.AllowEmptyComponentMenu).OrderBy(type => type.Name).ToArray();

			this.typeNames = this.types.Select(type => {
				string tooltip = type.GetCustomAttributes(typeof(AddComponentMenu), false).Cast<AddComponentMenu>().FirstOrDefault()?.componentMenu;
				if (!string.IsNullOrEmpty(tooltip)) {
					tooltip += " " + type.Name;
				} else {
					tooltip = type.Name;
				}

				return new GUIContent(type.Name, tooltip);
			}).ToArray();

			this.RefreshFilteredTypes();
		}

		private void RefreshFilteredTypes() {
			var filtered = this.typeNames.Select((content, i) =>
				new KeyValuePair<GUIContent, int>(content, i)).TextSearch(content => content.Key.tooltip, this.searchText);

			this.filteredTypeNames = filtered.Select(kvp => kvp.Key).ToArray();
			this.filteredTypes = filtered.Select(kvp => this.types[kvp.Value]).ToArray();
		}

		private int GetSelectionIndex(Type source) {
			return Array.IndexOf(this.FilteredTypes, source);
		}
		#endregion

	}

	internal class TypeSelectionPopup : PopupWindowContent {

		private readonly TypeSelectionDrawer drawer = new TypeSelectionDrawer {
			AllowEmptyComponentMenu = false
		};

		public Vector2 Size { get; set; } = new Vector2(200, 300);

		public Type CurrentType { get; set; }

		public Action<Type> OnSelectionMade { get; set; }

		public override Vector2 GetWindowSize() {
			return this.Size;
		}

		public override void OnGUI(Rect rect) {
			Event current = Event.current;

			if (current.type == EventType.KeyDown && current.keyCode == KeyCode.Escape && string.IsNullOrEmpty(this.drawer.SearchText)) {
				current.Use();
				this.editorWindow.Close();
				return;
			}

			EditorGUI.BeginChangeCheck();
			this.CurrentType = this.drawer.Draw(this.CurrentType, this.Size.x);
			if (EditorGUI.EndChangeCheck()) {
				this.editorWindow.Close();
			}

			this.editorWindow.Repaint();
		}
		
		public override void OnClose() {
			if (this.CurrentType != null) {
				this.OnSelectionMade?.Invoke(this.CurrentType);
			}
		}

	}

}