﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal static class Extensions {

		/// <summary>
		/// Determines whether the specified sequence of values are all identical to each other.
		/// </summary>
		/// <typeparam name="T">The type of the value to check.</typeparam>
		/// <param name="sequence">The sequence of values to check.</param>
		/// <param name="comparer">An optional equality comparer.</param>
		/// <returns><see langword="true"/> if the sequence of values are identical to each other; otherwise, <see langword="false"/>.</returns>
		public static bool Unanimous<T>(this IEnumerable<T> sequence, IEqualityComparer<T> comparer = null) {
			T first = default(T);
			bool hasFirst = false;

			foreach (var item in sequence) {
				if (!hasFirst) {
					first = item;
					hasFirst = true;
				} else if (comparer != null && !comparer.Equals(first, item))
					return false;
				else if (!first.Equals(item))
					return false;
			}

			return true;
		}

		/// <summary>
		/// Adds a strikethrough character between each letter of the specified text, to simulate a strikethrough effect.
		/// </summary>
		/// <param name="text">The text to strikethrough.</param>
		/// <returns>The text with strikethrough characters.</returns>
		public static string WithStrikethrough(this string text) {
			var sb = new StringBuilder();

			foreach (char c in text) {
				sb.Append(c).Append('\u0336');
			}

			return sb.ToString();
		}

		public static string GetPath(this Transform transform) {
			// TODO: Escape slashes in the transform name with double-slashes?

			string path = transform.name;
			while (transform.parent != null) {
				transform = transform.parent;
				path = transform.name + "/" + path;
			}
			return path;
		}

		public static IEnumerable<string> ExpandTransformPath(string transformPath) {
			return transformPath.Split(new [] { '/' }, StringSplitOptions.RemoveEmptyEntries);
		}

		public static IEnumerable<T> TextSearch<T>(this IEnumerable<T> items, Func<T, string> sortSelector, string regexPattern) {
			if (!string.IsNullOrEmpty(regexPattern)) {
				Regex regex;
				try {
					regex = new Regex(regexPattern, RegexOptions.IgnoreCase);
				} catch (ArgumentException) {
					try {
						regex = new Regex(Regex.Escape(regexPattern), RegexOptions.IgnoreCase);
					} catch (ArgumentException) {
						return new List<T>();
					}
				}

				return items.Where(item => regex.IsMatch(sortSelector(item))).ToList();
			}

			return items;
		}

	}

}