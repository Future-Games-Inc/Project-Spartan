﻿using System.Diagnostics.CodeAnalysis;

using UnityEditor;
using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	public static class MenuItems {

		#region GameObject menu item.
		/// <summary>
		/// Adds a menu item to create a GameObject pool.
		/// </summary>
		/// <param name="menuCommand"></param>
		[MenuItem("GameObject/Pooling/GameObject Pool", false, 10)] // Priority 10 ensures it is grouped with the other menu items of the same kind and propagated to the hierarchy dropdown and hierarchy context menus.
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void CreateCustomGameObjectPool(MenuCommand menuCommand) {
			MenuItems.CreateCustomGameObject<GameObjectPool>("GameObject Pool", menuCommand.context as GameObject);
		}
		#endregion

		#region GameObject menu item.
		/// <summary>
		/// Adds a menu item to create a component pool.
		/// </summary>
		/// <param name="menuCommand"></param>
		[MenuItem("GameObject/Pooling/Component Pool", false, 10)] // Priority 10 ensures it is grouped with the other menu items of the same kind and propagated to the hierarchy dropdown and hierarchy context menus.
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void CreateCustomComponentPool(MenuCommand menuCommand) {
			MenuItems.CreateCustomGameObject<ComponentPool>("Component Pool", menuCommand.context as GameObject);
		}
		#endregion

		#region GameObject menu item.
		/// <summary>
		/// Adds a menu item to create a component pool manager.
		/// </summary>
		/// <param name="menuCommand"></param>
		[MenuItem("GameObject/Pooling/Component Pool Manager", false, 10)] // Priority 10 ensures it is grouped with the other menu items of the same kind and propagated to the hierarchy dropdown and hierarchy context menus.
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void CreateCustomComponentPoolManager(MenuCommand menuCommand) {
			MenuItems.CreateCustomGameObject<ComponentPoolManager>("Component Pool Manager", menuCommand.context as GameObject);
		}
		#endregion

		#region GameObject menu item.
		/// <summary>
		/// Adds a menu item to create a GameObject pool manager.
		/// </summary>
		/// <param name="menuCommand"></param>
		[MenuItem("GameObject/Pooling/GameObject Pool Manager", false, 10)] // Priority 10 ensures it is grouped with the other menu items of the same kind and propagated to the hierarchy dropdown and hierarchy context menus.
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void CreateCustomGameObjectPoolManager(MenuCommand menuCommand) {
			MenuItems.CreateCustomGameObject<GameObjectPoolManager>("GameObject Pool Manager", menuCommand.context as GameObject);
		}
		#endregion

		/// <summary>
		/// Creates a new <see cref="GameObject"/> with a component added to it, with the specified name, and parented and aligned to the specified parent.
		/// </summary>
		/// <typeparam name="T">The type of component to add to the new <see cref="GameObject"/>.</typeparam>
		/// <param name="name">The name of the <see cref="GameObject"/>.</param>
		/// <param name="parent">The parent <see cref="GameObject"/>.</param>
		/// <remarks>
		/// This method is useful when using a <see cref="MenuItem"/> attribute to add an item to the GameObject menu.
		/// Internally, <see cref="GameObjectUtility.SetParentAndAlign"/> is used to ensure the object is re-parented
		/// if the menu action was from a context click.
		/// </remarks>
		private static void CreateCustomGameObject<T>(string name, GameObject parent) where T : Component {
			// Create a custom game object.
			GameObject go = new GameObject(name);
			go.AddComponent<T>();

			// Ensure it gets re-parented if this was a context click (otherwise does nothing).
			GameObjectUtility.SetParentAndAlign(go, parent);

			// Register the creation in the undo system.
			Undo.RegisterCreatedObjectUndo(go, "Create " + name);
			Selection.activeObject = go;
		}

	}

}