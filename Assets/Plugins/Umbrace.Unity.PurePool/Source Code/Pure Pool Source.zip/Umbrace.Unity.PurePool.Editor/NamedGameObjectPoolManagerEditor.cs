﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

using UnityEditor;

using UnityEditorInternal;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[CustomEditor(typeof(NamedGameObjectPoolManager))]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	public class NamedGameObjectPoolManagerEditor : UnityEditor.Editor {

		#region Inner classes.
		[Serializable]
		private class PoolName {

			public string Name;
			public GameObject SourceObject;

			public bool IsActive;

			public bool IsValid => !string.IsNullOrEmpty(this.Name) && this.SourceObject != null;

		}
		#endregion

		#region Fields.
		private NamedGameObjectPoolManager manager;

		private ReorderableList poolNamesList;
		private ReorderableList namesAddedFromManager;

		private readonly List<PoolName> poolNames = new List<PoolName>();
		private readonly List<PoolName> addedFromManager = new List<PoolName>();

		private SerializedProperty managerProperty;
		private SerializedProperty autoAddFromManagerProperty;
		private SerializedProperty useResourcesProperty;
		#endregion

		#region Editor methods.
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private void OnEnable() {
			this.manager = (NamedGameObjectPoolManager)this.target;
			
			this.poolNamesList = new ReorderableList(this.poolNames, typeof(PoolName), false, true, true, true) {
				drawElementCallback = this.DrawElementCallback,
				onRemoveCallback = this.OnRemoveCallback,
				drawHeaderCallback = this.DrawHeaderCallback
			};

			this.namesAddedFromManager = new ReorderableList(this.addedFromManager, typeof(PoolName), false, true, false, false) {
				drawHeaderCallback = rect => EditorGUI.LabelField(rect, "Pool Names Added From Manager"),
				drawElementCallback = this.DrawAutoAddedElement,
				drawElementBackgroundCallback = (rect, index, active, focused) => { } // Don't draw a background, as we don't want the current selection to be visible.
			};

			// Find serialised properties.
			this.managerProperty = this.serializedObject.FindProperty("manager");
			this.autoAddFromManagerProperty = this.serializedObject.FindProperty("autoAddFromManager");
			this.useResourcesProperty = this.serializedObject.FindProperty("useResources");
			
			// Populate the list of pool names.
			this.PopulatePoolNames();

			// Listen for changes to the named pools, to keep the list updated.
			this.manager.Changed += this.ManagerOnChanged;
			Undo.undoRedoPerformed += this.UndoRedoPerformed;
		}

		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private void OnDisable() {
			this.manager.Changed -= this.ManagerOnChanged;
			Undo.undoRedoPerformed -= this.UndoRedoPerformed;
		}

		public override void OnInspectorGUI() {
			this.serializedObject.Update();

			// Set the minimum label width to be larger than the default, so the labels aren't cut off.
			using (new LabelWidthGroup(180)) {
				this.DrawDefaultInspector();

				this.DrawManagerProperties();

				// Ensure a GameObjectPoolManager is connected to the NamedGameObjectPoolManager.
				if (!this.EnsureManager()) return;

				// Draw the pool names that will be automatically added in play mode, when AutoAddFromManager is true.
				if (!EditorApplication.isPlaying && this.manager.AutoAddFromManager) {
					if (this.manager.Manager.AttachDescendentPools) {
						this.addedFromManager.Clear();
						foreach (var pool in this.manager.Manager.FindChildPools()) {
							if (pool == null || pool.Source == null) continue;

							this.addedFromManager.Add(new PoolName {
								Name = pool.Source.name,
								SourceObject = pool.Source
							});
						}

						this.namesAddedFromManager.DoLayoutList();
					} else {
						EditorGUILayout.HelpBox($"{nameof(this.manager.Manager.AttachDescendentPools)} is disabled on the connected {nameof(GameObjectPoolManager)}. " +
												$"{nameof(this.manager.AutoAddFromManager)} will add pools that are attached to the manager at runtime.", MessageType.Info);
					}
				}

				EditorGUILayout.HelpBox("Assign names to the source objects, to allow you to access the pools by name. " +
										"The selected GameObject should be the Source Object of the pool.", MessageType.Info);

				// Draw the customisable list of names.
				this.poolNamesList.DoLayoutList();
			}

			this.serializedObject.ApplyModifiedProperties();
		}
		#endregion

		private void ManagerOnChanged(object sender, EventArgs eventArgs) {
			this.PopulatePoolNames();
			PrefabHelper.MarkPrefabChanged(this.target);
			this.Repaint();
		}

		private void UndoRedoPerformed() {
			this.PopulatePoolNames();
			this.Repaint();
		}

		private void DrawManagerProperties() {
			this.DrawSetting(this.managerProperty,
				rect => (GameObjectPoolManager)EditorGUI.ObjectField(rect, new GUIContent("Manager", "The pool manager whose pools should be accessed by name."), this.manager.Manager, typeof(GameObjectPoolManager), true),
				newValue => this.manager.Manager = newValue);

			this.DrawSetting(this.autoAddFromManagerProperty,
				rect => EditorGUI.Toggle(rect, new GUIContent("Auto Add From Manager", "Whether to automatically provide named access to the pools attached to the manager."), this.manager.AutoAddFromManager),
				newValue => this.manager.AutoAddFromManager = newValue);

			this.DrawSetting(this.useResourcesProperty,
				rect => EditorGUI.Toggle(rect, new GUIContent("Use Resources", "Whether to locate unrecognised GameObject names using the Resources.Load method."), this.manager.AutoAddFromManager),
				newValue => this.manager.UseResources = newValue);
		}

		private bool EnsureManager() {
			if (this.manager.Manager == null) {
				EditorGUILayout.HelpBox($"The {nameof(this.manager.Manager)} property cannot be null. " +
									$"Select a {nameof(GameObjectPoolManager)} to set up named access.", MessageType.Warning);
				if (GUILayout.Button($"Find {nameof(GameObjectPoolManager)} In Scene", GUILayout.ExpandWidth(false))) {
					this.manager.Manager = UnityEngine.Object.FindObjectOfType<GameObjectPoolManager>();
				}
				return false;
			}

			return true;
		}

		#region PoolName validation methods.
		private bool IsNameInUse(string name, PoolName element) {
			if (string.IsNullOrEmpty(name)) return false;

			GameObject sourceObject;
			if (this.manager.TryGetGameObject(name, out sourceObject)) {
				if (!element.IsActive || sourceObject != element.SourceObject) return true;
			}
			return false;
		}

		private bool IsSourceObjectInUse(GameObject sourceObject, PoolName element) {
			if (sourceObject == null) return false;

			string name;
			if (this.manager.TryGetName(sourceObject, out name)) {
				if (!element.IsActive || name != element.Name) return true;
			}
			return false;
		}
		#endregion

		#region AutoAddFromManager drawing.
		private void DrawAutoAddedElement(Rect rect, int index, bool isActive, bool isFocused) {
			// Skip if the index is outside the bounds of the list. This can occur when the list is refreshed, and the ReorderableList still thinks there are more items than there now are.
			if (index >= this.namesAddedFromManager.list.Count) return;

			var element = (PoolName)this.namesAddedFromManager.list[index];
			rect.y += 2;

			EditorGUI.SelectableLabel(new Rect(rect.x, rect.y, rect.width / 2, EditorGUIUtility.singleLineHeight), element.Name);
			EditorGUI.ObjectField(new Rect(rect.x + (rect.width / 2), rect.y, rect.width / 2, EditorGUIUtility.singleLineHeight), element.SourceObject, typeof(GameObject), true);
		}
		#endregion

		#region Custom names drawing.
		private void PopulatePoolNames() {
			this.poolNames.Clear();
			this.poolNames.AddRange(this.manager.AssignedNames.Select(kvp => new PoolName {
				Name = kvp.Key,
				SourceObject = kvp.Value,
				IsActive = true
			}));
		}
		
		private void DrawHeaderCallback(Rect rect) {
			EditorGUI.LabelField(rect, "Custom Pool Names");
		}

		private void OnRemoveCallback(ReorderableList list) {
			var element = (PoolName)list.list[list.index];

			if (element.IsValid && element.IsActive) {
				Undo.RecordObject(this.manager, "Remove Pool Name");
				this.manager.RemoveName(element.Name);
			}

			ReorderableList.defaultBehaviours.DoRemoveButton(list);
		}
		
		private void DrawElementCallback(Rect rect, int index, bool isActive, bool isFocused) {
			// Skip if the index is outside the bounds of the list. This can occur when the list is refreshed, and the ReorderableList still thinks there are more items than there now are.
			if (index >= this.poolNamesList.list.Count) return;

			var element = (PoolName)this.poolNamesList.list[index];
			rect.y += 2;

			// Tint the background red if the pool name is invalid.
			var bgColour = GUI.backgroundColor;
			if (!element.IsValid) {
				GUI.backgroundColor = new Color(1f, 0.3f, 0.3f);
			}

			EditorGUI.BeginChangeCheck();
			string newName = EditorGUI.DelayedTextField(new Rect(rect.x, rect.y, rect.width / 2, EditorGUIUtility.singleLineHeight), element.Name);
			if (EditorGUI.EndChangeCheck()) {
				if (!this.IsNameInUse(newName, element)) {
					// If the name and object are already added to the manager, remove them first.
					if (element.IsActive) {
						Undo.RecordObject(this.manager, "Remove Pool Name");
						this.manager.RemoveName(element.Name);
						element.IsActive = false;
					}

					element.Name = newName;
				} else {
					EditorUtility.DisplayDialog("Error", $"The name '{newName}' is already in use for the source object '{this.manager.GetGameObject(newName).name}'. Please choose a different name.", "OK");
				}
			}

			EditorGUI.BeginChangeCheck();
			var newObject = (GameObject)EditorGUI.ObjectField(new Rect(rect.x + (rect.width / 2), rect.y, rect.width / 2, EditorGUIUtility.singleLineHeight), element.SourceObject, typeof(GameObject), true);
			if (EditorGUI.EndChangeCheck()) {
				if (!this.IsSourceObjectInUse(newObject, element)) {
					// If the name and object are already added to the manager, remove them first.
					if (element.IsActive) {
						Undo.RecordObject(this.manager, "Remove Pool Name");
						this.manager.RemoveName(element.Name);
						element.IsActive = false;
					}

					element.SourceObject = newObject;
					// Default the name to the object's name.
					if (element.Name == null && newObject != null && !this.IsNameInUse(newObject.name, element)) {
						element.Name = newObject.name;
					}
				} else {
					EditorUtility.DisplayDialog("Error", $"The source object '{newObject.name}' already has a name assigned ('{this.manager.GetName(newObject)}').", "OK");
				}
			}

			// If the pool name is valid, and isn't yet added to the manager, add it now.
			if (element.IsValid && !element.IsActive) {
				Undo.RecordObject(this.manager, "Set Pool Name");
				this.manager.SetName(element.SourceObject, element.Name);
				element.IsActive = true;
			}

			GUI.backgroundColor = bgColour;
		}
		#endregion

		protected void DrawSetting<T>(SerializedProperty property, Func<Rect, T> drawControl, Action<T> setValue) {
			//EditorGUI.showMixedValue = !pools.Select(kvp => currentValueSelector(kvp.Key, kvp.Value)).Unanimous();
			var rect = EditorGUILayout.GetControlRect(true);
			if (property != null) {
				EditorGUI.BeginProperty(rect, GUIContent.none, property);
			}

			EditorGUI.BeginChangeCheck();
			T newValue = drawControl(rect);
			if (EditorGUI.EndChangeCheck()) {
				// Record an undo state for the pools being edited.
				Undo.RecordObject(this.manager, "Change Pool Setting");

				// Apply the change in value to all pools (or pool settings) being edited.
				setValue(newValue);

				// Prefab override support.
				if (property != null) {
					// Ensure all pools being edited have their prefab state updated.
					foreach (var targetObject in property.serializedObject.targetObjects) {
						PrefabHelper.MarkPrefabChanged(targetObject);
					}
				}
			}
			if (property != null) {
				EditorGUI.EndProperty();
			}
		}

	}

}