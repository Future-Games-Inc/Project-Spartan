﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

using Umbrace.Unity.Contracts;
using Umbrace.Unity.PurePool.ForEditor;

using UnityEditor;
using UnityEditor.IMGUI.Controls;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal abstract class BasePoolManagerEditor<TManager, TManagerSettings, TManagerEditorSettings, TPool, TPoolSettings, TSource, TInstance> : UnityEditor.Editor
		where TManagerSettings : PoolManagerSettings<TPoolSettings, TSource>
		where TManagerEditorSettings : ManagerEditorSettings<TPool, TSource, TInstance, TPoolSettings>
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TPool : PoolBase<TSource, TInstance, TPoolSettings>
		where TManager : PoolManagerBase<TManagerSettings, TPool, TPoolSettings, TSource, TInstance>
		where TSource : class {
		
		#region Fields.
		protected readonly List<Action> delayedActions = new List<Action>();
		private readonly List<Action> delayedActionsCopy = new List<Action>();

		private Transform containerNameBeingEdited;
		protected TPool lastCreatedPool;
		private SearchField poolSearchField;
		private string poolSearchText;

		private TManager manager;
		private ManagerEditorSettings<TPool, TSource, TInstance, TPoolSettings> settings;

		protected Helper<TManager, TManagerSettings, TManagerEditorSettings, TPool, TPoolSettings, TSource, TInstance> helper;
		protected PoolDrawer<TPool, TSource, TInstance, TPoolSettings> poolDrawer;
		private PoolDrawer<TPool, TSource, TInstance, TPoolSettings> defaultSettingsDrawer;
		private PoolSearch poolSearch;

		private GUIStyle boldFoldoutStyle;
		private GUIStyle poolLabelStyle;
		#endregion

		#region Properties.
		protected IList<TPool> OtherAttachedPools {
			get {
				var underManagerPools = this.manager.FindChildPools();
				return this.manager.Pools.Except(underManagerPools).ToList();
			}
		}

		protected bool IsFiltered => !string.IsNullOrEmpty(this.poolSearchText);

		protected IList<TPool> FilteredPools => this.poolSearch.Search(this.UnfilteredPools, this.poolSearchText);

		protected IList<TPool> UnfilteredPools {
			get {
				var childPools = this.manager.FindChildPools();
				var pools = EditorApplication.isPlaying ?
					childPools.Union(this.manager.Pools).ToList() :
					childPools.ToList();
				return pools;
			}
		}

		protected TManager Manager => this.manager;
		#endregion

		protected abstract Helper<TManager, TManagerSettings, TManagerEditorSettings, TPool, TPoolSettings, TSource, TInstance> CreateHelper();
		protected abstract PoolDrawer<TPool, TSource, TInstance, TPoolSettings> CreatePoolDrawer();
		protected abstract PoolDrawer<TPool, TSource, TInstance, TPoolSettings> CreateDefaultSettingsDrawer();

		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		protected virtual void OnEnable() {
			this.manager = (TManager)this.target;
			if (this.helper == null) this.helper = this.CreateHelper();

			this.settings = this.helper.GetSettingsComponent();
			this.poolDrawer = this.CreatePoolDrawer();
			this.defaultSettingsDrawer = this.CreateDefaultSettingsDrawer();
			this.poolSearch = new PoolSearch();
			this.poolSearchField = new SearchField();

			EditorApplication.hierarchyWindowChanged += this.OnHierarchyChanged;
		}

		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		protected virtual void OnDisable() {
			EditorApplication.hierarchyWindowChanged -= this.OnHierarchyChanged;
		}

		protected virtual void OnHierarchyChanged() {
			// Since the containers are based on GameObjects, we need to repaint the inspector if the hierarchy has changed, in case any of the containers have changed.
			this.Repaint();
		}

		public override bool RequiresConstantRepaint() {
			if (base.RequiresConstantRepaint()) return true;

			// Repaint the editor constantly while the statistics are shown, as the statistics will always be updating.
			foreach (var pool in this.FilteredPools.Where(p => p.IsInitialised)) {
				ContainerSettings containerSettings = this.helper.GetContainerSettings(pool.gameObject);

				if (containerSettings.FoldoutOpen.CurrentValue) {
					PoolDisplaySettings poolSettings = this.helper.GetPoolSettings(pool);

					if (poolSettings.ShowStatistics && poolSettings.StatisticsExpanded) {
						return true;
					}
				}
			}

			return false;
		}

		public override void OnInspectorGUI() {
			this.serializedObject.Update();

			this.boldFoldoutStyle = this.boldFoldoutStyle ?? new GUIStyle(EditorStyles.foldout) {
				fontStyle = FontStyle.Bold
			};
			this.poolLabelStyle = this.poolLabelStyle ?? new GUIStyle(EditorStyles.label) {
				fontStyle = FontStyle.Italic
			};

			if (Event.current.type == EventType.Layout) {
				// After the start of a layout pass, we avoid making changes to the manager that will result in a different number of UI elements being drawn.
				// If the number of GUI items being drawn changes between the layout pass and the repaint pass (e.g. due to adding a definition), Unity will throw an error.

				// Process any pending actions that cannot be performed immediately, and must wait for the next layout pass.
				this.ProcessDelayedActions();

				this.settings.ChangeValues();
			}
			
			// Draw the manager's Enabled toggle button.
			string enabledButtonText = this.manager.Enabled ? "Disable Pooling" : "Enable Pooling";
			this.DrawSetting(this.serializedObject.FindProperty("settings.isPoolingEnabled"),
				rect => {
					var buttonRect = new Rect(rect);
					buttonRect.x += 20;
					buttonRect.width -= 2 * 20;
					return GUI.Toggle(buttonRect, !this.manager.Enabled, new GUIContent(enabledButtonText), GUI.skin.button);
				},
				newValue => this.manager.Enabled = !newValue);
			if (!this.manager.Enabled) {
				EditorGUILayout.HelpBox("Pooling is currently disabled. " +
										"All pools will appear empty, and acquiring from them will only work if " +
										$"{nameof(PoolBase<TSource, TInstance, TPoolSettings>.InstantiateWhenEmpty)} is true.", MessageType.Warning);
			}

			// Set the minimum label width to be larger than the default, so the labels aren't cut off.
			using (new LabelWidthGroup(200)) {
				this.DrawDefaultInspector();

				this.DrawManagerProperties();

				// Draw the editor for changing the default settings for new pools.
				this.DrawDefaultSettingsFoldout();

				// Draw the foldout for the object pools.
				this.DrawOverallObjectPoolsFoldout();

				// If the object pools should be displayed, draw them.
				if (this.settings.PoolViewExpanded) {
					this.DrawObjectPools();
				}
			}

			this.serializedObject.SetIsDifferentCacheDirty();
			this.serializedObject.ApplyModifiedProperties();
		}

		protected virtual void DrawManagerProperties() {
			// Draw the Dont Destroy On Load field.
			this.DrawSetting(this.serializedObject.FindProperty("settings.dontDestroyOnLoad"),
				rect => EditorGUI.Toggle(rect, new GUIContent("Don't Destroy On Load", "A value indicating whether the pool manager (and its pools) will remain in the scene when a new scene is loaded."), this.manager.DontDestroyOnLoad),
				newValue => this.manager.DontDestroyOnLoad = newValue);
			
			// Draw the Attach Descendent Pools field.
			this.DrawSetting(this.serializedObject.FindProperty("settings.attachDescendentPools"),
				rect => EditorGUI.Toggle(rect, new GUIContent("Attach Descendent Pools", "A value indicating whether to attach all descendent pools to the manager on startup."), this.manager.AttachDescendentPools),
				newValue => this.manager.AttachDescendentPools = newValue);
			
			// Draw the Acquire Mode field.
			this.DrawSetting(this.serializedObject.FindProperty("settings.acquireMode"),
				rect => (AcquireNoPoolMode)EditorGUI.EnumPopup(rect, new GUIContent("Acquire Without Pool", "The action to take when an attempt is made to acquire an object from the manager, but no pool exists for the object."), this.manager.AcquireMode),
				newValue => this.manager.AcquireMode = newValue);
		}

		protected virtual void DrawDefaultSettingsFoldout() {
			BoolEditorChangeValue defaultSettingsExpanded = this.settings.DefaultSettingsExpanded;

			// Temporarily turn off hierarchy mode, so the foldout is drawn indented. Hierarchy mode would cause the label of the foldout to be lined up with other labels,
			// with the foldout arrow positioned further to the left.
			using (new HierarchyModeGroup(false)) {
				defaultSettingsExpanded.TargetValue = EditorGUILayout.Foldout(defaultSettingsExpanded, new GUIContent("Default Settings (New Pools)"), true, this.boldFoldoutStyle);
			}

			if (defaultSettingsExpanded) {
				EditorGUI.indentLevel++;
				EditorGUILayout.HelpBox(this.DefaultSettingsHelpText, MessageType.Info);
				this.defaultSettingsDrawer.DrawPoolDefinition(this.manager.DefaultPoolSettings, true);
				EditorGUI.indentLevel--;
			}
		}

		/// <summary>
		/// When implemented in a derived class, gets the help text to display for the Default Settings foldout.
		/// </summary>
		protected abstract string DefaultSettingsHelpText { get; }

		private void ProcessDelayedActions() {
			// Process any pending actions that cannot be performed immediately, and must wait for the next layout pass.
			if (this.delayedActions.Count > 0) {
				this.delayedActionsCopy.AddRange(this.delayedActions);
				this.delayedActions.Clear();

				foreach (Action delayedAction in this.delayedActionsCopy) {
					delayedAction();
				}

				this.delayedActionsCopy.Clear();
			}
		}

		/// <summary>
		/// Draws the object pools and optionally their containers.
		/// </summary>
		private void DrawObjectPools() {
			EditorGUI.indentLevel++;
			// Either draw the full containers, or just the pools.
			if (this.settings.ShowContainers) {
				// Enumerate over the child containers of the manager.
				foreach (Transform container in this.helper.GetContainers(this.manager.transform, this.settings.SortAlphabetically)) {
					// Draw the container and its children.
					this.DrawContainer(container, true);
				}

				// If there are other pools attached that aren't children of the manager, draw them under a special "Loose Pools" container.
				if (this.OtherAttachedPools.Count > 0) {
					EditorGUILayout.Space();
					EditorGUIHelper.DrawFoldout(this.settings.LoosePoolContainerExpanded, new GUIContent(this.settings.LoosePoolsContainerName, "Pools that are attached to the manager, but are not parented beneath the manager's transform ."), (expanded, rect) => {
						// Draw nothing in the foldout.
					});
					if (this.settings.LoosePoolContainerExpanded) {
						EditorGUI.indentLevel++;
						foreach (Transform container in this.OtherAttachedPools.Select(p => p.transform)) {
							// Draw the container but not its children.
							this.DrawContainer(container, false);
						}
						EditorGUI.indentLevel--;
					}
				}
			} else {
				// Enumerate over the containers that have a pool attached.
				foreach (Transform poolContainer in this.helper.GetContainers(this.FilteredPools, this.settings.SortAlphabetically)) {
					// Draw the container but not its children.
					this.DrawContainer(poolContainer, false);
				}
			}
			EditorGUI.indentLevel--;
		}

		private void DrawContainer(Transform container, bool drawChildren) {
			// If we're filtering by search text, ignore any containers that don't have a matching pool on them or beneath them.
			if (this.IsFiltered && !this.FilteredPools.Any(p => p.transform.IsChildOf(container))) return;

			var pool = container.GetComponent<TPool>();
			
			// Get the settings for the container and, if it has one, the pool.
			ContainerSettings containerSettings = this.helper.GetContainerSettings(container);
			PoolDisplaySettings poolSettings = pool != null ? this.helper.GetPoolSettings(pool) : null;

			Action<bool, Rect> foldoutAction = this.DrawContainerFoldoutContents(pool, poolSettings, container);
			
			// Only draw a foldout if the container has a pool, or has children. Otherwise, the empty container is just drawn as a toolbar without a foldout.
			if (pool != null || container.childCount > 0) {
				this.DrawContainerFoldout(containerSettings.FoldoutOpen, container.name, container, pool, foldoutAction);
			} else {
				EditorGUIHelper.DrawToolbar(null, EditorStyles.toolbar, rect => {
					this.DrawEditableContainerLabel(container, rect);
					foldoutAction(false, rect);
				});
			}

			if (containerSettings.FoldoutOpen.CurrentValue) {
				// If this container has a pool, draw the editor for it.
				if (pool != null) this.DrawPoolWithDefinition(pool);

				if (drawChildren) {
					EditorGUI.indentLevel++;
					foreach (Transform childContainer in this.helper.GetContainers(container, this.settings.SortAlphabetically)) {
						this.DrawContainer(childContainer, drawChildren);
					}
					EditorGUI.indentLevel--;
				}
			}
		}

		private void DrawContainerFoldout(BoolEditorChangeValue foldoutOpen, string foldoutLabel, Transform container, TPool pool, Action<bool, Rect> foldoutAction) {
			// Draw a custom foldout without a normal label.
			EditorGUIHelper.DrawCustomFoldout(foldoutOpen, EditorStyles.toolbar, (expanded, rect) => {
				Rect clickableRect;

				if (pool != null) {
					// For containers with pools, draw a fixed and un-editable label.
					using (new NoIndentGroup()) {
						clickableRect = EditorGUILayout.BeginHorizontal();
						// Draw the pool's icon, which indicates the state of the pool.
						Texture2D icon = this.GetPoolIcon(pool);
						GUILayout.Label(new GUIContent(icon, this.GetPoolState(pool)), GUILayout.Height(icon.height), GUILayout.Width(icon.width));
						
						EditorGUILayout.LabelField(new GUIContent(foldoutLabel, foldoutLabel), this.poolLabelStyle, GUILayout.MinWidth(10));
						EditorGUILayout.EndHorizontal();
					}
				} else {
					// For containers without pools, draw an editable label.
					this.DrawEditableContainerLabel(container, rect);
					clickableRect = GUILayoutUtility.GetLastRect();
				}

				// Toggle the foldout if the user clicked on the label or text field.
				if (EditorGUIHelper.IsLeftMouseUp(clickableRect) && !EditorGUIUtility.editingTextField) {
					foldoutOpen.Toggle();
					Event.current.Use();
				}

				foldoutAction(expanded, rect);
			});
		}

		private Texture2D GetPoolIcon(TPool pool) {
			Texture2D icon;
			if (!pool.IsInitialised) {
				icon = EditorIcons.GreyBulletTexture;
			} else if (!this.manager.IsAttached(pool)) {
				icon = EditorIcons.YellowBulletTexture;
			} else if (!pool.Enabled) {
				icon = EditorIcons.BlueBulletTexture;
			} else {
				icon = EditorIcons.GreenBulletTexture;
			}
			return icon;
		}

		private string GetPoolState(TPool pool) {
			string state;
			if (!pool.IsInitialised) {
				state = "Pool not initialised.";
			} else if (!this.manager.IsAttached(pool)) {
				state = "Pool not attached.";
			} else if (!pool.Enabled) {
				state = "Pool is disabled.";
			} else {
				state = "Pool initialised and attached.";
			}
			return state;
		}

		private void DrawEditableContainerLabel(Transform container, Rect drawArea) {
			bool isEditing = this.containerNameBeingEdited == container;

			if (EditorGUIHelper.EditableLabel(container.name, drawArea, EditorStyles.textField, "ContainerName" + container.GetHashCode(), isEditing, newName => container.name = newName)) {
				this.containerNameBeingEdited = container;
				this.Repaint();
			} else {
				if (this.containerNameBeingEdited == container) {
					this.containerNameBeingEdited = null;
					this.Repaint();
				}
			}
		}

		private Action<bool, Rect> DrawContainerFoldoutContents(TPool pool, PoolDisplaySettings poolSettings, Transform container) {
			return (expanded, rect) => {
				// Draw one set of controls for containers with pool components, and another set of controls for containers without pool components.
				if (pool != null) {
					// Draw the View button, which selects the pool's game object when pressed.
					if (GUILayout.Button(new GUIContent("View", "Select the pool's GameObject in the hierarchy."), EditorStyles.toolbarButton, GUILayout.ExpandWidth(false))) {
						Selection.activeGameObject = pool.gameObject;
					}

					// Draw a toggleable Details button to show/hide the more advanced settings.
					EditorGUI.BeginChangeCheck();
					bool newShowDetails = GUILayout.Toggle(poolSettings.ShowDetails, "Details", EditorStyles.toolbarButton, GUILayout.ExpandWidth(false));
					if (EditorGUI.EndChangeCheck()) {
						poolSettings.ShowDetails.TargetValue = newShowDetails;

						// If the Details setting has been enabled, ensure the container is expanded.
						if (newShowDetails) {
							this.helper.SetFoldoutStateRecursive(container.gameObject, true);
						}
					}

					// Show a context menu for the pool when the context button is pressed.
					EditorGUIHelper.ContextMenu(rect, menu => {
						if (pool.IsInitialised) {
							menu.AddItem(new GUIContent("Show Definition"), poolSettings.ShowDefinition, () => poolSettings.ShowDefinition.Toggle());
							menu.AddItem(new GUIContent("Show Statistics"), poolSettings.ShowStatistics, () => poolSettings.ShowStatistics.Toggle());
						} else {
							menu.AddDisabledItem(new GUIContent("Show Definition"));
							menu.AddDisabledItem(new GUIContent("Show Statistics"));
						}
						menu.AddItem(new GUIContent("Show Details"), poolSettings.ShowDetails, () => poolSettings.ShowDetails.Toggle());
					});
				} else {
					// Draw the Add Pool button, which adds a TPool component to the container when pressed.
					if (GUILayout.Button(new GUIContent("Add Pool", "Creates a new pool beneath this container."), EditorStyles.toolbarButton, GUILayout.ExpandWidth(false))) {
						this.CreateEmptyPool(container);
					}

					// Show a context menu for the container when the context button is pressed.
					EditorGUIHelper.ContextMenu(rect, menu => {
						menu.AddItem(new GUIContent("New Container"), false, () => this.CreateContainer(container));
						menu.AddSeparator(string.Empty);
						if (container.childCount > 0) {
							menu.AddItem(new GUIContent("Expand All"), false, () => this.ExpandAll(container.gameObject));
							menu.AddItem(new GUIContent("Collapse All"), false, () => this.CollapseAll(container.gameObject));
						} else {
							menu.AddDisabledItem(new GUIContent("Expand All"));
							menu.AddDisabledItem(new GUIContent("Collapse All"));
						}
					});
				}

				// Draw the Remove button, which deletes the container/pool permanently.
				if (GUILayout.Button(new GUIContent("x", "Deletes this container, including its pool if it has one."), EditorStyles.toolbarButton, GUILayout.ExpandWidth(false))) {
					bool remove = container.childCount == 0 || EditorUtility.DisplayDialog("Remove container and its children?", "Are you sure you want to remove this container, and all of its children?", "Remove", "Cancel");

					if (remove) {
						this.DeleteContainers(container.gameObject);
					}
				}

				// Handle dragging and dropping to the foldout, to create a new pool or set the source object.
				this.DragDropContainerFoldout(pool, rect, container);
			};
		}

		/// <summary>
		/// When implemented in a derived class, handles drag and drop events over a container foldout.
		/// </summary>
		/// <param name="pool">The pool attached to the container, or <see langword="null"/> if it has no pool.</param>
		/// <param name="rect">The foldout's area, where drag and drop events should occur.</param>
		/// <param name="container">The container whose drag and drop events should be handled.</param>
		protected virtual void DragDropContainerFoldout(TPool pool, Rect rect, Transform container) {
			// Do nothing.
		}
		
		#region Draw overall pools foldout.
		private void DrawOverallObjectPoolsFoldout() {
			// Draw a foldout for the object pools. Use a custom foldout, as the normal foldout would steal the drag events (to open the foldout), and we need it to create new pools from dropped objects.
			EditorGUIHelper.DrawCustomFoldout(this.settings.PoolViewExpanded, EditorStyles.toolbar, (expanded, rect) => {

				// Draw the foldout label.
				using (new NoIndentGroup()) {
					int poolCount = this.UnfilteredPools.Count;
					string labelText = this.IsFiltered ? $"Pools ({this.FilteredPools.Count}/{poolCount})" : $"Pools ({poolCount})";
					GUILayout.Label(new GUIContent(labelText, labelText));
				}

				// Toggle the foldout if the user clicked on the label.
				var labelRect = GUILayoutUtility.GetLastRect();
				if (EditorGUIHelper.IsLeftMouseUp(labelRect)) {
					this.settings.PoolViewExpanded.Toggle();
					Event.current.Use();
				}

				// Draw a search field to filter the pools.
				this.poolSearchText = this.poolSearchField.OnToolbarGUI(this.poolSearchText, GUILayout.ExpandWidth(true), GUILayout.MinWidth(15));
				
				// Show a button to toggle whether containers are shown, or just the pools themselves.
				this.settings.ShowContainers.TargetValue = GUILayout.Toggle(this.settings.ShowContainers, new GUIContent("Containers", "Show/hide container objects"), EditorStyles.toolbarButton, GUILayout.ExpandWidth(false));

				// Show a toggleable sorting button, to sort the definitions alphabetically.
				this.settings.SortAlphabetically.TargetValue = GUILayout.Toggle(this.settings.SortAlphabetically, new GUIContent("A-z", "Sort definitions alphabetically"), EditorStyles.toolbarButton, GUILayout.ExpandWidth(false));

				// Handle dragging and dropping to the foldout.
				this.DragDropOverallFoldout(rect);

				// Show a context menu when the context button is pressed.
				EditorGUIHelper.ContextMenu(rect, menu => {
					menu.AddItem(new GUIContent("New Container"), false, () => this.CreateContainer(this.manager.transform));
					menu.AddSeparator(string.Empty);
					menu.AddItem(new GUIContent("Expand All"), false, () => this.ExpandAll());
					menu.AddItem(new GUIContent("Collapse All"), false, () => this.CollapseAll());
				});
			});

			// Draw the Quick Add (Drag/Drop) field.
			EditorGUI.indentLevel++;
			if (!EditorApplication.isPlaying && this.settings.PoolViewExpanded) {
				this.QuickAddField();
			}
			EditorGUI.indentLevel--;
		}

		/// <summary>
		/// When implemented in a derived class, handles drag and drop events over the main pool foldout.
		/// </summary>
		/// <param name="rect">The main pool foldout's area, where drag and drop events should occur.</param>
		protected virtual void DragDropOverallFoldout(Rect rect) {
			// Do nothing.
		}

		/// <summary>
		/// When implemented in a derived class, draws a Quick Add field below the main pool foldout, to allow quick pool creation.
		/// </summary>
		protected virtual void QuickAddField() {
			// Do nothing.
		}
		#endregion

		#region Draw individual pool.
		private void DrawPoolWithDefinition(TPool pool) {
			Contract.Requires(pool != null);

			PoolDisplaySettings settings = this.helper.GetPoolSettings(pool);

			// If the pool has been initialised, draw the pool's definition (the settings that were used to initialise it).
			if (pool.IsInitialised) {
				if (settings.ShowDefinition) {
					settings.DefinitionExpanded.TargetValue = EditorGUILayout.Foldout(settings.DefinitionExpanded, "Definition", true, this.boldFoldoutStyle);
					if (settings.DefinitionExpanded) {
						this.DrawInitialisedPoolDefinition(pool, settings.ShowDetails);
					}
				}

				if (settings.ShowStatistics) {
					settings.StatisticsExpanded.TargetValue = EditorGUILayout.Foldout(settings.StatisticsExpanded, "Statistics", true, this.boldFoldoutStyle);
					if (settings.StatisticsExpanded) {
						this.DrawInitialisedPoolStatistics(pool);
					}
				}
			}

			// If any of the other groups of fields are drawn above the pool settings, draw a header for the settings.
			if (pool.IsInitialised && (settings.ShowDefinition || settings.ShowStatistics)) {
				EditorGUILayout.LabelField("Settings", EditorStyles.boldLabel);
			}
			// Draw the main controls for the pool - this includes things that will be drawn only when the pool hasn't been initialised, as well as those that are drawn all the time.
			this.DrawPoolMain(pool, settings.ShowDetails);
		}

		private void DrawInitialisedPoolDefinition(TPool pool, bool drawAdvanced = true) {
			Contract.Requires(pool != null);
			Contract.Requires(pool.IsInitialised);

			// The definition cannot be changed, so disable the controls.
			EditorGUI.BeginDisabledGroup(true);
			this.poolDrawer.DrawPoolDefinition(pool, drawAdvanced);
			EditorGUI.EndDisabledGroup();
		}

		private void DrawInitialisedPoolStatistics(TPool pool) {
			Contract.Requires(pool != null);
			Contract.Requires(pool.IsInitialised);

			this.poolDrawer.DrawPoolStatistics(pool);
		}

		protected abstract void DrawPoolMain(TPool pool, bool drawAdvanced = true);

		protected void DrawSetting<T>(SerializedProperty property, Func<Rect, T> drawControl, Action<T> setValue) {
			//EditorGUI.showMixedValue = !pools.Select(kvp => currentValueSelector(kvp.Key, kvp.Value)).Unanimous();
			var rect = EditorGUILayout.GetControlRect(true);
			if (property != null) {
				EditorGUI.BeginProperty(rect, GUIContent.none, property);
			}

			EditorGUI.BeginChangeCheck();
			T newValue = drawControl(rect);
			if (EditorGUI.EndChangeCheck()) {
				// Record an undo state for the pools being edited.
				Undo.RecordObject(this.manager, "Change Pool Setting");

				// Apply the change in value to all pools (or pool settings) being edited.
				setValue(newValue);

				// Prefab override support.
				if (property != null) {
					// Ensure all pools being edited have their prefab state updated.
					foreach (var targetObject in property.serializedObject.targetObjects) {
						PrefabHelper.MarkPrefabChanged(targetObject);
					}
				}
			}
			if (property != null) {
				EditorGUI.EndProperty();
			}
		}
		#endregion

		private void ExpandAll(GameObject startingPoint = null) {
			this.ExpandCollapseAll(true, startingPoint);
		}

		private void CollapseAll(GameObject startingPoint = null) {
			this.ExpandCollapseAll(false, startingPoint);
		}

		private void ExpandCollapseAll(bool expanded, GameObject startingPoint = null) {
			this.helper.SetFoldoutStateRecursiveDownwards(startingPoint ?? this.manager.gameObject, expanded);

			if (startingPoint == null) {
				this.settings.LoosePoolContainerExpanded.TargetValue = expanded;
				foreach (var pool in this.OtherAttachedPools) {
					this.helper.GetContainerSettings(pool.transform).FoldoutOpen.TargetValue = expanded;
				}
			}
		}

		protected virtual bool CreatePool(Transform parent, TSource source, bool expand = true) {
			Contract.Requires(parent != null);

			// Check if a pool already exists using the specified source object. Duplicates aren't allowed.
			if (this.helper.IsSourceInUse(source)) {
				Debug.LogWarning($"The pool could not be created, as the source object ('{this.GetSourceName(source)}') is already assigned to another pool.");
				return false;
			}

			// Delay the creation of the pool until the next layout pass.
			this.delayedActions.Add(() => {
				this.CreatePoolInternal(parent, source, expand);
			});

			return true;
		}

		protected virtual TPool CreatePoolInternal(Transform parent, TSource source, bool expand = true) {
			Contract.Requires(parent != null);

			// Choose the name of the container that the pool resides on.
			string containerName = this.helper.GenerateContainerName(source);

			// Create the container object, and attach it to the parent transform.
			var container = new GameObject(containerName);
			container.transform.SetParent(parent, false);

			// Add the pool component, and set the source on it.
			var pool = container.AddComponent<TPool>();
			pool.Settings = this.CreatePoolSettingsClone(this.manager.DefaultPoolSettings);
			pool.Source = source;

			// Allow the creation of the pool to be undone.
			Undo.RegisterCreatedObjectUndo(container, "Create Pool");

			// Expand the parent container and the pool's container, if needed.
			if (expand) {
				this.helper.SetFoldoutStateRecursive(container, true);
				this.settings.PoolViewExpanded.TargetValue = true;
			}

			// By default, show the detailed settings on a new pool.
			this.helper.GetPoolSettings(pool).ShowDetails.TargetValue = true;

			return pool;
		}

		protected virtual TPool CreateEmptyPool(Transform parent) {
			var container = new GameObject("Empty Pool");
			container.transform.SetParent(parent, false);

			var newPool = container.AddComponent<TPool>();
			newPool.Settings = this.CreatePoolSettingsClone(this.manager.DefaultPoolSettings);
			newPool.InitialiseOnStart = false; // Disable initialise on start, since the source object won't have been chosen yet.

			// Allow the creation of the pool to be undone.
			Undo.RegisterCreatedObjectUndo(container, "Create Pool");

			this.helper.SetFoldoutStateRecursive(container, true);
			this.settings.PoolViewExpanded.TargetValue = true;
			this.helper.GetPoolSettings(newPool).ShowDetails.TargetValue = true;

			return newPool;
		}
		
		/// <summary>
		/// Creates a new container beneath the specified parent object.
		/// </summary>
		/// <param name="parent">The <see cref="Transform"/> of the object that the new container should be parented to.</param>
		/// <param name="name">The name of the container. The default value is "Unnamed".</param>
		private void CreateContainer(Transform parent, string name = "Unnamed") {
			this.delayedActions.Add(() => {
				this.helper.CreateContainer(parent, name);
				this.settings.ShowContainers.TargetValue = true;
				// TODO: Fix the renaming/editing. Currently unable to start editing with focus in the text field.
				//EditorGUIUtility.editingTextField = true;
				//EditorGUI.FocusTextInControl("ContainerName" + container.transform.GetHashCode());
				//this.containerNameBeingEdited = container.transform;
			});
		}

		/// <summary>
		/// Deletes the specified container game objects.
		/// </summary>
		/// <param name="containers"></param>
		/// <remarks>This method is delayed until the next <see cref="EventType.Layout"/> pass.</remarks>
		private void DeleteContainers(params GameObject[] containers) {
			this.delayedActions.Add(() => {
				this.helper.DeleteContainers(containers);
			});
		}

		/// <summary>
		/// When implemented in a derived class, creates a new instance of <typeparamref name="TPoolSettings"/> that is an exact copy of the specified settings.
		/// </summary>
		/// <param name="settings">The settings to copy.</param>
		/// <returns>A new instance of <typeparamref name="TPoolSettings"/> that is an exact copy of <paramref name="settings"/>.</returns>
		protected abstract TPoolSettings CreatePoolSettingsClone(TPoolSettings settings);

		protected virtual string GetSourceName(TSource source) {
			return this.helper.GetSourceName(source);
		}

	}

}