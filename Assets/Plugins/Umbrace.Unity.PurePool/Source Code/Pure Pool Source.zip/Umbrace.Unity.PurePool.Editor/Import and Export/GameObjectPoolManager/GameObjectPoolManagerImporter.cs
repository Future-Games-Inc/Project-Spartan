﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class GameObjectPoolManagerImporter : PoolManagerImporter<GameObjectPoolManager, GameObjectPoolManagerSettings, GameObjectPool, GameObjectPoolSettings, ExportedGameObjectManagerSettings, ExportedGameObjectPoolSettings, GameObjectPoolImporter, GameObject, GameObject> {
		
		/// <inheritdoc />
		protected override Version MinimumSupportedVersion => new Version(1, 0);

		/// <inheritdoc />
		protected override Version MaximumSupportedVersion => new Version(1, 0);

		/// <inheritdoc />
		protected override string ExportSubType => Editor.ExportSubType.GameObjectPoolManager;

		/// <inheritdoc />
		protected override string PoolManagerTypeName => nameof(GameObjectPoolManager);

		/// <inheritdoc />
		protected override string PoolTypeName => nameof(GameObjectPool);
		
		/// <inheritdoc />
		protected override GameObjectPoolImporter CreatePoolImporter() {
			return new GameObjectPoolImporter();
		}
		
	}

}