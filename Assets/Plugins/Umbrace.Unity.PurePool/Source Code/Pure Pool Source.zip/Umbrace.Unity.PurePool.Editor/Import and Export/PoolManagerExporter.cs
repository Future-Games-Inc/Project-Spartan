using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal abstract class PoolManagerExporter<TManager, TManagerSettings, TPool, TPoolSettings, TExportedManagerSettings, TExportedPoolSettings, TExporter, TSource, TInstance>
		where TManager : PoolManagerBase<TManagerSettings, TPool, TPoolSettings, TSource, TInstance>
		where TManagerSettings : PoolManagerSettings<TPoolSettings, TSource>
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TPool : PoolBase<TSource, TInstance, TPoolSettings>
		where TExportedManagerSettings : ExportedManagerSettings<TSource, TPoolSettings, TManagerSettings, TExportedPoolSettings>
		where TExportedPoolSettings : ExportedPoolSettings<TSource, TPoolSettings>
		where TExporter : PoolExporter<TSource, TInstance, TPoolSettings, TExportedPoolSettings, TPool> {

		/// <summary>
		/// When overridden in a derived class, gets the version number of this exporter.
		/// </summary>
		protected abstract Version Version { get; }

		/// <summary>
		/// When overridden in a derived class, gets the export sub-type of this exporter.
		/// </summary>
		protected abstract string ExportSubType { get; }

		/// <summary>
		/// When overridden in a derived class, gets the display name of the type of pool manager that this exporter supports.
		/// </summary>
		protected abstract string PoolManagerTypeName { get; }

		/// <summary>
		/// Exports the settings from the specified manager to the given file.
		/// </summary>
		/// <param name="path">The path to the file to export to.</param>
		/// <param name="manager">The manager to export the settings from.</param>
		/// <param name="mode">The settings that should be exported from the manager.</param>
		public void Export(string path, TManager manager, ManagerExportMode mode) {
			Contract.RequiresNotNull(path, nameof(path));
			Contract.RequiresNotNull(manager, nameof(manager));

			if (mode == ManagerExportMode.ManagerSettingsOnly) {
				this.ExportManagerSettingsOnly(path, manager);
			}
			else if (mode == ManagerExportMode.ManagerSettingsWithPools) {
				this.ExportManagerWithPools(path, manager);
			}
		}

		private void ExportManagerSettingsOnly(string path, TManager manager) {
			var exportMetadata = new ManagerExportMetadata(this.Version, manager.name, manager.transform.GetPath(), DateTimeOffset.Now, this.ExportSubType);
			var exportData = this.CreateExportedManagerSettings(exportMetadata, manager.Settings);

			string json = JsonUtility.ToJson(exportData, true);

			try {
				File.WriteAllText(path, json);

				string message = $"Successfully exported {this.PoolManagerTypeName} settings for \"{exportMetadata.ManagerName}\".{Environment.NewLine}{Environment.NewLine}" +
								$"Export Date: {exportMetadata.ExportDateTime}{Environment.NewLine}" +
								$"Exported From: {exportMetadata.ManagerGameObjectPath}";
				EditorUtility.DisplayDialog("Export Successful", message, "OK");
			} catch (Exception ex) {
				string message = $"Failed to export {this.PoolManagerTypeName} settings for \"{exportMetadata.ManagerName}\".{Environment.NewLine}{Environment.NewLine}" +
								$"Reason: {ex}";
				EditorUtility.DisplayDialog("Export Failed", message, "OK");
			}
		}

		private void ExportManagerWithPools(string path, TManager manager) {
			var pools = manager.FindChildPools(includeInactive: true);
			var poolExporter = this.CreatePoolExporter();
			var exportedPoolSettings = pools.Select(p => poolExporter.CreateExportData(p));

			var exportMetadata = new ManagerExportMetadata(this.Version, manager.name, manager.transform.GetPath(), DateTimeOffset.Now, this.ExportSubType);
			var exportData = this.CreateExportedManagerSettings(exportMetadata, manager.Settings, exportedPoolSettings);

			string json = JsonUtility.ToJson(exportData, true);

			try {
				File.WriteAllText(path, json);

				string message = $"Successfully exported {this.PoolManagerTypeName} settings for \"{exportMetadata.ManagerName}\".{Environment.NewLine}{Environment.NewLine}" +
								$"Export Date: {exportMetadata.ExportDateTime}{Environment.NewLine}" +
								$"Exported From: {exportMetadata.ManagerGameObjectPath}";
				EditorUtility.DisplayDialog("Export Successful", message, "OK");
			} catch (Exception ex) {
				string message = $"Failed to export {this.PoolManagerTypeName} settings for \"{exportMetadata.ManagerName}\".{Environment.NewLine}{Environment.NewLine}" +
								$"Reason: {ex}";
				EditorUtility.DisplayDialog("Export Failed", message, "OK");
			}
		}

		/// <summary>
		/// When overridden in a derived class, creates the exporter for individual pools.
		/// </summary>
		/// <returns>An instance of <typeparamref name="TExporter"/> that can export individual pools.</returns>
		protected abstract TExporter CreatePoolExporter();

		/// <summary>
		/// When overridden in a derived class, creates the export data for the specified metadata and manager settings.
		/// </summary>
		/// <param name="metadata">The export metadata.</param>
		/// <param name="managerSettings">The manager settings.</param>
		/// <returns></returns>
		protected abstract TExportedManagerSettings CreateExportedManagerSettings(ManagerExportMetadata metadata, TManagerSettings managerSettings);

		/// <summary>
		/// When overridden in a derived class, creates the export data for the specified metadata, manager settings, and pool settings.
		/// </summary>
		/// <param name="metadata">The export metadata.</param>
		/// <param name="managerSettings">The manager settings.</param>
		/// <param name="poolSettings">The individual pool settings.</param>
		/// <returns></returns>
		protected abstract TExportedManagerSettings CreateExportedManagerSettings(ManagerExportMetadata metadata, TManagerSettings managerSettings, IEnumerable<TExportedPoolSettings> poolSettings);

	}

}