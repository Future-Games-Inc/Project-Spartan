﻿using System;
using System.Collections.Generic;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class ExportedComponentManagerSettings : ExportedManagerSettings<Type, ComponentPoolSettings, ComponentPoolManagerSettings, ExportedComponentPoolSettings> {
		
		public ExportedComponentManagerSettings(ManagerExportMetadata metadata, ComponentPoolManagerSettings managerSettings) : base(metadata, managerSettings) {
			
		}

		public ExportedComponentManagerSettings(ManagerExportMetadata metadata, ComponentPoolManagerSettings managerSettings, IEnumerable<ExportedComponentPoolSettings> poolSettings) 
			: base(metadata, managerSettings, poolSettings) {
			
		}

	}

}