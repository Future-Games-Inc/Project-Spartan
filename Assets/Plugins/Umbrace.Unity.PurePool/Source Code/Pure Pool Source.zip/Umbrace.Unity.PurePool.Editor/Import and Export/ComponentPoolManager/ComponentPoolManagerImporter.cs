﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class ComponentPoolManagerImporter : PoolManagerImporter<ComponentPoolManager, ComponentPoolManagerSettings, ComponentPool, ComponentPoolSettings, ExportedComponentManagerSettings, ExportedComponentPoolSettings, ComponentPoolImporter, Type, Component> {
		
		/// <inheritdoc />
		protected override Version MinimumSupportedVersion => new Version(1, 0);

		/// <inheritdoc />
		protected override Version MaximumSupportedVersion => new Version(1, 0);

		/// <inheritdoc />
		protected override string ExportSubType => Editor.ExportSubType.ComponentPoolManager;

		/// <inheritdoc />
		protected override string PoolManagerTypeName => nameof(ComponentPoolManager);

		/// <inheritdoc />
		protected override string PoolTypeName => nameof(ComponentPool);

		/// <inheritdoc />
		protected override ComponentPoolImporter CreatePoolImporter() {
			return new ComponentPoolImporter();
		}

	}

}