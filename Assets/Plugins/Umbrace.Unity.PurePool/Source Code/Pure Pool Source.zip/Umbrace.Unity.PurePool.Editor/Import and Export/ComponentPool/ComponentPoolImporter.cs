﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal class ComponentPoolImporter : PoolImporter<Type, Component, ComponentPoolSettings, ExportedComponentPoolSettings, ComponentPool> {

		/// <inheritdoc />
		protected override Version MinimumSupportedVersion => new Version(1, 0);

		/// <inheritdoc />
		protected override Version MaximumSupportedVersion => new Version(1, 0);

		/// <inheritdoc />
		protected override string ExportSubType => Editor.ExportSubType.ComponentPool;

		/// <inheritdoc />
		protected override string PoolTypeName => nameof(ComponentPool);

	}

}