﻿using System;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class ExportedComponentPoolSettings : ExportedPoolSettings<Type, ComponentPoolSettings> {

		public ExportedComponentPoolSettings(PoolExportMetadata metadata, ComponentPoolSettings settings) : base(metadata, settings) {
			
		}

	}

}