﻿namespace Umbrace.Unity.PurePool.Editor {

	internal static class ExportSubType {

		internal static readonly string GameObjectPool = "GameObjectPool";
		internal static readonly string ComponentPool = "ComponentPool";
		internal static readonly string GameObjectPoolManager = "GameObjectPoolManager";
		internal static readonly string ComponentPoolManager = "ComponentPoolManager";

	}

}