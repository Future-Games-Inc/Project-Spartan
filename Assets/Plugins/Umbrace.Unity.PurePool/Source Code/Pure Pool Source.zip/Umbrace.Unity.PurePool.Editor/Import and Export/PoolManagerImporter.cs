using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	internal abstract class PoolManagerImporter<TManager, TManagerSettings, TPool, TPoolSettings, TExportedManagerSettings, TExportedPoolSettings, TImporter, TSource, TInstance>
		where TManager : PoolManagerBase<TManagerSettings, TPool, TPoolSettings, TSource, TInstance>
		where TManagerSettings : PoolManagerSettings<TPoolSettings, TSource>
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TPool : PoolBase<TSource, TInstance, TPoolSettings>
		where TExportedManagerSettings : ExportedManagerSettings<TSource, TPoolSettings, TManagerSettings, TExportedPoolSettings>
		where TExportedPoolSettings : ExportedPoolSettings<TSource, TPoolSettings>
		where TImporter : PoolImporter<TSource, TInstance, TPoolSettings, TExportedPoolSettings, TPool> {

		private enum SkipMode {

			CreateAll,
			SkipAll,
			Prompt

		}

		/// <summary>
		/// When overridden in a derived class, gets the minimum version number that this importer supports.
		/// </summary>
		protected abstract Version MinimumSupportedVersion { get; }

		/// <summary>
		/// When overridden in a derived class, gets the maximum version number that this importer supports.
		/// </summary>
		protected abstract Version MaximumSupportedVersion { get; }

		/// <summary>
		/// When overridden in a derived class, gets the export sub-type that this importer supports.
		/// </summary>
		protected abstract string ExportSubType { get; }

		/// <summary>
		/// When overridden in a derived class, gets the display name of the type of pool manager that this importer supports.
		/// </summary>
		protected abstract string PoolManagerTypeName { get; }

		/// <summary>
		/// When overridden in a derived class, gets the display name of the type of pool that this importer supports.
		/// </summary>
		protected abstract string PoolTypeName { get; }

		/// <summary>
		/// Imports the settings from the specified file into the given manager.
		/// </summary>
		/// <param name="path">The path to the file to import.</param>
		/// <param name="manager">The manager to import the settings into.</param>
		public void Import(string path, TManager manager) {
			Contract.RequiresNotNull(path, nameof(path));
			Contract.RequiresNotNull(manager, nameof(manager));

			string message;
			bool importPools = false;

			TExportedManagerSettings importData = this.ReadImportData(path);

			Debug.Log($"Importing manager settings. Version {importData.Metadata.Version}.");

			// Ensure the settings being imported are from a supported version.
			try {
				this.EnsureVersion(importData.Metadata.Version);
			}
			catch (VersionNotSupportedException) {
				message = $"Failed to import the manager settings. The specified file contains settings in an unsupported version.{Environment.NewLine}{Environment.NewLine}" +
						$"File Version: {importData.Metadata.Version}{Environment.NewLine}" +
						$"Supported Versions: {this.MinimumSupportedVersion} to {this.MaximumSupportedVersion}{Environment.NewLine}" +
						$"File: {path}";
				Debug.LogError(message);
				EditorUtility.DisplayDialog("Import Error", message, "OK");
				return;
			}

			// Ensure the settings are for a supported manager component.
			try {
				this.EnsureExportType(importData.Metadata.ExportType, importData.Metadata.ExportSubType);
			}
			catch (ExportTypeMismatchException) {
				message = $"Failed to import the manager settings. The specified file does not contain settings for a {this.PoolManagerTypeName}.{Environment.NewLine}{Environment.NewLine}" +
						$"File Version: {importData.Metadata.Version}{Environment.NewLine}" +
						$"Export Type: {importData.Metadata.ExportType}{Environment.NewLine}" +
						$"Export Sub-Type: {importData.Metadata.ExportSubType}{Environment.NewLine}" +
						$"File: {path}";
				Debug.LogError(message);
				EditorUtility.DisplayDialog("Import Error", message, "OK");
				return;
			}

			// If individual pool settings are present, ask if the user wants to import those too.
			if (importData.PoolSettings.Count > 0) {
				message = $"The specified file contains settings for the manager, as well as settings for {importData.PoolSettings.Count} individual pool(s) under the manager.{Environment.NewLine}{Environment.NewLine}" +
						$"Do you wish to import only the settings for the manager, or the settings for the pools as well?";
				var result = EditorUtility.DisplayDialogComplex("Import Settings", message, "Import Manager", "Import Manager And Pools", "Cancel");
				if (result == 2) return;
				importPools = result == 1;
			}

			message = $"Importing will overwrite the existing settings of the manager. " +
					$"Are you sure you want to import the {this.PoolManagerTypeName} settings?{Environment.NewLine}{Environment.NewLine}" +
					$"Importing From: {path}{Environment.NewLine}" +
					$"Importing To: {manager.transform.GetPath()}{Environment.NewLine}{Environment.NewLine}" +
					$"Export Date: {importData.Metadata.ExportDateTime}{Environment.NewLine}" +
					$"Exported From: {importData.Metadata.ManagerGameObjectPath}";
			if (EditorUtility.DisplayDialog("Import Confirmation", message, "Import", "Cancel")) {
				// Import the manager's settings.
				this.ImportManagerSettings(importData, manager);

				// Optionally, import settings for individual pools too.
				if (importPools) {
					//bool skipMissingGameObject = true;

					//var missingGameObjects = this.FindMissingGameObjects(importData.PoolSettings);
					//if (missingGameObjects.Any()) {
					//	message = $"The specified file contains individual pool settings for {missingGameObjects.Count()} pool(s) that no longer exist(s).{Environment.NewLine}{Environment.NewLine}" +
					//			$"Do you wish to re-create the missing pools and their {nameof(GameObject)} containers?";
					//	var result = EditorUtility.DisplayDialogComplex("Missing Pools", message, "Re-create All", "Skip All", "Decide Individually");

					//	if (result == 0) this.CreateGameObjects(missingGameObjects);
					//	if (result == 2) skipMissingGameObject = false;
					//}

					SkipMode skipMode = SkipMode.Prompt;

					// Check for any game objects with missing pool components.
					var missingComponents = this.FindMissingPoolComponents(importData.PoolSettings);
					if (missingComponents.Any()) {
						message = $"The specified file contains individual pool settings for {missingComponents.Count()} pool(s) that no longer exist(s).{Environment.NewLine}{Environment.NewLine}" +
								$"Do you wish to re-create the missing pools?";
						var result = EditorUtility.DisplayDialogComplex("Missing Pools", message, "Re-create All", "Skip All", "Decide Individually");

						if (result == 0) skipMode = SkipMode.CreateAll;
						if (result == 1) skipMode = SkipMode.SkipAll;
						if (result == 2) skipMode = SkipMode.Prompt;
					}

					this.ImportPoolSettings(importData, skipMode);
				}

				message = $"Successfully imported {this.PoolManagerTypeName} settings to \"{manager.name}\".{Environment.NewLine}{Environment.NewLine}" +
						$"Export Date: {importData.Metadata.ExportDateTime}{Environment.NewLine}" +
						$"Exported From: {importData.Metadata.ManagerGameObjectPath}";
				EditorUtility.DisplayDialog("Import Successful", message, "OK");
			}
		}

		private void EnsureVersion(Version version) {
			// Ensure the settings being imported are from a supported version.
			if (version < this.MinimumSupportedVersion || version > this.MaximumSupportedVersion) {
				string message = $"The specified file contains settings in an unsupported version.{Environment.NewLine}{Environment.NewLine}" +
								$"File Version: {version}{Environment.NewLine}" +
								$"Supported Versions: {this.MinimumSupportedVersion} to {this.MaximumSupportedVersion}{Environment.NewLine}";
				throw new VersionNotSupportedException(message);
			}
		}

		private void EnsureExportType(string exportType, string exportSubType) {
			// Ensure the settings are for a supported manager component.
			if (exportType != ExportType.PoolManager || exportSubType != this.ExportSubType) {
				string message = $"The specified file does not contain settings for a {this.PoolManagerTypeName} manager.{Environment.NewLine}{Environment.NewLine}" +
								$"Export Type: {exportType}{Environment.NewLine}" +
								$"Export Sub-Type: {exportSubType}";
				throw new ExportTypeMismatchException(message);
			}
		}

		private TExportedManagerSettings ReadImportData(string path) {
			string json = File.ReadAllText(path);

			return JsonUtility.FromJson<TExportedManagerSettings>(json);
		}

		private void ImportManagerSettings(TExportedManagerSettings importData, TManager manager) {
			Undo.RecordObject(manager, "Import Manager Settings");
			string managerSettings = JsonUtility.ToJson(importData.ManagerSettings);
			JsonUtility.FromJsonOverwrite(managerSettings, manager.Settings);
		}

		private void ImportPoolSettings(TExportedManagerSettings importData, SkipMode skipMode) {
			foreach (TExportedPoolSettings poolSettings in importData.PoolSettings) {
				this.ImportPoolSettings(poolSettings, skipMode);
			}
		}

		private void ImportPoolSettings(TExportedPoolSettings data, SkipMode skipMode) {
			var gameObject = GameObject.Find(data.Metadata.PoolGameObjectPath);

			// Skip the exported pools that don't have a matching GameObject in the scene.
			if (gameObject == null) {
				Debug.LogWarning($"Couldn't import pool settings for '{data.Metadata.PoolName}'. " +
								$"The {nameof(GameObject)} containing the pool could not be found at '{data.Metadata.PoolGameObjectPath}'.");
				return;
			}

			var component = gameObject.GetComponent<TPool>();

			if (component == null && skipMode == SkipMode.CreateAll) {
				component = gameObject.AddComponent<TPool>();
			} else if (component == null && skipMode == SkipMode.Prompt) {
				string message = $"The specified file contains individual pool settings for a pool that no longer exists." +
								$"Do you wish to re-create the missing pool?{Environment.NewLine}{Environment.NewLine}" +
								$"Pool Name: {data.Metadata.PoolName}{Environment.NewLine}" +
								$"Pool Path: {data.Metadata.PoolGameObjectPath}";
				if (EditorUtility.DisplayDialog("Missing Pool", message, "Re-create Pool", "Skip")) {
					component = gameObject.AddComponent<TPool>();
				}
			}

			// Skip the exported pools that don't have a pool component on their matching GameObject in the scene.
			if (component == null) {
				Debug.LogWarning($"Couldn't import pool settings for '{data.Metadata.PoolName}'. " +
								$"The {this.PoolTypeName} component could not be found on the {nameof(GameObject)} at '{data.Metadata.PoolGameObjectPath}'.");
				return;
			}

			try {
				var importer = this.CreatePoolImporter();
				importer.ImportSettings(data, component);

				Debug.Log($"Imported pool settings for {data.Metadata.PoolGameObjectPath}.");
			} catch (VersionNotSupportedException ex) {
				Debug.LogWarning(ex.Message);
			} catch (ExportTypeMismatchException ex) {
				Debug.LogWarning(ex.Message);
			}
		}

		private IEnumerable<TExportedPoolSettings> FindMissingGameObjects(IEnumerable<TExportedPoolSettings> poolSettings) {
			// Find the exported pool settings that don't have a matching GameObject in the scene.
			return poolSettings.Where(pool => GameObject.Find(pool.Metadata.PoolGameObjectPath) == null);
		}

		private IEnumerable<TExportedPoolSettings> FindMissingPoolComponents(IEnumerable<TExportedPoolSettings> poolSettings) {
			// Find the exported pool settings that don't have a pool component on their matching GameObject in the scene.
			return poolSettings.Where(pool => {
				var gameObject = GameObject.Find(pool.Metadata.PoolGameObjectPath);
				return gameObject != null && gameObject.GetComponent<TPool>() == null;
			});
		}

		//private void CreateGameObjects(IEnumerable<TExportedPoolSettings> missingPoolSettings) {
		//	foreach (var data in missingPoolSettings) {
		//		IEnumerable<string> transformPath = Extensions.ExpandTransformPath(data.Metadata.PoolGameObjectPath);

		//		Transform parent = null;
		//		foreach (var transformName in transformPath) {
		//			if (parent == null) {
		//				var root = GameObject.Find(transformName)?.transform; // TODO: What if GameObject.Find returns a non-root object?
		//				parent = root ?? new GameObject(transformName).transform;
		//				continue;
		//			}

		//			var child = parent.Find(transformName);
		//			if (child == null) {
		//				child = new GameObject(transformName).transform;
		//				child.SetParent(parent, false);
		//			}

		//			parent = child;
		//		}
		//	}
		//}

		/// <summary>
		/// When overridden in a derived class, creates the importer for individual pools.
		/// </summary>
		/// <returns>An instance of <typeparamref name="TImporter"/> that can import individual pools.</returns>
		protected abstract TImporter CreatePoolImporter();

	}

}