using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal class PoolExportMetadata {

		[SerializeField, HideInInspector]
		private SerialisableVersion version;

		[SerializeField, HideInInspector]
		private string exportType = "Pool";

		[SerializeField, HideInInspector]
		private string exportSubType;

		[SerializeField, HideInInspector]
		private string poolName;

		[SerializeField, HideInInspector]
		private string poolGameObjectPath;

		[SerializeField, HideInInspector]
		private SerialisableDateTimeOffset exportDateTime;

		public Version Version => this.version;

		public string ExportType => this.exportType;

		public string ExportSubType => this.exportSubType;

		public string PoolName => this.poolName;

		public string PoolGameObjectPath => this.poolGameObjectPath;

		public DateTimeOffset ExportDateTime => this.exportDateTime;

		public PoolExportMetadata(Version version, string poolName, string poolGameObjectPath, DateTimeOffset exportDateTime, string exportSubType) {
			this.version = version;
			this.poolName = poolName;
			this.poolGameObjectPath = poolGameObjectPath;
			this.exportDateTime = exportDateTime;
			this.exportSubType = exportSubType;
		}

	}

}