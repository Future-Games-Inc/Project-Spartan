﻿using System;

namespace Umbrace.Unity.PurePool.Editor {

	public class ExportTypeMismatchException : Exception {

		public ExportTypeMismatchException() {
			
		}

		public ExportTypeMismatchException(string message) : base(message) {
			
		}

	}

}