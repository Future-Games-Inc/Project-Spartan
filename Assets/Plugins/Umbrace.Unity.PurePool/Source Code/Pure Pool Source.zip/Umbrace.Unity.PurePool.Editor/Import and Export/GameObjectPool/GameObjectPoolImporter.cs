﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {
	
	internal class GameObjectPoolImporter : PoolImporter<GameObject, GameObject, GameObjectPoolSettings, ExportedGameObjectPoolSettings, GameObjectPool> {

		/// <inheritdoc />
		protected override Version MinimumSupportedVersion => new Version(1, 0);

		/// <inheritdoc />
		protected override Version MaximumSupportedVersion => new Version(1, 0);

		/// <inheritdoc />
		protected override string ExportSubType => Editor.ExportSubType.GameObjectPool;

		/// <inheritdoc />
		protected override string PoolTypeName => nameof(GameObjectPool);

	}

}