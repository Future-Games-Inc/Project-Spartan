﻿using System;
using System.Collections.Generic;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[Serializable]
	internal abstract class ExportedManagerSettings<TSource, TPoolSettings, TManagerSettings, TExportedPoolSettings>
		where TManagerSettings : PoolManagerSettings<TPoolSettings, TSource>
		where TPoolSettings : SharedPoolSettings<TSource>, new()
		where TExportedPoolSettings : ExportedPoolSettings<TSource, TPoolSettings> {

		[SerializeField, HideInInspector]
		private ManagerExportMetadata metadata;

		[SerializeField, HideInInspector]
		private TManagerSettings managerSettings;

		[SerializeField, HideInInspector]
		private List<TExportedPoolSettings> poolSettings;

		public ManagerExportMetadata Metadata => this.metadata;

		public TManagerSettings ManagerSettings => this.managerSettings;

		public List<TExportedPoolSettings> PoolSettings => this.poolSettings;

		protected ExportedManagerSettings(ManagerExportMetadata metadata, TManagerSettings managerSettings) {
			this.metadata = metadata;
			this.managerSettings = managerSettings;
			this.poolSettings = new List<TExportedPoolSettings>();
		}

		protected ExportedManagerSettings(ManagerExportMetadata metadata, TManagerSettings managerSettings, IEnumerable<TExportedPoolSettings> poolSettings) {
			this.metadata = metadata;
			this.managerSettings = managerSettings;
			this.poolSettings = new List<TExportedPoolSettings>(poolSettings);
		}

	}

}