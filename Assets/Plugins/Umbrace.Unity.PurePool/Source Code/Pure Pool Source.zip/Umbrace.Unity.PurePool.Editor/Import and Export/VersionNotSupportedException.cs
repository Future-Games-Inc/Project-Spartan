﻿using System;

namespace Umbrace.Unity.PurePool.Editor {

	public class VersionNotSupportedException : Exception {

		public VersionNotSupportedException() : base() {
			
		}

		public VersionNotSupportedException(string message) : base(message) {

		}

	}

}