﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

using UnityEditor;
using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	using TypedHelper = Helper<GameObjectPoolManager, GameObjectPoolManagerSettings, GameObjectManagerEditorSettings, GameObjectPool, GameObjectPoolSettings, GameObject, GameObject>;
	using TypedPoolDrawer = PoolDrawer<GameObjectPool, GameObject, GameObject, GameObjectPoolSettings>;

	[CustomEditor(typeof(GameObjectPoolManager))]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal class GameObjectPoolManagerEditor : BasePoolManagerEditor<GameObjectPoolManager, GameObjectPoolManagerSettings, GameObjectManagerEditorSettings, GameObjectPool, GameObjectPoolSettings, GameObject, GameObject> {

		#region Properties.
		private new GameObjectPoolManager Manager => (GameObjectPoolManager)this.target;
		
		protected override string DefaultSettingsHelpText => "The default settings will be used when a new pool is created automatically. " +
															"This could be when you drop a GameObject on to the inspector, or when " +
															"an instance of an object is requested from the manager at runtime, and no pool exists for it.";
		#endregion

		#region BasePoolManagerEditor method overrides.
		protected override TypedHelper CreateHelper() => new GameObjectHelper(this.Manager);

		protected override TypedPoolDrawer CreatePoolDrawer() {
			return new ManagerGameObjectPoolDrawer(this.Manager, (pool, source) => this.helper.ChangeSourceObject(pool, source));
		}

		protected override TypedPoolDrawer CreateDefaultSettingsDrawer() {
			return new ManagerGameObjectPoolDrawer(this.Manager, this.serializedObject, "settings.defaultPoolSettings") {
				DrawSourceObject = false // The default settings have no need for a source object.
			};
		}
		
		public override void OnInspectorGUI() {
			base.OnInspectorGUI();

			// When the Object Selector window is closed, update the source object on the last-created pool.
			if (Event.current.type == EventType.ExecuteCommand && Event.current.commandName == "ObjectSelectorClosed") {
				if (this.lastCreatedPool != null) {
					GameObject selectedObject = (GameObject)EditorGUIUtility.GetObjectPickerObject();
					if (this.helper.ChangeSourceObject(this.lastCreatedPool, selectedObject)) {
						// If the source object was changed, reset the last created pool.
						this.lastCreatedPool = null;
					} else {
						// If the source object could not be changed, re-display the object picker.
						// Has to be delayed, or it freezes Unity.
						this.delayedActions.Add(() => EditorGUIUtility.ShowObjectPicker<GameObject>(null, true, "", 0));
					}

					Event.current.Use();
				}
			}
		}

		/// <inheritdoc />
		protected override void DrawPoolMain(GameObjectPool pool, bool drawAdvanced = true) {
			this.poolDrawer.DrawPool(pool, "currentSettings", drawAdvanced);
		}

		protected override void DragDropContainerFoldout(GameObjectPool pool, Rect rect, Transform container) {
			bool allowMultipleDrop = pool == null;
			EditorGUIHelper.DragDrop<GameObject>(rect, allowMultipleDrop, true, DragAndDropVisualMode.Copy, (gameObjects, nonGameObjects) => {
				if (pool != null) {
					GameObject gameObject = gameObjects.First();
					this.helper.ChangeSourceObject(pool, gameObject);
				} else {
					foreach (GameObject gameObject in gameObjects) {
						this.CreatePool(container, gameObject);
					}
				}
			});
		}

		protected override void DragDropOverallFoldout(Rect rect) {
			EditorGUIHelper.DragDrop<GameObject>(rect, true, true, DragAndDropVisualMode.Copy, (gameObjects, nonGameObjects) => {
				// Create new pools for each game object.
				foreach (GameObject gameObject in gameObjects) {
					this.CreatePool(this.Manager.transform, gameObject);
				}

				// If there were any non-poolable objects dropped, display a warning message.
				if (nonGameObjects.Length > 0) {
					Debug.LogWarning($"The following objects were dropped on to the {nameof(GameObjectPoolManager)}, but are not poolable: " + string.Join(", ", nonGameObjects.Select(o => o.name + " (" + o.GetType() + ")").ToArray()));
				}
			});
		}

		protected override void QuickAddField() {
			var obj = (GameObject)EditorGUILayout.ObjectField("Quick Add (Drag/Drop)", null, typeof(GameObject), true);

			if (obj != null) {
				this.CreatePool(this.Manager.transform, obj);
			}
		}

		protected override GameObjectPoolSettings CreatePoolSettingsClone(GameObjectPoolSettings settings) {
			return new GameObjectPoolSettings(settings);
		}
		
		protected override GameObjectPool CreateEmptyPool(Transform parent) {
			GameObjectPool newPool = base.CreateEmptyPool(parent);

			// Display the object picker to let the user choose the object to be pooled.
			this.lastCreatedPool = newPool;
			EditorGUIUtility.ShowObjectPicker<GameObject>(null, true, "", 0);

			return newPool;
		}
		#endregion

		#region Exporting.
		[MenuItem("CONTEXT/GameObjectPoolManager/Export Manager Settings")]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void ExportManagerSettings(MenuCommand menuCommand) {
			var manager = menuCommand.context as GameObjectPoolManager;
			if (manager == null) return;

			// Determine which export mode that user wishes to use.
			string message = $"Please choose whether you wish to export only the manager's settings, or whether you wish to export the settings of the pools beneath the manager too.";
			int result = EditorUtility.DisplayDialogComplex("Export Mode", message, "Export Settings", "Export Pools", "Cancel");

			// Cancel was chosen.
			if (result == 2) return;

			var exportMode = result == 0 ? ManagerExportMode.ManagerSettingsOnly : ManagerExportMode.ManagerSettingsWithPools;

			// Choose the file to save the pool settings to.
			string path = EditorUtility.SaveFilePanel("Export Manager Settings", String.Empty, manager.name, "json");

			if (path.Length != 0) {
				var exporter = new GameObjectPoolManagerExporter();
				exporter.Export(path, manager, exportMode);
			}
		}

		[MenuItem("CONTEXT/GameObjectPoolManager/Export Manager Settings", true)]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static bool ValidateExportManagerSettings() {
			// Only allow exporting of settings when a single pool is selected.
			return Selection.objects.Length == 1;
		}
		#endregion

		#region Importing.
		[MenuItem("CONTEXT/GameObjectPoolManager/Import Manager Settings")]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static void ImportManagerSettings(MenuCommand menuCommand) {
			var manager = menuCommand.context as GameObjectPoolManager;
			if (manager == null) return;

			// Choose the file to load the pool settings from.
			string path = EditorUtility.OpenFilePanel("Import Manager Settings", String.Empty, "json");

			if (path.Length != 0) {
				var importer = new GameObjectPoolManagerImporter();
				importer.Import(path, manager);
			}
		}

		[MenuItem("CONTEXT/GameObjectPoolManager/Import Pool Settings", true)]
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private static bool ValidateImportManagerSettings() {
			// Only allow importing of settings when a single pool is selected.
			return Selection.objects.Length == 1;
		}
		#endregion

	}

}