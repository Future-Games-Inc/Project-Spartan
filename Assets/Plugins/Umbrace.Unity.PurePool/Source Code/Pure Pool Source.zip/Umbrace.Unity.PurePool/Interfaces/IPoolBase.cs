using System;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// An interface that defines the behaviour and properties of a serialisable object pool.
	/// </summary>
	public interface IPoolBase : IObjectPool {

		#region Properties.
		/// <summary>
		/// Gets a value indicating whether the pool has been initialised.
		/// </summary>
		bool IsInitialised { get; }

		/// <summary>
		/// Gets an object containing general operational statistics about the pool.
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		PoolStatistics Statistics { get; }

		/// <summary>
		/// <para>Gets a value indicating whether an instance can be acquired from the pool.</para>
		/// <para>An instance can be acquired when the pool contains at least one instance, or when <see cref="IObjectPool.InstantiateWhenEmpty"/> is <see langword="true"/>.</para>
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		/// <seealso cref="PoolBase{TSource, TInstance, TSettings}.IsEmpty"/>
		/// <seealso cref="IObjectPool.InstantiateWhenEmpty"/>
		/// <seealso cref="PoolBase{TSource, TInstance, TSettings}.CanAcquireChanged"/>
		bool CanAcquire { get; }
		#endregion

		#region Events.
		/// <summary>
		/// Occurs when the pool is initialised.
		/// </summary>
		event EventHandler Initialised;

		/// <summary>
		/// Occurs when the pool is destroyed.
		/// </summary>
		event EventHandler Destroyed;

		/// <summary>
		/// Occurs when the value of <see cref="CanAcquire"/> changes.
		/// </summary>
		/// <seealso cref="CanAcquire"/>
		event EventHandler<PoolCanAcquireChangedEventArgs> CanAcquireChanged;

		/// <summary>
		/// Occurs when <see cref="IObjectPool.Count"/> changes.
		/// </summary>
		/// <seealso cref="IObjectPool.Count"/>
		event EventHandler<PoolCountChangedEventArgs> CountChanged;
		#endregion

		#region Methods.
		/// <summary>
		/// Initialises the pool, populating it with the initial number of objects.
		/// </summary>
		void Initialise();
		#endregion

	}

}