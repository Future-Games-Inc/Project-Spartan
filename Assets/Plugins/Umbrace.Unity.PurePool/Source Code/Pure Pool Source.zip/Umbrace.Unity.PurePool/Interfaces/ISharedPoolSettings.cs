﻿using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// An interface that defines the shared settings that can be changed on a <see cref="GameObject"/> pool and a <see cref="Component"/> pool.
	/// </summary>
	public interface ISharedPoolSettings {
		
		/// <summary>
		/// Gets or sets a value indicating whether pooling is enabled.
		/// </summary>
		bool Enabled { get; set; }

		/// <summary>
		/// Gets or sets the level of log messaging that the pool will output.
		/// </summary>
		LogLevel LogMessages { get; set; }

		/// <summary>
		/// Gets or sets the modes in which pooled objects are notified of their acquisition from, and release to, the pool.
		/// </summary>
		NotificationMode NotificationMode { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether the pool should persist between scene changes.
		/// </summary>
		bool DontDestroyOnLoad { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether to instantiate a new object when the pool is empty, and an attempt is made to acquire from the pool.
		/// </summary>
		bool InstantiateWhenEmpty { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether to re-parent the pooled objects to the pool's transform, after the objects are released.
		/// </summary>
		bool ReparentPooledObjects { get; set; }

		/// <summary>
		/// Gets or sets the maximum size of the pool, which is the maximum number of objects it can contain.
		/// </summary>
		/// <remarks>
		/// <para>The maximum size must be greater than, or equal to, zero. It cannot be a negative number.</para>
		/// <para>If an object is released to the pool while the pool is full, the object will be destroyed.</para>
		/// <para>
		/// If <see cref="MaximumSize"/> is set to a value lower than the current size of the pool, the pool will be
		/// reduced in size by destroying excess objects.
		/// </para>
		/// </remarks>
		int MaximumSize { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether to record pool statistics.
		/// </summary>
		bool RecordStatistics { get; set; }

		/// <summary>
		/// Gets or sets the initial size of the pool.
		/// </summary>
		int InitialSize { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether to initialise the pool in the <see cref="MonoBehaviour"/> Start method.
		/// </summary>
		bool InitialiseOnStart { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether to log a warning message when a poolable object is destroyed (either inside of the pool, or while in use).
		/// </summary>
		/// <remarks>
		/// <para>
		/// Poolable objects should be released to the pool and re-used, rather than being destroyed.
		/// This property ensures any destruction of the pooled objects is logged.
		/// </para>
		/// <para>
		/// Unfortunately, scene changes may also cause pooled objects to be destroyed. In this case, the warning message will be shown incorrectly,
		/// and can safely be ignored.
		/// </para>
		/// </remarks>
		bool WarnOnDestroy { get; set; }

	}

	/// <summary>
	/// An interface that defines the shared settings that can be changed on a <see cref="GameObject"/> pool and a <see cref="Component"/> pool.
	/// </summary>
	/// <typeparam name="TSource">The type of object being pooled.</typeparam>
	public interface ISharedPoolSettings<TSource> : ISharedPoolSettings {

		/// <summary>
		/// Gets or sets the source object that will be pooled.
		/// </summary>
		TSource Source { get; set; }

	}

}