﻿using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// An interface that defines the settings that can be changed on a <see cref="GameObject"/> pool.
	/// </summary>
	public interface IGameObjectPoolSettings : ISharedPoolSettings<GameObject> {
		
	}

}