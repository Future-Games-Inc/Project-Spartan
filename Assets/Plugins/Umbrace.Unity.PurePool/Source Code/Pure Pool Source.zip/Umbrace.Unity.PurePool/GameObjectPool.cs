﻿using System;

using Umbrace.Unity.Contracts;

using UnityEngine;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A <see cref="MonoBehaviour"/> component that provides pooling of many instances of a single <see cref="GameObject"/>, allowing the game objects to be recycled and reused.
	/// </summary>
	/// <remarks>
	/// <para>
	/// By virtue of being serialisable, <see cref="GameObjectPool"/> can survive an assembly reload caused by live recompilation inside of the Unity editor.
	/// </para>
	/// <para>
	/// To use the <see cref="GameObjectPool"/>, add a new instance of the component to a <see cref="GameObject"/>, and then set the properties to appropriate values.
	/// Once all properties have been set, invoke the <see cref="GameObjectPool.Initialise()"/> method. A pool cannot be used without being initialised.
	/// </para>
	/// </remarks>
	/// <example>
	/// <code language="cs">
	/// // Create the pool as a component on a game object.
	/// var pool = gameObject.AddComponent&lt;GameObjectPool&gt;();
	/// 
	/// // Set up the pool's properties.
	/// pool.SourceObject = prefab;
	/// pool.InitialSize = 50;
	/// pool.MaximumSize = 200;
	/// pool.InstantiateWhenEmpty = true;
	/// pool.NotificationMode = NotificationMode.Interface;
	/// pool.LogMessages = LogLevel.Warning;
	/// 
	/// // Initialise the pool. It will contain 50 objects.
	/// pool.Initialise();
	/// 
	/// // Acquire one of the 50 objects from the pool. The Acquire method can be used safely if InstantiateWhenEmpty is true, or if a check is made to CanAcquire beforehand.
	/// GameObject instance = pool.Acquire();
	/// 
	/// // Acquire one of the 49 remaining objects from the pool. TryAcquire can be used safely even when InstantiateWhenEmpty is false.
	/// GameObject secondInstance;
	/// if (pool.TryAcquire(out secondInstance)) {
	/// 	// Release the object back to the pool. It now contains 49 objects again.
	/// 	pool.Release(secondInstance);
	///	}
	/// 
	/// // Release the object back to the pool. It now contains 50 objects.
	/// pool.Release(instance);
	/// </code>
	/// </example>
	/// <seealso cref="GameObjectPoolManager"/>
	/// <seealso cref="SerialisableGameObjectPool"/>
	/// <seealso cref="IGameObjectPoolSettings"/>
	/// <seealso cref="IObjectPool{T}"/>
	public class GameObjectPool : PoolBase<GameObject, GameObject, GameObjectPoolSettings>, IGameObjectPoolSettings {

		#region Fields.
		[SerializeField, HideInInspector] private SerialisableGameObjectPool pool;
		#endregion

		#region Properties.
		/// <inheritdoc />
		protected override SerialisableObjectPool<GameObject> Pool {
			get => this.pool;
			set => this.pool = (SerialisableGameObjectPool)value;
		}

		/// <inheritdoc />
		public override NotificationMode NotificationMode {
			get => this.Settings.NotificationMode;
			set {
				this.Settings.NotificationMode = value;

				if (this.IsInitialised) {
					this.pool.NotificationMode = value;
				}
			}
		}

		/// <inheritdoc />
		public override bool ReparentPooledObjects {
			get => this.Settings.ReparentPooledObjects;
			set {
				this.Settings.ReparentPooledObjects = value;

				if (this.IsInitialised) {
					this.pool.ReparentPooledObjects = value;
				}
			}
		}

		/// <inheritdoc />
		public override bool WarnOnDestroy {
			get => this.Settings.WarnOnDestroy;
			set {
				this.Settings.WarnOnDestroy = value;

				if (this.IsInitialised) {
					this.pool.WarnOnDestroy = value;
				}
			}
		}
		#endregion

		#region UnityEvents.
		/// <summary>
		/// Occurs when a new instance of the source object is instantiated.
		/// </summary>
		[SerializeField, HideInInspector]
		public GameObjectEvent ObjectInstantiatedEvent = new GameObjectEvent();

		/// <summary>
		/// Occurs when an instance of the source object is acquired from the pool.
		/// </summary>
		[SerializeField, HideInInspector]
		public GameObjectEvent ObjectAcquiredEvent = new GameObjectEvent();

		/// <summary>
		/// Occurs when an instance of the source object is released back to the pool.
		/// </summary>
		[SerializeField, HideInInspector]
		public GameObjectEvent ObjectReleasedEvent = new GameObjectEvent();

		/// <summary>
		/// Occurs when an instance of the source object is destroyed.
		/// </summary>
		[SerializeField, HideInInspector]
		public GameObjectEvent ObjectDestroyedEvent = new GameObjectEvent();
		#endregion

		#region Initialisation and shutdown methods.
		/// <inheritdoc />
		protected override bool CanInitialise() {
			if (this.Source != null) {
				return true;
			} else {
				DebugHelper.LogWarning($"Cannot initialise {nameof(GameObjectPool)}. " +
										$"{nameof(this.Source)} must be set before {nameof(this.Start)} is called. " +
										$"Set {nameof(this.InitialiseOnStart)} to false if you wish to initialise the pool manually.{Environment.NewLine}" +
										$"{nameof(GameObjectPool)} on {this.transform.GetPath()}.");
				return false;
			}
		}
		
		protected override void OnDestroy() {
			// TODO: Unregister the Destroyed event handler on acquired pool objects, otherwise they'll continue to hold a reference to this component. Though when the objects are eventually destroyed, the reference will be removed.
			// The PoolableObject component would have to sign up to the pool's Destroyed event, and then ask the pool to unregister.

			base.OnDestroy();
		}
		#endregion

		#region Initialise method.
		/// <inheritdoc />
		public override void Initialise() {
			Contract.RequiresMessage(!this.IsInitialised, "Unable to initialise the pool as it's already been initialised. A pool can only be initialised once.");
			Contract.RequiresMessage(this.Source != null, () => $"Unable to initialise the pool as the source object has not been set. Please set the {nameof(this.Source)} property prior to initialising.");
			
			base.Initialise();

			DebugHelper.Log(this.LogMessages, $"Object pool for '{this.Source.name}' initialised with {this.InitialSize}/{this.MaximumSize} instances.");
		}
		#endregion

		#region Acquire methods.
		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of the source object, <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Transform, out GameObject)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public GameObject Acquire(Transform parent) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			return this.pool.Acquire(parent);
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <returns>An instance of the source object, <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Transform, out GameObject)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public GameObject Acquire(Transform parent, bool spawnInWorldSpace) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.pool.Acquire(parent, spawnInWorldSpace);
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <returns>An instance of the source object, <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Vector3, Quaternion, out GameObject)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public GameObject Acquire(Vector3 position, Quaternion rotation) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			return this.pool.Acquire(position, rotation);
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of the source object, <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Vector3, Quaternion, Transform, out GameObject)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public GameObject Acquire(Vector3 position, Quaternion rotation, Transform parent) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			return this.pool.Acquire(position,rotation, parent);
		}
		#endregion

		#region TryAcquire methods.
		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Transform)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire(Transform parent, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(parent, out instance);

			return this.pool.TryAcquire(parent, out instance);
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <param name="instance">When this method returns, contains the instance of <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Transform)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire(Transform parent, bool spawnInWorldSpace, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(parent, spawnInWorldSpace, out instance);

			return this.pool.TryAcquire(parent, spawnInWorldSpace, out instance);
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Vector3, Quaternion)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire(Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(position, rotation, out instance);

			return this.pool.TryAcquire(position, rotation, out instance);
		}

		/// <summary>
		/// Acquires an instance of the source object, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <see cref="PoolBase{TSource,TInstance,TSettings}.Source"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Vector3, Quaternion, Transform)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire(Vector3 position, Quaternion rotation, Transform parent, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(parent, position, rotation, out instance);

			return this.pool.TryAcquire(position, rotation, parent, out instance);
		}
		#endregion

		#region InternalTryInstantiate methods.
		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Transform parent, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");

			return this.InternalTryInstantiate(parent, false, out instance);
		}

		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Transform parent, bool spawnInWorldSpace, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");

			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.Set(parent, spawnInWorldSpace);
			}
			return result;
		}

		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.Set(position, rotation);
			}
			return result;
		}

		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Transform parent, Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.Set(parent, position, rotation);
			}
			return result;
		}
		#endregion

		#region Event raisers.
		/// <summary>
		/// Raises the <see cref="PoolBase{TSource,TInstance,TSettings}.ObjectInstantiated"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was instantiated.</param>
		protected override void OnObjectInstantiated(GameObject instance) {
			base.OnObjectInstantiated(instance);

			this.ObjectInstantiatedEvent?.Invoke(instance);
		}

		/// <summary>
		/// Raises the <see cref="PoolBase{TSource,TInstance,TSettings}.ObjectAcquired"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was acquired from the pool.</param>
		/// <param name="instantiated">A value indicating whether the acquired object was instantiated specifically for this acquisition, rather than being taken from the pool.</param>
		protected override void OnObjectAcquired(GameObject instance, bool instantiated) {
			base.OnObjectAcquired(instance, instantiated);

			this.ObjectAcquiredEvent?.Invoke(instance);
		}

		/// <summary>
		/// Raises the <see cref="PoolBase{TSource,TInstance,TSettings}.ObjectReleased"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was released back to the pool.</param>
		/// <param name="destroying">A value indicating whether the released object is about to be destroyed.</param>
		protected override void OnObjectReleased(GameObject instance, bool destroying) {
			base.OnObjectReleased(instance, destroying);

			this.ObjectReleasedEvent?.Invoke(instance);
		}

		/// <summary>
		/// Raises the <see cref="PoolBase{TSource,TInstance,TSettings}.ObjectDestroyed"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was destroyed.</param>
		protected override void OnObjectDestroyed(GameObject instance) {
			base.OnObjectDestroyed(instance);

			this.ObjectDestroyedEvent?.Invoke(instance);
		}
		#endregion

		#region PoolBase override methods.
		/// <inheritdoc />
		protected override SerialisableObjectPool<GameObject> CreateInternalPool() {
			// Construct the internal pool.
			return new SerialisableGameObjectPool(this.Source, this.transform) {
				NotificationMode = this.NotificationMode,
				ReparentPooledObjects = this.ReparentPooledObjects
			};
		}

		/// <inheritdoc />
		protected override GameObjectPoolSettings CreateSettingsClone(GameObjectPoolSettings settings) {
			return new GameObjectPoolSettings(settings);
		}

		/// <inheritdoc />
		protected override void DestroyInstance(GameObject instance) {
			// We expect the PoolableGameObject to be destroyed.
			var poolable = instance.GetComponent<PoolableGameObject>();
			if (poolable != null) {
				poolable.ExpectDestroy = true;
			}
			Object.Destroy(instance);
		}
		#endregion

	}

}