﻿using System;
using System.Collections.Generic;

using Umbrace.Unity.Contracts;

using Debug = System.Diagnostics.Debug;

#if POOL_STATISTICS
using UnityEngine;
#endif

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A generic implementation of an object pool, that allows for recycling and reuse of objects of type <typeparamref name="T"/>.
	/// </summary>
	/// <typeparam name="T">The type of object being pooled.</typeparam>
	/// <seealso cref="IObjectPool{T}"/>
	public class GenericObjectPool<T> : IObjectPool<T> {

		#region Constants.
		/// <summary>
		/// The default initial size of newly-created pools.
		/// </summary>
		public const int DefaultInitialSize = 0;

		/// <summary>
		/// The default maximum size of newly-created pools.
		/// </summary>
		public const int DefaultMaximumSize = 1000;
		#endregion

		#region Fields.
		private readonly BasicObjectPool<T> objectPool;

		private readonly PoolStatistics statistics;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets or sets the level of log messaging that the pool will output.
		/// </summary>
		public LogLevel LogMessages {
			get => this.objectPool.LogMessages;
			set => this.objectPool.LogMessages = value;
		}

		/// <summary>
		/// Gets or sets a value indicating whether to instantiate a new object when the pool is empty, and an attempt is made to acquire from the pool.
		/// </summary>
		public bool InstantiateWhenEmpty {
			get => this.objectPool.InstantiateWhenEmpty;
			set => this.objectPool.InstantiateWhenEmpty = value;
		}

		/// <summary>
		/// Gets or sets the maximum size of the pool, which is the maximum number of objects it can contain.
		/// </summary>
		/// <remarks>
		/// <para>The maximum size must be greater than, or equal to, zero. It cannot be a negative number.</para>
		/// <para>If an object is released to the pool while the pool is full, the object will be destroyed.</para>
		/// <para>
		/// If <see cref="MaximumSize"/> is set to a value lower than the current <see cref="Count"/>, the pool will be
		/// reduced in size by destroying excess objects.
		/// </para>
		/// </remarks>
		/// <seealso cref="Count"/>
		public int MaximumSize {
			get => this.objectPool.MaximumSize;
			set {
				Contract.Requires(value >= 0, $"The {nameof(this.MaximumSize)} property cannot be set to a negative number.");
				this.objectPool.MaximumSize = value;
			}
		}

		/// <summary>
		/// Gets the number of objects currently contained by the pool.
		/// </summary>
		/// <seealso cref="IsFull"/>
		/// <seealso cref="IsEmpty"/>
		/// <seealso cref="CountChanged"/>
		/// <seealso cref="MaximumSize"/>
		public int Count => this.objectPool.Count;

		/// <summary>
		/// Gets a list of items currently contained by the pool.
		/// </summary>
		/// <remarks>
		/// <para>
		/// This property always creates a new <see cref="List{T}"/> each time the property getter is accessed.
		/// For performance reasons the value should be cached where possible, to avoid the costs of object instantiation and garbage collection.
		/// </para>
		/// <para>See the <see cref="GetItems"/> method for a way to avoid the allocation of a new <see cref="List{T}"/> object.</para>
		/// </remarks>
		/// <seealso cref="GetItems"/>
		public IList<T> Items => this.objectPool.Items;

		/// <summary>
		/// Gets an object containing general operational statistics about the pool.
		/// </summary>
		public PoolStatistics Statistics => this.statistics;

		/// <summary>
		/// Gets a value indicating whether the pool is empty and contains no objects.
		/// </summary>
		/// <seealso cref="Count"/>
		/// <seealso cref="IsFull"/>
		public bool IsEmpty => this.objectPool.IsEmpty;

		/// <summary>
		/// Gets a value indicating whether the pool is full, and cannot contain any more objects.
		/// </summary>
		/// <seealso cref="Count"/>
		/// <seealso cref="IsEmpty"/>
		public bool IsFull => this.objectPool.IsFull;

		/// <summary>
		/// <para>Gets a value indicating whether an instance can be acquired from the pool.</para>
		/// <para>An instance can be acquired when the pool contains at least one instance, or when <see cref="InstantiateWhenEmpty"/> is <see langword="true"/>.</para>
		/// </summary>
		/// <seealso cref="IsEmpty"/>
		/// <seealso cref="InstantiateWhenEmpty"/>
		/// <seealso cref="CanAcquireChanged"/>
		public bool CanAcquire => this.objectPool.CanAcquire;

		/// <summary>
		/// Gets or sets a value indicating whether to record pool statistics.
		/// </summary>
		/// <seealso cref="Statistics"/>
		public bool RecordStatistics { get; set; } = true;
		#endregion

		#region Events.
		/// <summary>
		/// Occurs when a new object is instantiated.
		/// </summary>
		public event EventHandler<PoolObjectEventArgs<T>> ObjectInstantiated;

		/// <summary>
		/// Occurs when an object is acquired from the pool.
		/// </summary>
		/// <remarks>
		/// This event will also be invoked for objects that are instantiated when the pool is empty, in addition to <see cref="ObjectInstantiated"/>.
		/// In this situation, the <see cref="PoolObjectAcquiredEventArgs{T}.Instantiated"/> property is set to <see langword="true"/> to indicate that the acquired object was instantiated.
		/// </remarks>
		public event EventHandler<PoolObjectAcquiredEventArgs<T>> ObjectAcquired;

		/// <summary>
		/// Occurs when an object is released back to the pool.
		/// </summary>
		/// <remarks>
		/// This event will also be invoked for objects that are released to a pool that has reached its maximum size.
		/// In this situation, the <see cref="PoolObjectReleasedEventArgs{T}.Destroying"/> property is set to <see langword="true"/> to indicate that the released object is about to be destroyed.
		/// </remarks>
		public event EventHandler<PoolObjectReleasedEventArgs<T>> ObjectReleased;

		/// <summary>
		/// Occurs when an object is destroyed.
		/// </summary>
		public event EventHandler<PoolObjectEventArgs<T>> ObjectDestroyed;

		/// <summary>
		/// Occurs when the value of <see cref="CanAcquire"/> changes.
		/// </summary>
		/// <seealso cref="CanAcquire"/>
		public event EventHandler<PoolCanAcquireChangedEventArgs> CanAcquireChanged;

		/// <summary>
		/// Occurs when <see cref="Count"/> changes.
		/// </summary>
		/// <seealso cref="Count"/>
		public event EventHandler<PoolCountChangedEventArgs> CountChanged;
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="GenericObjectPool{T}"/> class.
		/// </summary>
		/// <remarks>
		/// <para>
		/// This constructor uses the public parameterless constructor on type <typeparamref name="T"/> for the creation of new objects.
		/// If you need to have greater control over the creation of new objects, or <typeparamref name="T"/> does not have a public parameterless
		/// constructor, you should use the overloaded constructor that takes a factory method, <see cref="GenericObjectPool{T}(Func{T})"/>.
		/// </para>
		/// <para>
		/// This constructor is not available on iOS or other build targets that don't support just-in-time compilation (AOT compilers).
		/// Instead, please use the <see cref="GenericObjectPool{T}(Func{T})"/> overload and provide a factory method.
		/// </para>
		/// </remarks>
		/// <exception cref="InvalidOperationException">If type <typeparamref name="T"/> has no public parameterless constructor.</exception>
		public GenericObjectPool() : this(GenericObjectPool<T>.DefaultInitialSize, GenericObjectPool<T>.DefaultMaximumSize) {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="GenericObjectPool{T}"/> class.
		/// </summary>
		/// <param name="initialSize">The initial number of objects to populate the pool with.</param>
		/// <param name="maximumSize">The maximum size of the pool, which is the maximum number of objects it can contain.</param>
		/// <remarks>
		/// <para>
		/// This constructor uses the public parameterless constructor on type <typeparamref name="T"/> for the creation of new objects.
		/// If you need to have greater control over the creation of new objects, or <typeparamref name="T"/> does not have a public parameterless
		/// constructor, you should use the overloaded constructor that takes a factory method, <see cref="GenericObjectPool{T}(Func{T}, int, int)"/>.
		/// </para>
		/// <para>
		/// This constructor is not available on iOS or other build targets that don't support just-in-time compilation (AOT compilers).
		/// Instead, please use the <see cref="GenericObjectPool{T}(Func{T},int,int)"/> overload and provide a factory method.
		/// </para>
		/// </remarks>
		/// <exception cref="InvalidOperationException">If type <typeparamref name="T"/> has no public parameterless constructor.</exception>
		public GenericObjectPool(int initialSize, int maximumSize) {
			Contract.RequiresMessage(initialSize >= 0, () => $"{nameof(initialSize)} cannot be a negative number.");
			Contract.RequiresMessage(initialSize <= maximumSize, () => $"{nameof(initialSize)} cannot be larger than {nameof(maximumSize)}.");

			this.statistics = new PoolStatistics();

			this.objectPool = new BasicObjectPool<T> {
				ObjectAcquiredHandler = this.OnObjectAcquired,
				ObjectInstantiatedHandler = this.OnObjectInstantiated,
				ObjectReleasedHandler = this.OnObjectReleased,
				ObjectDestroyedHandler = this.OnObjectDestroyed,
				CanAcquireChangedHandler = this.OnCanAcquireChanged,
				CountChangedHandler = this.OnCountChanged,
				MaximumSize = maximumSize
			};
			this.objectPool.SetSize(initialSize);
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="GenericObjectPool{T}"/> class.
		/// </summary>
		/// <param name="factory">A factory method that constructs and returns a new object each time it is invoked.</param>
		public GenericObjectPool(Func<T> factory) : this(factory, GenericObjectPool<T>.DefaultInitialSize, GenericObjectPool<T>.DefaultMaximumSize) {
			Contract.RequiresNotNull(factory, nameof(factory));

			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="GenericObjectPool{T}"/> class.
		/// </summary>
		/// <param name="factory">A factory method that constructs and returns a new object each time it is invoked.</param>
		/// <param name="initialSize">The initial number of objects to populate the pool with.</param>
		/// <param name="maximumSize">The maximum size of the pool, which is the maximum number of objects it can contain.</param>
		public GenericObjectPool(Func<T> factory, int initialSize, int maximumSize) {
			Contract.RequiresNotNull(factory, nameof(factory));
			Contract.RequiresMessage(initialSize >= 0, () => $"{nameof(initialSize)} cannot be a negative number.");
			Contract.RequiresMessage(initialSize <= maximumSize, () => $"{nameof(initialSize)} cannot be larger than {nameof(maximumSize)}.");

			this.statistics = new PoolStatistics();

			this.objectPool = new BasicObjectPool<T>(factory) {
				ObjectAcquiredHandler = this.OnObjectAcquired,
				ObjectInstantiatedHandler = this.OnObjectInstantiated,
				ObjectReleasedHandler = this.OnObjectReleased,
				ObjectDestroyedHandler = this.OnObjectDestroyed,
				CanAcquireChangedHandler = this.OnCanAcquireChanged,
				CountChangedHandler = this.OnCountChanged,
				MaximumSize = maximumSize
			};
			this.objectPool.SetSize(initialSize);
		}
		#endregion

		#region Acquire method.
		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <returns>An object from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire"/>
		/// <seealso cref="Release"/>
		public T Acquire() {
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			//Contract.Ensures(Contract.Result<T>() != null);

			T instance = this.objectPool.Acquire();
			Debug.Assert(instance != null);
			return instance;
		}
		#endregion

		#region TryAcquire(out T) method.
		/// <summary>
		/// Acquires an object from the pool.
		/// </summary>
		/// <param name="instance">When this method returns, contains the object from the pool, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire"/>
		/// <seealso cref="Release"/>
		public bool TryAcquire(out T instance) {
			//Contract.Ensures(!Contract.Result<bool>() || Contract.ValueAtReturn(out instance) != null);

			bool result = this.objectPool.TryAcquire(out instance);
			Debug.Assert(!result || instance != null);
			return result;
		}
		#endregion

		#region Release(T) method.
		/// <summary>
		/// Releases an object back to the pool.
		/// </summary>
		/// <param name="instance">The object to release to the pool.</param>
		public void Release(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			this.objectPool.Release(instance);
		}
		#endregion

		#region SetSize(int), Fill, Clear, Remove(T), Contains(T) methods.
		/// <summary>
		/// Sets the number of objects contained by the pool, either destroying excess pooled objects, or instantiating new ones.
		/// </summary>
		/// <param name="poolSize">The target number of objects the pool should contain.</param>
		/// <remarks>
		/// <paramref name="poolSize"/> cannot be a negative number, and cannot be larger than <see cref="MaximumSize"/>.
		/// </remarks>
		/// <seealso cref="Fill"/>
		/// <seealso cref="Clear"/>
		public void SetSize(int poolSize) {
			Contract.RequiresMessage(poolSize >= 0, () => $"{nameof(poolSize)} cannot be a negative number.");
			Contract.RequiresMessage(poolSize <= this.MaximumSize, () => $"{nameof(poolSize)} cannot be larger than {nameof(this.MaximumSize)}.");

			this.objectPool.SetSize(poolSize);
		}

		/// <summary>
		/// Fills the pool, populating it with pooled objects until it reaches the maximum pool size.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Clear"/>
		/// <seealso cref="MaximumSize"/>
		public void Fill() {
			//Contract.Ensures(this.Count == this.MaximumSize);

			this.objectPool.Fill();
		}

		/// <summary>
		/// Clears the pool, emptying it of all pooled objects.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Fill"/>
		public void Clear() {
			//Contract.Ensures(this.Count == 0);

			this.objectPool.Clear();
		}

		/// <summary>
		/// Removes the specified instance from the pool.
		/// </summary>
		/// <param name="instance">The instance of the source object that should be removed from the pool.</param>
		/// <returns><see langword="true"/> if the instance was found in the pool and removed; otherwise, <see langword="false"/>.</returns>
		public bool Remove(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			return this.objectPool.Remove(instance);
		}

		/// <summary>
		/// Determines whether an instance is in the pool.
		/// </summary>
		/// <param name="instance">The instance of the source object to locate in the pool.</param>
		/// <returns><see langword="true"/> if <paramref name="instance"/> is found in the pool; otherwise, <see langword="false"/>.</returns>
		public bool Contains(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			return this.objectPool.Contains(instance);
		}
		#endregion

		#region GetItems method.
		/// <summary>
		/// Gets a list of items currently contained by the pool, and stores them in the specified <see cref="List{T}"/>.
		/// </summary>
		/// <param name="list">The existing list in which the items should be stored.</param>
		/// <seealso cref="Items"/>
		public void GetItems(List<T> list) {
			Contract.RequiresNotNull(list, nameof(list));

			this.objectPool.GetItems(list);
		}
		#endregion

		#region InternalAdd(T) method.
		/// <summary>
		/// Adds an instance directly to the pool. This method is used internally and should be used with caution.
		/// </summary>
		/// <param name="instance">The instance to add to the pool.</param>
		/// <remarks>
		/// <para>If the maximum size of the pool would be exceeded by adding the instance, the instance is destroyed.</para>
		/// <para>
		/// This method does not inform the instance that it is being returned to the pool, and does not raise
		/// any events. It should only be used to add instances to the pool that were previously already in the pool,
		/// such as those serialised during live recompilation.
		/// </para>
		/// </remarks>
		internal void InternalAdd(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			this.objectPool.InternalAdd(instance);
		}
		#endregion

		#region InternalTryInstantiate(out T) method.
		/// <summary>
		/// Instantiates a new object if <see cref="InstantiateWhenEmpty"/> is <see langword="true"/>.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(out T instance) {
			//Contract.Ensures(!Contract.Result<bool>() || Contract.ValueAtReturn(out instance) != null);

			bool result = this.objectPool.InternalTryInstantiate(out instance);
			Debug.Assert(!result || instance != null);
			return result;
		}
		#endregion

		#region Event raisers.
		/// <summary>
		/// Raises the <see cref="ObjectInstantiated"/> event.
		/// </summary>
		/// <param name="instance">The object that was instantiated.</param>
		protected virtual void OnObjectInstantiated(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			#if POOL_STATISTICS
			if (this.RecordStatistics) {
				// Increment the number of objects that belong to the pool (those inside the pool and those outside of it).
				int aliveCount = ++this.statistics.ObjectsAliveInsideAndOutsidePool;
				if (this.statistics.HighestAliveCount < aliveCount) {
					this.statistics.HighestAliveCount = aliveCount;
				}
				
				this.statistics.InstantiationCount++;
				this.statistics.LastInstantiateTime = new TimeInstant(Time.frameCount, Time.realtimeSinceStartup, Time.time, Time.unscaledTime);
			}
			#endif

			this.ObjectInstantiated.InvokeEventPooled(this, instance);
		}

		/// <summary>
		/// Raises the <see cref="ObjectAcquired"/> event.
		/// </summary>
		/// <param name="instance">The object that was acquired from the pool.</param>
		/// <param name="instantiated">A value indicating whether the acquired object was instantiated specifically for this acquisition, rather than being taken from the pool.</param>
		protected virtual void OnObjectAcquired(T instance, bool instantiated) {
			Contract.RequiresNotNull(instance, nameof(instance));

			#if POOL_STATISTICS
			if (this.RecordStatistics) {
				this.statistics.AcquireCount++;

				int aliveOutsideCount = ++this.statistics.ObjectsAliveOutsidePool;
				if (aliveOutsideCount > this.statistics.RecommendedPoolSize) {
					this.statistics.RecommendedPoolSize = aliveOutsideCount;
				}

				this.statistics.LastAcquireTime = new TimeInstant(Time.frameCount, Time.realtimeSinceStartup, Time.time, Time.unscaledTime);
			}
			#endif

			this.ObjectAcquired.InvokeEventPooled(this, instance, instantiated);
		}

		/// <summary>
		/// Raises the <see cref="ObjectReleased"/> event.
		/// </summary>
		/// <param name="instance">The object that was released back to the pool.</param>
		/// <param name="destroying">A value indicating whether the released object is about to be destroyed.</param>
		protected virtual void OnObjectReleased(T instance, bool destroying) {
			Contract.RequiresNotNull(instance, nameof(instance));

			#if POOL_STATISTICS
			// Only record statistics if the object is not being destroyed. The OnObjectDestroyed method will handle those statistics.
			if (this.RecordStatistics && !destroying) {
				this.statistics.ReleaseCount++;
				this.statistics.ObjectsAliveOutsidePool--;
				this.statistics.LastReleaseTime = new TimeInstant(Time.frameCount, Time.realtimeSinceStartup, Time.time, Time.unscaledTime);
			}
			#endif

			this.ObjectReleased.InvokeEventPooled(this, instance, destroying);
		}

		/// <summary>
		/// Raises the <see cref="ObjectDestroyed"/> event.
		/// </summary>
		/// <param name="instance">The object that was destroyed.</param>
		protected virtual void OnObjectDestroyed(T instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			#if POOL_STATISTICS
			if (this.RecordStatistics) {
				this.statistics.DestructionCount++;
				this.statistics.ObjectsAliveOutsidePool--;
				this.statistics.ObjectsAliveInsideAndOutsidePool--;
				this.statistics.LastDestroyTime = new TimeInstant(Time.frameCount, Time.realtimeSinceStartup, Time.time, Time.unscaledTime);
			}
			#endif

			this.ObjectDestroyed.InvokeEventPooled(this, instance);
		}

		/// <summary>
		/// Raises the <see cref="CanAcquireChanged"/> event.
		/// </summary>
		/// <param name="canAcquire">The new value of <see cref="CanAcquire"/>.</param>
		protected virtual void OnCanAcquireChanged(bool canAcquire) {
			this.CanAcquireChanged.InvokeEventPooled(this, canAcquire);
		}

		/// <summary>
		/// Raises the <see cref="CountChanged"/> event.
		/// </summary>
		/// <param name="count">The new value of <see cref="Count"/>.</param>
		protected virtual void OnCountChanged(int count) {
			this.CountChanged.InvokeEventPooled(this, count);
		}
		#endregion

	}

}