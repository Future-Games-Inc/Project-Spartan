﻿using System;
using System.Collections.Generic;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEngine;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A generic, serialisable object pool for a <see cref="Component"/>, where the component type is known at compile time.
	/// </summary>
	/// <typeparam name="T">The type of component being pooled.</typeparam>
	/// <remarks>
	/// <para>
	/// By virtue of being serialisable, <see cref="SerialisableGenericComponentPool{T}"/> can survive an assembly reload caused by live recompilation
	/// inside of the Unity editor. However, to ensure Unity is able to serialise fields containing pools, you should subclass <see cref="SerialisableGenericComponentPool{T}"/>
	/// by creating a new, non-generic, class derived from it.
	/// </para>
	/// <para>
	/// <see cref="SerialisableGenericComponentPool{T}"/> achieves this by serialising the instances of the component that were contained in the pool,
	/// and then re-adding them to the pool after deserialisation.
	/// </para>
	/// <para>
	/// To use the <see cref="SerialisableGenericComponentPool{T}"/>, initialise a new instance using the constructor, and then set the properties to appropriate values.
	/// Once all properties have been set, invoke the <see cref="SerialisableObjectPool{T}.Initialise()"/> method. A pool cannot be used without being initialised in this way.
	/// </para>
	/// </remarks>
	/// <example>
	/// <code language="cs">
	/// // Create the pool.
	/// var pool = new SerialisableGenericComponentPool&lt;AudioSource&gt;(parentContainer) {
	/// 	InitialSize = 50,
	/// 	MaximumSize = 200,
	/// 	InstantiateWhenEmpty = true,
	/// 	NotificationMode = NotificationMode.Interface,
	/// 	LogMessages = LogLevel.Warning
	/// };
	/// 
	/// // Initialise the pool. It will contain 50 objects.
	/// pool.Initialise();
	/// 
	/// // Acquire one of the 50 components from the pool. The Acquire method can be used safely if InstantiateWhenEmpty is true, or if a check is made to CanAcquire beforehand.
	/// AudioSource instance = pool.Acquire();
	/// 
	/// // Acquire one of the 49 remaining components from the pool. TryAcquire can be used safely even when InstantiateWhenEmpty is false.
	/// AudioSource secondInstance;
	/// if (pool.TryAcquire(out secondInstance)) {
	/// 	// Release the component back to the pool. It now contains 49 objects again.
	/// 	pool.Release(secondInstance);
	///	}
	/// 
	/// // Release the component back to the pool. It now contains 50 objects.
	/// pool.Release(instance);
	/// </code>
	/// </example>
	/// <seealso cref="SerialisableComponentPool"/>
	/// <seealso cref="SerialisableObjectPool{T}"/>
	[Serializable]
	public class SerialisableGenericComponentPool<T> : SerialisableObjectPool<T> where T : Component {

		// TODO: Replace all GetComponent<PoolableComponent> calls with cache lookups?
		// TODO: Override SerialisableObjectPool methods to provide better XML documentation? Is there a nicer way to do this without overriding the method?

		#region Fields.
		/// <summary>
		/// The parent transform to which all pooled objects will be parented in the hierarchy,
		/// if <see cref="reparentPooledObjects"/> is <see langword="true"/>.
		/// </summary>
		[SerializeField, HideInInspector]
		private Transform parent;

		/// <summary>
		/// The way in which pooled objects are notified about being acquired from, and returned to, the pool.
		/// </summary>
		[SerializeField, HideInInspector]
		private NotificationMode notificationMode = NotificationMode.Interface;

		/// <summary>
		/// Whether to re-parent the pooled objects to the <see cref="parent"/> transform,
		/// after the objects are returned to the pool.
		/// </summary>
		[SerializeField, HideInInspector]
		private bool reparentPooledObjects = true;

		/// <summary>
		/// A list of additional component types, that should be added to the same GameObject as the main component type.
		/// </summary>
		[SerializeField, HideInInspector]
		private List<SerialisableType> additionalComponents = new List<SerialisableType>(); // TODO: Replace with ComponentTypeCollection?

		/// <summary>
		/// Whether to log a warning message when a poolable object is destroyed (either inside of the pool, or while in use).
		/// </summary>
		[SerializeField, HideInInspector]
		private bool warnOnDestroy = true;

		/// <summary>
		/// A dictionary mapping pooled components to their <see cref="PoolableComponent"/> component. This is necessary as we can't use GetComponent from OnAfterDeserialize.
		/// </summary>
		[SerializeField, HideInInspector]
		private ComponentToPoolableComponentDictionary componentToPoolable = new ComponentToPoolableComponentDictionary();

		/// <summary>
		/// The objects contained by the pool at the time the pool was serialised by Unity.
		/// </summary>
		[SerializeField, HideInInspector]
		private List<T> serialisedGameObjects;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets the type of the component being pooled.
		/// </summary>
		public virtual Type ComponentType => typeof(T);

		/// <summary>
		/// Gets a list of additional component types, that should be added to the same GameObject as the main component type.
		/// </summary>
		public IList<Type> AdditionalComponentTypes => this.additionalComponents.Cast<Type>().ToList();

		/// <summary>
		/// Gets or sets the parent transform to which all pooled objects will be parented in the hierarchy,
		/// if <see cref="ReparentPooledObjects"/> is <see langword="true"/>.
		/// </summary>
		/// <seealso cref="ReparentPooledObjects"/>
		public Transform Parent {
			get => this.parent;
			set {
				this.parent = value;

				// Update the parent transform for all objects in the pool.
				foreach (var instance in this.Items) {
					instance.transform.SetParent(value, false);
				}
			}
		}

		/// <summary>
		/// Gets or sets the way in which pooled objects are notified about being acquired from, and returned to, the pool.
		/// Cannot be set once the pool has been initialised.
		/// </summary>
		public NotificationMode NotificationMode {
			get => this.notificationMode;
			set {
				Contract.Requires(!this.IsInitialised, $"The {nameof(this.NotificationMode)} property cannot be set once the pool has been initialised.");
				this.notificationMode = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to re-parent the pooled objects to the <see cref="Parent"/> transform,
		/// after the objects are returned to the pool.
		/// </summary>
		/// <remarks>
		/// Re-parenting is enabled by default and is the safest option, but comes with a small performance penalty.
		/// Disabling re-parenting provides the best performance but there is the increased risk of any of the objects being affected
		/// by other scripts. As the objects will be parented beneath various other objects, deleting of an unrelated object
		/// may cause the pooled object to also be deleted.
		/// You should pay great attention to what objects you destroy if re-parenting is disabled.
		/// </remarks>
		/// <seealso cref="Parent"/>
		public bool ReparentPooledObjects {
			get => this.reparentPooledObjects;
			set => this.reparentPooledObjects = value;
		}

		/// <summary>
		/// Gets or sets a value indicating whether to log a warning message when a poolable object is destroyed (either inside of the pool, or while in use).
		/// </summary>
		/// <remarks>
		/// <para>
		/// Poolable objects should be released to the pool and re-used, rather than being destroyed.
		/// This property ensures any destruction of the pooled objects is logged.
		/// </para>
		/// <para>
		/// Unfortunately, scene changes may also cause pooled objects to be destroyed. In this case, the warning message will be shown incorrectly,
		/// and can safely be ignored.
		/// </para>
		/// </remarks>
		public bool WarnOnDestroy {
			get => this.warnOnDestroy;
			set => this.warnOnDestroy = value;
		}

		/// <summary>
		/// Gets a value indiciating whether to refill the pool with new components after the pool is reinitialised,
		/// as happens from deserialisation.
		/// </summary>
		protected override bool RefillPoolOnReinitialise => false; // We don't want the pool to be refilled with new components, as we can just re-add the serialised objects.
		#endregion

		#region Constructor.
		/// <summary>
		/// Initialises a new instance of the <see cref="SerialisableGenericComponentPool{T}"/> class.
		/// </summary>
		/// <param name="parent">The parent transform to which all pooled <see cref="GameObject"/> objects will be parented in the hierarchy.</param>
		/// <param name="additionalComponents">An optional list of additional component types, that should be added to the same GameObject as the main component type.</param>
		public SerialisableGenericComponentPool(Transform parent, params Type[] additionalComponents) {
			// Must be an addable component type, or any component type as long as this class is subclassed.
			Contract.RequiresMessage(typeof(T).CanAddAsComponent() || (typeof(Component).IsAssignableFrom(typeof(T)) && this.GetType().IsSubclassOf(typeof(SerialisableGenericComponentPool<T>))), typeName => $"The type '{typeName}' cannot be used as the component type in a {nameof(SerialisableGenericComponentPool<T>)}, as it is not a valid component type.", typeof(T).Name);
			
			this.parent = parent;
			this.serialisedGameObjects = new List<T>();

#if DEBUG
			// Use reflection to check if this type has been subclassed. Unity can't serialise a field if it's a generic type.
			if (!this.GetType().IsSubclassOf(typeof(SerialisableGenericComponentPool<T>))) {
				DebugHelper.LogWarning($"To allow Unity to serialise a field containing the pool, you should derive a new, non-generic, subclass from {nameof(SerialisableGenericComponentPool<T>)}. " +
										"For example, class SerialisableAudioSourcePool : SerialisableGenericComponentPool<AudioSource>.");
			}
#endif

			// Additional components that need to be added to each pooled object.
			if (additionalComponents != null) {
				foreach (Type additionalComponent in additionalComponents) {
					// Ensure the type is a valid component.
					Contract.RequiresMessage(additionalComponent.CanAddAsComponent(), additionalComponentName => $"The type '{additionalComponentName}' cannot be used as an additional component type in a {nameof(SerialisableGenericComponentPool<T>)}, as it is not a valid component type.", additionalComponent.Name);
					
					// Ignore duplicates that are disallowed.
					if (additionalComponent.DisallowMultiple() && this.additionalComponents.Contains(additionalComponent)) continue;

					this.additionalComponents.Add(new SerialisableType(additionalComponent));
				}
			}
		}
		#endregion

		#region SerialisableObjectPool overrides.
		/// <inheritdoc />
		protected override Func<T> GetObjectFactory() {
			return () => {
				// Create a new GameObject for the component to reside on.
				GameObject instance = new GameObject(this.ComponentType.Name);

				var component = (T)instance.AddComponent(this.ComponentType); // TODO: component could be null if the type can't be added for some reason.

				// Add the additional components to the GameObject.
				foreach (Type additionalComponent in this.additionalComponents) {
					instance.AddComponent(additionalComponent);
				}
				
				// Optionally, parent the instance to belong to the pool.
				if (this.ReparentPooledObjects) {
					instance.transform.SetParent(this.parent, false);
				}

				// Attach the PoolableComponent component to the new instance.
				// This component allows us to ensure only instances created by this pool can be returned to this pool.
				// It also allows other components on the object to run code when the object is released to the pool, to reset their state.
				var poolable = instance.AddComponent<PoolableComponent>(); // TODO: Check if PoolableComponent is already on the prefab? Maybe some settings could be set up on it in advance.
				poolable.SourceObject = new SerialisableType(this.ComponentType);
				poolable.NotificationMode = this.notificationMode;
				poolable.IsInPool = true;
				poolable.CachePoolableComponents = true;
				poolable.Destroyed += this.HandlePoolObjectDestroyed; // This event handler is re-added in OnAfterDeserialize, since it can't be serialised.

				// Disable the object whilst in the pool.
				instance.SetActive(false);

				this.componentToPoolable[component] = poolable;

				return component;
			};
		}

		/// <inheritdoc />
		protected override void OnObjectAcquired(T instance, bool instantiated) {
			// Shouldn't need to check if the GameObject is null (been destroyed while in pool).
			// A handler already exists for the Destroyed event that removes the object from the pool.

			GameObject attachedGameObject = instance.gameObject;

			// Enable the object and its components.
			attachedGameObject.SetActive(true);

			// Reinitialise the transform and detach it from the pool container.
			attachedGameObject.transform.SetParent(null, false); // TODO: This changing of the parent transform can be unnecessary, as the parent is set in some of the Acquire methods.

			// Tell the components on the object to reinitialise themselves.
			var poolable = attachedGameObject.GetComponent<PoolableComponent>();
			poolable.IsInPool = false;
			poolable.OnAcquire();

			base.OnObjectAcquired(instance, instantiated);
		}

		/// <inheritdoc />
		protected override void OnObjectReleased(T instance, bool destroying) {
			// If the object is about to be destroyed, we don't need to do anything to it.
			if (!destroying) {
				GameObject attachedGameObject = instance.gameObject;

				// Get the PoolableObject component, which allows the components on the game object to carry out actions when being released to the pool.
				var poolable = attachedGameObject.GetComponent<PoolableComponent>();
				poolable.IsInPool = true;
				poolable.OnRelease();

				// Disable the object whilst in the pool.
				attachedGameObject.SetActive(false);

				// Optionally attach the object to the pool container.
				if (this.ReparentPooledObjects) {
					attachedGameObject.transform.SetParent(this.parent, false);
				}
			}

			base.OnObjectReleased(instance, destroying);
		}

		/// <inheritdoc />
		protected override void OnObjectDestroyed(T instance) {
			base.OnObjectDestroyed(instance);

			GameObject attachedGameObject = instance.gameObject;

			// Get the PoolableObject component, which allows the components on the game object to carry out actions when being released to the pool.
			var poolable = attachedGameObject.GetComponent<PoolableComponent>();
			poolable.Destroyed -= this.HandlePoolObjectDestroyed;

			this.componentToPoolable.Remove(instance);

			Object.Destroy(attachedGameObject);
		}

		/// <inheritdoc />
		protected override void OnBeforeSerialize() {
			base.OnBeforeSerialize();

			// Remember the game objects that belong to the pool - Unity will serialise them as part of the scene,
			// and we'll need to re-add them to the pool after deserialisation.
			if (this.IsInitialised) {
				this.serialisedGameObjects.Clear();
				this.serialisedGameObjects.AddRange(this.Items);
			}
		}

		/// <inheritdoc />
		protected override void OnAfterDeserialize() {
			// Deserialise as normal. RefillPoolOnReinitialise is false to prevent the base method from trying to recreate the components.
			base.OnAfterDeserialize();

			// Add the serialised components back to the pool.
			foreach (var serialisedGameObject in this.serialisedGameObjects) {
				this.InternalAdd(serialisedGameObject);

				// Re-add the event handlers, as event handlers aren't serialised.
				this.componentToPoolable[serialisedGameObject].Destroyed += this.HandlePoolObjectDestroyed;
			}
			this.serialisedGameObjects.Clear();
		}

		/// <inheritdoc />
		protected override void ReleaseInternal(T instance) {
			GameObject attachedGameObject = instance.gameObject;

			// Get the PoolableComponent component, which allows the components on the game object to carry out actions when being released to the pool.
			var poolable = attachedGameObject.GetComponent<PoolableComponent>(); // TODO: The PoolableComponent is also retrieved in the OnObjectReleased method, duplicating the GetComponent call.

			// Ensure the object being returned has a PoolableComponent component, otherwise we can't verify that it belongs to the pool.
			if (poolable == null) {
				DebugHelper.LogError(this.LogMessages, $"Unable to release a component ('{this.ComponentType.Name}') to the pool without a {nameof(PoolableComponent)} component on its {nameof(GameObject)}. " +
														"The component may not have originated from this pool. The component and its game object have been destroyed.");
				Object.Destroy(attachedGameObject);
				return;
			}

			// Ensure the object being returned is an instance of the pool's source object.
			if (poolable.SourceObject.Type != this.ComponentType) {
				DebugHelper.LogError(this.LogMessages, "Unable to release a component to the pool due to component type mismatch. " +
														$"The component didn't originate from this pool. The component and its game object have been destroyed.{Environment.NewLine}" +
														$"Pool contains '{this.ComponentType.Name}' components, but component is '{poolable.SourceObject?.Type?.Name ?? "null"}'.");
				Object.Destroy(attachedGameObject);
				return;
			}

			base.ReleaseInternal(instance);
		}
		#endregion

		#region Acquire methods.
		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <returns>An instance of the component, <typeparamref name="T"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Transform, out T)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public T Acquire(Transform parent) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			T instance = this.Acquire();
			Debug.Assert(instance != null);
			instance.gameObject.Set(parent, false);

			return instance;
		}
		
		/// <summary>
		/// Acquires an instance of the component, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the components's transform to.</param>
		/// <returns>An instance of the component, <typeparamref name="T"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Vector3, Quaternion, out T)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public T Acquire(Vector3 position, Quaternion rotation) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			T instance = this.Acquire();
			Debug.Assert(instance != null);
			instance.gameObject.Set(position, rotation);

			return instance;
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <returns>An instance of the component, <typeparamref name="T"/>.</returns>
		/// <seealso cref="SerialisableObjectPool{T}.CanAcquire"/>
		/// <seealso cref="TryAcquire(Transform, Vector3, Quaternion, out T)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public T Acquire(Transform parent, Vector3 position, Quaternion rotation) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			T instance = this.Acquire();
			Debug.Assert(instance != null);
			instance.gameObject.Set(parent, position, rotation);

			return instance;
		}
		#endregion

		#region TryAcquire methods.
		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of the component <typeparamref name="T"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component <typeparamref name="T"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Transform)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire(Transform parent, out T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			if (this.TryAcquire(out instance)) {
				Debug.Assert(instance != null);
				instance.gameObject.Set(parent, false);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component <typeparamref name="T"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component <typeparamref name="T"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Vector3, Quaternion)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire(Vector3 position, Quaternion rotation, out T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			if (this.TryAcquire(out instance)) {
				Debug.Assert(instance != null);
				instance.gameObject.Set(position, rotation);
				return true;
			}

			return false;
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component <typeparamref name="T"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component <typeparamref name="T"/> was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Transform, Vector3, Quaternion)"/>
		/// <seealso cref="SerialisableObjectPool{T}.Release"/>
		public bool TryAcquire(Transform parent, Vector3 position, Quaternion rotation, out T instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			if (this.TryAcquire(out instance)) {
				Debug.Assert(instance != null);
				instance.gameObject.Set(parent, position, rotation);
				return true;
			}

			return false;
		}
		#endregion

		#region Private methods.
		/// <summary>
		/// Handles the <see cref="PoolableObject{T}.Destroyed"/> event.
		/// </summary>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="e">The event data.</param>
		private void HandlePoolObjectDestroyed(object sender, DestroyedEventArgs e) {
			// This method is called when the PoolableComponent component is removed from the object.
			// The whole object may be being destroyed, or just the component may have been destroyed.
			// The object may reside in the pool, or may have been acquired from the pool and not yet been returned.

			var poolable = (PoolableComponent)sender;
			var instance = poolable.gameObject;

			// If the component is in the pool, remove it and destroy it. It cannot exist in the pool without the PoolableComponent component.
			if (this.Remove((T)instance.GetComponent(this.ComponentType))) {
				// Ignore if the object is being destroyed because the application is quitting, or the destruction was expected (pooling disabled).
				if (!e.ApplicationQuit && !e.ExpectDestroy) {
					if (this.WarnOnDestroy) {
						DebugHelper.LogError(this.LogMessages,
							$"An instance of the '{this.ComponentType.Name}' component was destroyed, or had its {nameof(PoolableComponent)} component destroyed, while it was still in the pool. " +
							"You should identify the code that destroyed the object or component, and ensure it no longer modifies objects that have been returned to the pool.");
					}
					Object.Destroy(instance);
				}
			} else {
#if POOL_STATISTICS
				if (this.RecordStatistics) {
					// Decrement the number of objects alive outside the pool. This object has been destroyed.
					this.Statistics.ObjectsAliveOutsidePool--;
				}
#endif

				// Ignore if the object is being destroyed because the application is quitting, or the destruction was expected.
				if (!e.ApplicationQuit && !e.ExpectDestroy) {
					if (this.WarnOnDestroy) {
						// If the object is not in the pool, we'll ignore it for now. When the object is attempted to be returned to the pool, it will be rejected.
						DebugHelper.LogWarning(this.LogMessages,
							$"An instance of the '{this.ComponentType.Name}' component was destroyed, or had its {nameof(PoolableComponent)} component destroyed, while in use (outside of the pool). " +
							"You should refrain from destroying pooled objects, as this negates the purpose of pooling and may cause performance problems. " +
							$"Instead, release them back to the pool using the {nameof(this.Release)} method.");
					}
				}
			}
		}
		#endregion

	}

}