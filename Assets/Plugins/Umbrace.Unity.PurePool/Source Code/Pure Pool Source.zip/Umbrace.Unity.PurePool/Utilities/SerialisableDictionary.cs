﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A serialisable implementation of a key-value pair dictionary. The types <typeparamref name="TKey"/> and <typeparamref name="TValue"/> must also be serialisable.
	/// </summary>
	/// <typeparam name="TKey">The type of the key.</typeparam>
	/// <typeparam name="TValue">The type of the value.</typeparam>
	[Serializable, DebuggerDisplay("Count = {" + nameof(SerialisableDictionary<TKey, TValue>.Count) + "}")]
	public class SerialisableDictionary<TKey, TValue> : IDictionary<TKey, TValue>, ISerializationCallbackReceiver {

		#region Fields.
		[NonSerialized]
		private Dictionary<TKey, TValue> _dict;
		#endregion

		#region IDictionary implementation.
		public int Count => this._dict?.Count ?? 0;

		public void Add(TKey key, TValue value) {
			if (this._dict == null) this._dict = new Dictionary<TKey, TValue>();
			this._dict.Add(key, value);
		}

		public bool ContainsKey(TKey key) {
			if (this._dict == null) return false;
			return this._dict.ContainsKey(key);
		}

		public ICollection<TKey> Keys {
			get {
				if (this._dict == null) this._dict = new Dictionary<TKey, TValue>();
				return this._dict.Keys;
			}
		}

		public bool Remove(TKey key) {
			if (this._dict == null) return false;
			return this._dict.Remove(key);
		}

		public bool TryGetValue(TKey key, out TValue value) {
			if (this._dict == null) {
				value = default(TValue);
				return false;
			}
			return this._dict.TryGetValue(key, out value);
		}

		public ICollection<TValue> Values {
			get {
				if (this._dict == null) this._dict = new Dictionary<TKey, TValue>();
				return this._dict.Values;
			}
		}

		public TValue this[TKey key] {
			get {
				if (this._dict == null) throw new KeyNotFoundException();
				return this._dict[key];
			}
			set {
				if (this._dict == null) this._dict = new Dictionary<TKey, TValue>();
				this._dict[key] = value;
			}
		}

		public void Clear() {
			this._dict?.Clear();
		}

		void ICollection<KeyValuePair<TKey, TValue>>.Add(KeyValuePair<TKey, TValue> item) {
			if (this._dict == null) this._dict = new Dictionary<TKey, TValue>();
			(this._dict as ICollection<KeyValuePair<TKey, TValue>>).Add(item);
		}

		bool ICollection<KeyValuePair<TKey, TValue>>.Contains(KeyValuePair<TKey, TValue> item) {
			if (this._dict == null) return false;
			return (this._dict as ICollection<KeyValuePair<TKey, TValue>>).Contains(item);
		}

		void ICollection<KeyValuePair<TKey, TValue>>.CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex) {
			if (this._dict == null) return;
			(this._dict as ICollection<KeyValuePair<TKey, TValue>>).CopyTo(array, arrayIndex);
		}

		bool ICollection<KeyValuePair<TKey, TValue>>.Remove(KeyValuePair<TKey, TValue> item) {
			if (this._dict == null) return false;
			return (this._dict as ICollection<KeyValuePair<TKey, TValue>>).Remove(item);
		}

		bool ICollection<KeyValuePair<TKey, TValue>>.IsReadOnly => false;

		public Dictionary<TKey, TValue>.Enumerator GetEnumerator() {
			if (this._dict == null) return default(Dictionary<TKey, TValue>.Enumerator);
			return this._dict.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator() {
			if (this._dict == null) return Enumerable.Empty<KeyValuePair<TKey, TValue>>().GetEnumerator();
			return this._dict.GetEnumerator();
		}

		IEnumerator<KeyValuePair<TKey, TValue>> IEnumerable<KeyValuePair<TKey, TValue>>.GetEnumerator() {
			if (this._dict == null) return Enumerable.Empty<KeyValuePair<TKey, TValue>>().GetEnumerator();
			return this._dict.GetEnumerator();
		}
		#endregion

		#region ISerializationCallbackReceiver implementation.
		[SerializeField, HideInInspector] private TKey[] keys;
		[SerializeField, HideInInspector] private TValue[] values;

		void ISerializationCallbackReceiver.OnAfterDeserialize() {
			if (this.keys != null && this.values != null) {
				if (this._dict == null) this._dict = new Dictionary<TKey, TValue>(this.keys.Length);
				else this._dict.Clear();
				for (int i = 0; i < this.keys.Length; i++) {
					if (this.keys[i] == null) continue;

					if (i < this.values.Length)
						this._dict[this.keys[i]] = this.values[i];
					else
						this._dict[this.keys[i]] = default(TValue);
				}
			}

			this.keys = null;
			this.values = null;
		}

		void ISerializationCallbackReceiver.OnBeforeSerialize() {
			if (this._dict == null || this._dict.Count == 0) {
				this.keys = null;
				this.values = null;
			} else {
				int cnt = this._dict.Count;
				this.keys = new TKey[cnt];
				this.values = new TValue[cnt];
				int i = 0;
				using (var e = this._dict.GetEnumerator()) {
					while (e.MoveNext()) {
						if (e.Current.Key != null) {
							this.keys[i] = e.Current.Key;
							this.values[i] = e.Current.Value;
						}
						i++;
					}
				}
			}
		}
		#endregion

	}

}