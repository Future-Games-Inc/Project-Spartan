﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains static extension methods for various types.
	/// </summary>
	internal static class Extensions {

		#region EventArgs pooling.
		internal static void InvokePooled<T>(this EventHandler<T> eventHandler, object sender, T eventArgs) where T : EventArgs, new() {
			eventHandler?.Invoke(sender, eventArgs);
			EventArgsPool.Release(eventArgs);
		}

		/// <summary>
		/// Invokes the specified event using a pooled object for the event data.
		/// </summary>
		/// <param name="theEvent">The event to invoke.</param>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="instance">The object that the event is about.</param>
		internal static void InvokeEventPooled<T>(this EventHandler<PoolObjectEventArgs<T>> theEvent, object sender, T instance) {
			var handler = theEvent;
			if (handler != null) {
				var args = EventArgsPool.Acquire<PoolObjectEventArgs<T>>();
				args.Instance = instance;
				handler.InvokePooled(sender, args);
			}
		}

		/// <summary>
		/// Invokes the specified event using a pooled object for the event data.
		/// </summary>
		/// <param name="theEvent">The event to invoke.</param>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="instance">The object that the event is about.</param>
		/// <param name="destroying">A value indicating whether the released object is about to be destroyed.</param>
		internal static void InvokeEventPooled<T>(this EventHandler<PoolObjectReleasedEventArgs<T>> theEvent, object sender, T instance, bool destroying) {
			var handler = theEvent;
			if (handler != null) {
				var args = EventArgsPool.Acquire<PoolObjectReleasedEventArgs<T>>();
				args.Instance = instance;
				args.Destroying = destroying;
				handler.InvokePooled(sender, args);
			}
		}

		/// <summary>
		/// Invokes the specified event using a pooled object for the event data.
		/// </summary>
		/// <param name="theEvent">The event to invoke.</param>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="instance">The object that the event is about.</param>
		/// <param name="instantiated">A value indicating whether the acquired object was instantiated specifically for this acquisition, rather than being taken from the pool.</param>
		internal static void InvokeEventPooled<T>(this EventHandler<PoolObjectAcquiredEventArgs<T>> theEvent, object sender, T instance, bool instantiated) {
			var handler = theEvent;
			if (handler != null) {
				var args = EventArgsPool.Acquire<PoolObjectAcquiredEventArgs<T>>();
				args.Instance = instance;
				args.Instantiated = instantiated;
				handler.InvokePooled(sender, args);
			}
		}
		
		/// <summary>
		/// Invokes the specified event using a pooled object for the event data.
		/// </summary>
		/// <typeparam name="TPool">The type of the pool.</typeparam>
		/// <param name="theEvent">The event to invoke.</param>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="pool">The pool that the event is about.</param>
		internal static void InvokeEventPooled<TPool>(this EventHandler<PoolEventArgs<TPool>> theEvent, object sender, TPool pool) where TPool : IPoolBase {
			var handler = theEvent;
			if (handler != null) {
				var args = EventArgsPool.Acquire<PoolEventArgs<TPool>>();
				args.Pool = pool;
				handler.InvokePooled(sender, args);
			}
		}

		/// <summary>
		/// Invokes the specified event using a pooled object for the event data.
		/// </summary>
		/// <param name="theEvent">The event to invoke.</param>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="canAcquire">A value indicating whether an instance can be acquired from the pool.</param>
		internal static void InvokeEventPooled(this EventHandler<PoolCanAcquireChangedEventArgs> theEvent, object sender, bool canAcquire) {
			var handler = theEvent;
			if (handler != null) {
				var args = EventArgsPool.Acquire<PoolCanAcquireChangedEventArgs>();
				args.CanAcquire = canAcquire;
				handler.InvokePooled(sender, args);
			}
		}

		/// <summary>
		/// Invokes the specified event using a pooled object for the event data.
		/// </summary>
		/// <param name="theEvent">The event to invoke.</param>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="count">The number of objects currently contained by the pool.</param>
		internal static void InvokeEventPooled(this EventHandler<PoolCountChangedEventArgs> theEvent, object sender, int count) {
			var handler = theEvent;
			if (handler != null) {
				var args = EventArgsPool.Acquire<PoolCountChangedEventArgs>();
				args.Count = count;
				handler.InvokePooled(sender, args);
			}
		}

		/// <summary>
		/// Invokes the specified event using a pooled object for the event data.
		/// </summary>
		/// <param name="theEvent">The event to invoke.</param>
		/// <param name="sender">The sender of the event.</param>
		/// <param name="applicationQuit">A value indicating whether the object or component was destroyed due to the application quitting.</param>
		/// <param name="expectDestroy">A value indicating whether the destruction of the object or component was expected.</param>
		internal static void InvokeEventPooled(this EventHandler<DestroyedEventArgs> theEvent, object sender, bool applicationQuit, bool expectDestroy) {
			var handler = theEvent;
			if (handler != null) {
				var args = EventArgsPool.Acquire<DestroyedEventArgs>();
				args.ApplicationQuit = applicationQuit;
				args.ExpectDestroy = expectDestroy;
				handler.InvokePooled(sender, args);
			}
		}
		#endregion

		/// <summary>
		/// Sets the parent transform, position, and rotation of the specified <see cref="GameObject"/>.
		/// </summary>
		/// <param name="gameObject">The <see cref="GameObject"/> whose parent transform, position, and rotation should be set.</param>
		/// <param name="parent">The parent transform to set.</param>
		/// <param name="position">The position to set.</param>
		/// <param name="rotation">The rotation to set.</param>
		/// <returns>The <paramref name="gameObject"/> whose parent transform, position, and rotation was set.</returns>
		internal static GameObject Set(this GameObject gameObject, Transform parent, Vector3 position, Quaternion rotation) {
			Transform transform = gameObject.transform;
			transform.SetParent(parent, false);
			transform.SetPositionAndRotation(position, rotation);
			return gameObject;
		}

		/// <summary>
		/// Sets the position and rotation of the specified <see cref="GameObject"/>.
		/// </summary>
		/// <param name="gameObject">The <see cref="GameObject"/> whose position and rotation should be set.</param>
		/// <param name="position">The position to set.</param>
		/// <param name="rotation">The rotation to set.</param>
		/// <returns>The <paramref name="gameObject"/> whose position and rotation was set.</returns>
		internal static GameObject Set(this GameObject gameObject, Vector3 position, Quaternion rotation) {
			Transform transform = gameObject.transform;
			transform.SetPositionAndRotation(position, rotation);
			return gameObject;
		}

		/// <summary>
		/// Sets the parent transform of the specified <see cref="GameObject"/>.
		/// </summary>
		/// <param name="gameObject">The <see cref="GameObject"/> whose parent transform should be set.</param>
		/// <param name="parent">The parent transform to set.</param>
		/// <param name="worldPositionStays"><see langword="true"/> if the parent-relative position, scale and rotation are modified such that the object keeps the same world space position, rotation and scale as before; otherwise, <see langword="false"/>.</param>
		/// <returns>The <paramref name="gameObject"/> whose parent transform was set.</returns>
		internal static GameObject Set(this GameObject gameObject, Transform parent, bool worldPositionStays) {
			gameObject.transform.SetParent(parent, worldPositionStays);
			return gameObject;
		}

		internal static string GetPath(this Transform transform) {
			// TODO: Escape slashes in the transform name with double-slashes?

			string path = transform.name;
			while (transform.parent != null) {
				transform = transform.parent;
				path = transform.name + "/" + path;
			}
			return path;
		}

	}

}