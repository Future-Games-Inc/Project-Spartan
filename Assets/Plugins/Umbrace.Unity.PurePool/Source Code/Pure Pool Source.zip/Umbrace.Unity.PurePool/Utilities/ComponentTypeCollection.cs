﻿using System;
using System.Collections;
using System.Collections.Generic;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Represents a serialisable collection of component types that can be individually accessed by index.
	/// </summary>
	[Serializable]
	public class ComponentTypeCollection : IList<Type>, ISerializationCallbackReceiver {

		#region Fields.
		private List<Type> list;

		[SerializeField, HideInInspector]
		private List<SerialisableType> serialisableList;

		[SerializeField, HideInInspector]
		private bool frozen;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets a value indicating whether the object has been frozen, and cannot be modified.
		/// </summary>
		public bool Frozen => this.frozen;
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="ComponentTypeCollection"/> class.
		/// </summary>
		public ComponentTypeCollection() {
			this.list = new List<Type>();
			this.serialisableList = new List<SerialisableType>();
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="ComponentTypeCollection"/> class.
		/// </summary>
		/// <param name="other">The collection whose elements are copied to the new list.</param>
		public ComponentTypeCollection(ComponentTypeCollection other) {
			this.list = new List<Type>(other);
			this.serialisableList = new List<SerialisableType>(this.list.Count);
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Freezes the object and prevents modifications being made to it.
		/// </summary>
		public void Freeze() {
			this.frozen = true;
		}

		/// <summary>
		/// Ensures the <see cref="ComponentTypeCollection"/> has not been frozen, and throws an exception if it has.
		/// </summary>
		/// <exception cref="InvalidOperationException">If the <see cref="ComponentTypeCollection"/> has been frozen.</exception>
		protected void EnsureNotFrozen() {
			if (this.frozen) throw new NotSupportedException("This object has been frozen and cannot be modified.");
		}

		/// <summary>
		/// Checks whether the specified type is allowed in the collection.
		/// </summary>
		/// <param name="type">The type to check.</param>
		/// <returns><see langword="true"/> if the specified type is allowed in the collection; otherwise, <see langword="false"/>.</returns>
		private bool IsAllowed(Type type) {
			if (type == null) return false;
			if (!type.CanAddAsComponent()) return false;
			if (type.DisallowMultiple() && this.Contains(type)) return false;

			return true;
		}
		#endregion

		#region IList<T> implementation.
		/// <inheritdoc />
		public Type this[int index] {
			get => this.list[index];
			set {
				this.EnsureNotFrozen();
				if (!this.IsAllowed(value)) return;

				this.list[index] = value;
			}
		}

		/// <inheritdoc />
		public int Count => this.list.Count;

		bool ICollection<Type>.IsReadOnly => this.frozen;

		/// <inheritdoc />
		public void Add(Type item) {
			this.EnsureNotFrozen();
			if (!this.IsAllowed(item)) return;
			this.list.Add(item);
		}

		/// <inheritdoc />
		public void Clear() {
			this.EnsureNotFrozen();
			this.list.Clear();
		}

		/// <inheritdoc />
		public bool Contains(Type item) {
			return this.list.Contains(item);
		}

		/// <inheritdoc />
		public void CopyTo(Type[] array, int arrayIndex) {
			this.list.CopyTo(array, arrayIndex);
		}

		/// <inheritdoc />
		public IEnumerator<Type> GetEnumerator() {
			return this.list.GetEnumerator();
		}

		/// <inheritdoc />
		public int IndexOf(Type item) {
			return this.list.IndexOf(item);
		}

		/// <inheritdoc />
		public void Insert(int index, Type item) {
			this.EnsureNotFrozen();
			if (!this.IsAllowed(item)) return;
			this.list.Insert(index, item);
		}

		/// <inheritdoc />
		public bool Remove(Type item) {
			this.EnsureNotFrozen();
			return this.list.Remove(item);
		}

		/// <inheritdoc />
		public void RemoveAt(int index) {
			this.EnsureNotFrozen();
			this.list.RemoveAt(index);
		}

		IEnumerator IEnumerable.GetEnumerator() {
			return this.list.GetEnumerator();
		}
		#endregion

		#region ISerializationCallbackReceiver implementation.
		void ISerializationCallbackReceiver.OnBeforeSerialize() {
			this.serialisableList.Clear();
			foreach (var type in this.list) {
				this.serialisableList.Add(type);
			}
		}

		void ISerializationCallbackReceiver.OnAfterDeserialize() {
			this.list.Clear();
			foreach (var type in this.serialisableList) {
				this.list.Add(type);
			}
		}
		#endregion

	}

}