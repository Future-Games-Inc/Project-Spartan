﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A serialisable class that represents a <see cref="Type"/>.
	/// </summary>
	[Serializable]
	public sealed class SerialisableType : ISerializationCallbackReceiver, IEquatable<SerialisableType> {
		
		#region Fields.
		[SerializeField, HideInInspector]
		private string assemblyQualifiedName;

		private Type type;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets or sets type of class reference.
		/// </summary>
		public Type Type {
			get { return this.type; }
			private set {
				this.type = value;
				this.assemblyQualifiedName = value == null ? string.Empty : value.AssemblyQualifiedName;
			}
		}
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="SerialisableType"/> class.
		/// </summary>
		/// <param name="assemblyQualifiedName">The assembly qualified name of the type.</param>
		public SerialisableType(string assemblyQualifiedName) {
			this.Type = Type.GetType(assemblyQualifiedName);
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="SerialisableType"/> class.
		/// </summary>
		/// <param name="type">The <see cref="Type"/> to represent.</param>
		public SerialisableType(Type type) {
			this.Type = type;
		}
		#endregion

		#region Object overrides.
		/// <inheritdoc />
		public override string ToString() {
			return this.Type.FullName;
		}

		/// <inheritdoc />
		public override int GetHashCode() {
			return this.assemblyQualifiedName.GetHashCode();
		}

		/// <inheritdoc />
		public override bool Equals(object obj) {
			return this.Equals(obj as SerialisableType);
		}
		#endregion

		#region IEquatable<T> implementation.
		/// <inheritdoc />
		public bool Equals(SerialisableType other) {
			if (object.ReferenceEquals(other, null)) return false;
			if (object.ReferenceEquals(other, this)) return true;

			return other.assemblyQualifiedName == this.assemblyQualifiedName;
		}
		#endregion

		#region ISerializationCallbackReceiver implementation.
		void ISerializationCallbackReceiver.OnAfterDeserialize() {
			if (string.IsNullOrEmpty(this.assemblyQualifiedName)) {
				this.type = null;
			} else {
				this.type = Type.GetType(this.assemblyQualifiedName);

				if (this.type == null) {
					Debug.LogWarning($"'{this.assemblyQualifiedName}' was referenced but class type was not found.");
				}
			}
		}

		void ISerializationCallbackReceiver.OnBeforeSerialize() {
			// Do nothing.
		}
		#endregion

		#region Implicit conversion operators.
		public static implicit operator string(SerialisableType typeReference) {
			return typeReference.assemblyQualifiedName;
		}

		public static implicit operator Type(SerialisableType typeReference) {
			return typeReference.Type;
		}

		public static implicit operator SerialisableType(Type type) {
			return new SerialisableType(type);
		}
		#endregion

	}

}