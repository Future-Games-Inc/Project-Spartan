﻿using System;
using System.Collections;
using System.Collections.Generic;

using Umbrace.Unity.Contracts;

using UnityEngine;
using UnityEngine.SceneManagement;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool {
	
	/// <summary>
	/// An abstract <see cref="MonoBehaviour"/> component that provides shared functionality for the pooling of many instances of a type, allowing the instances to be recycled and reused.
	/// </summary>
	/// <typeparam name="TSource">The type of the source object to be pooled.</typeparam>
	/// <typeparam name="TInstance">The type of the instances of a pooled object.</typeparam>
	/// <typeparam name="TSettings">The type of the pool settings.</typeparam>
	/// <remarks>
	/// <para>
	/// By virtue of being serialisable, <see cref="PoolBase{TSource,TInstance,TSettings}"/> can survive an assembly reload caused by live recompilation inside of the Unity editor.
	/// </para>
	/// <para>
	/// <typeparamref name="TSource"/> and <typeparamref name="TInstance"/> may differ in the case of a source that is a <see cref="Type"/>.
	/// For example, a <typeparamref name="TSource"/> of <see cref="Type"/> where the provided source is <c>typeof(Component)</c>,
	/// will result in instances of <see cref="Component"/>, and therefore <typeparamref name="TInstance"/> should be <see cref="Component"/>.
	/// </para>
	/// </remarks>
	/// <seealso cref="ISharedPoolSettings{TSource}"/>
	/// <seealso cref="IObjectPool{TInstance}"/>
	public abstract class PoolBase<TSource, TInstance, TSettings> : MonoBehaviour, ISharedPoolSettings<TSource>, IObjectPool<TInstance>, IPoolBase, ISerializationCallbackReceiver
		where TSettings : SharedPoolSettings<TSource>, new() {

		#region Fields.
		[SerializeField, HideInInspector] private TSettings definition;
		[SerializeField, HideInInspector] private TSettings currentSettings = new TSettings();
		[SerializeField, HideInInspector] private bool isInitialised;
		#endregion

		#region Properties.
		/// <summary>
		/// When implemented in a derived class, gets or sets the internal object pool.
		/// </summary>
		protected abstract SerialisableObjectPool<TInstance> Pool { get; set; }

		/// <inheritdoc />
		public TSource Source {
			get => this.Settings.Source;
			set {
				Contract.RequiresMessage(!this.IsInitialised, () => $"The {nameof(this.Source)} property cannot be set once the pool has been initialised.");
				this.Settings.Source = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether pooling is enabled.
		/// </summary>
		/// <remarks>
		/// When <see cref="Enabled"/> is set to <see langword="false"/>, the pool will appear empty,
		/// and attempts to acquire from the pool will fail unless <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>.
		/// </remarks>
		public bool Enabled {
			get => this.Settings.Enabled;
			set => this.Settings.Enabled = value;
		}

		/// <summary>
		/// Gets or sets a value indicating whether to initialise the pool in the <see cref="MonoBehaviour"/> Start method.
		/// Cannot be set once the pool has been initialised.
		/// </summary>
		/// <remarks>
		/// This property cannot be set once the pool has been initialised.
		/// </remarks>
		public bool InitialiseOnStart {
			get => this.Settings.InitialiseOnStart;
			set {
				Contract.RequiresMessage(!this.IsInitialised, () => $"The {nameof(this.InitialiseOnStart)} property cannot be set once the pool has been initialised.");
				this.Settings.InitialiseOnStart = value;
			}
		}

		/// <summary>
		/// Gets a value indicating whether the pool has been initialised.
		/// </summary>
		/// <remarks>An initialised pool cannot have its <see cref="InitialiseOnStart"/> property changed.</remarks>
		public bool IsInitialised => this.isInitialised;

		/// <summary>
		/// Gets the settings that were used to initialise this pool.
		/// </summary>
		/// <remarks>
		/// If the pool has not yet been initialised, this will return an immutable copy of the current settings.
		/// </remarks>
		public TSettings Definition {
			get {
				// If the pool has been initialised, return the frozen initial definition.
				if (this.IsInitialised) {
					return this.definition;
				}

				// If the pool hasn't been initialised, copy the current settings and freeze them, and return those.
				var currentClone = this.CreateSettingsClone(this.currentSettings);
				currentClone.Freeze();
				return currentClone;
			}
		}

		/// <summary>
		/// Gets or sets the level of log messaging that the pool will output.
		/// </summary>
		public LogLevel LogMessages {
			get => this.Settings.LogMessages;
			set {
				this.Settings.LogMessages = value;

				if (this.IsInitialised) {
					this.Pool.LogMessages = value;
				}
			}
		}

		/// <summary>
		/// Gets or sets the modes in which pooled objects are notified of their acquisition from, and release to, the pool.
		/// </summary>
		/// <remarks>
		/// <para>
		/// Depending on the modes chosen, the pool will inform the components on the pooled object in different ways.
		/// The modes can be combined to support components on the same object that require differing modes.
		/// </para>
		/// <para>
		/// If a component needs to handle the notification but its class cannot be modified, a separate component should be created and attached to the object,
		/// which will handle the notification on the original component's behalf.
		/// </para>
		/// <list type="table">
		/// <listheader>
		/// <term>Notification Mode</term>
		/// <description>Description</description>>
		/// </listheader>
		/// <item>
		/// <term><see cref="PurePool.NotificationMode.Interface"/></term>>
		/// <description>
		/// <para>A custom interface that is applied to any components that need to respond to the notification.</para>
		/// <para>Components attached to the pooled object should implement the <see cref="IPoolable"/> interface if they wish to perform actions when the object is acquired from,
		/// or released to, the pool.</para>
		/// </description>
		/// </item>
		/// <item>
		/// <term><see cref="PurePool.NotificationMode.SendMessage"/></term>
		/// <description>
		/// <para>The built-in Unity messaging system that sends notifications using the <see cref="GameObject.SendMessage(string)"/> method.</para>
		/// <para>
		/// Components attached to the pooled object should implement the <c>OnAcquire</c> method to receive a notification when the object is acquired from the pool,
		/// and the <c>OnRelease</c> method to receive a notification when the object is released back to the pool.
		/// </para>
		/// </description>
		/// </item>
		/// <item>
		/// <term><see cref="PurePool.NotificationMode.UnityMessagingInterface"/></term>
		/// <description>
		/// <para>The built-in Unity messaging system that sends notifications using the <see cref="UnityEngine.EventSystems.ExecuteEvents"/> class, using an interface applied to any components that need to respond to the notification.</para>
		/// </description>
		/// </item>
		/// </list>
		/// </remarks>
		/// <seealso cref="PurePool.NotificationMode"/>
		/// <seealso cref="IPoolable"/>
		/// <seealso cref="GameObject.SendMessage(string)"/>
		public abstract NotificationMode NotificationMode { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether the pool should persist between scene changes.
		/// </summary>
		/// <remarks>
		/// <para>
		/// Upon setting the <see cref="DontDestroyOnLoad"/> property to <see langword="true"/>, the pool will be prevented from
		/// being destroyed when loading a new scene.
		/// </para>
		/// <para>
		/// It's important to make the distinction that it's actually the root transform of the <see cref="GameObject"/> to which the pool is attached that
		/// will persist between scene changes. The root transform is the top-most transform in the hierarchy.
		/// </para>
		/// <para>
		/// If the <see cref="PoolBase{TSource,TInstance,TSettings}"/> component is removed from its game object, the game object will still persist through scene changes.
		/// </para>
		/// </remarks>
		public new bool DontDestroyOnLoad {
			get => this.Settings.DontDestroyOnLoad;
			set {
				this.Settings.DontDestroyOnLoad = value;

				if (value && Application.isPlaying) {
					// The DontDestroyOnLoad method can only be called in play mode.
					// Only top-level game objects can be marked, so mark the root.
					Object.DontDestroyOnLoad(this.transform.root.gameObject); // Pooled objects outside of the pool will be destroyed.
				}
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to instantiate a new object when the pool is empty, and an attempt is made to acquire from the pool.
		/// </summary>
		/// <remarks>When set to <see langword="true"/>, <see cref="Object.Instantiate{T}(T)"/> is used to create a new object if the pool is empty.</remarks>
		public bool InstantiateWhenEmpty {
			get => this.Settings.InstantiateWhenEmpty;
			set {
				this.Settings.InstantiateWhenEmpty = value;

				if (this.IsInitialised) {
					this.Pool.InstantiateWhenEmpty = value;
				}
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to re-parent the pooled objects to the pool's <see cref="Transform"/>,
		/// after the objects are returned to the pool.
		/// </summary>
		/// <remarks>
		/// Re-parenting is enabled by default and is the safest option, but comes with a small performance penalty.
		/// Disabling re-parenting provides the best performance but there is the increased risk of any of the objects being affected
		/// by other scripts. As the objects will be parented beneath various other objects, deleting of an unrelated object
		/// may cause the pooled object to also be deleted.
		/// You should pay great attention to what objects you destroy if re-parenting is disabled.
		/// </remarks>
		public abstract bool ReparentPooledObjects { get; set; }

		/// <summary>
		/// Gets or sets the initial size of the pool.
		/// Cannot be set once the pool has been initialised.
		/// </summary>
		/// <remarks>
		/// <para>This property cannot be set once the pool has been initialised.</para>
		/// <para>The initial size must be greater than, or equal to, zero. It cannot be a negative number.</para>
		/// <para>This is the desired number of objects in the pool after the <see cref="Initialise()"/> method has been called.</para>
		/// </remarks>
		/// <seealso cref="Count"/>
		/// <seealso cref="MaximumSize"/>
		public int InitialSize {
			get => this.Settings.InitialSize;
			set {
				Contract.RequiresMessage(value >= 0, () => $"{nameof(this.InitialSize)} cannot be a negative value.");
				Contract.RequiresMessage(!this.IsInitialised, () => $"The {nameof(this.InitialSize)} property cannot be set once the pool has been initialised.");

				if (this.InitialSize == value) return;
				this.Settings.InitialSize = value;
			}
		}

		/// <summary>
		/// Gets or sets the maximum size of the pool, which is the maximum number of objects it can contain.
		/// </summary>
		/// <remarks>
		/// <para>The maximum size must be greater than, or equal to, zero. It cannot be a negative number.</para>
		/// <para>If an object is released to the pool while the pool is full, the object will be destroyed.</para>
		/// <para>
		/// If <see cref="MaximumSize"/> is set to a value lower than the current <see cref="Count"/>, the pool will be
		/// reduced in size by destroying excess objects.
		/// </para>
		/// </remarks>
		/// <seealso cref="Count"/>
		/// <seealso cref="InitialSize"/>
		public int MaximumSize {
			get => this.Settings.MaximumSize;
			set {
				Contract.RequiresMessage(value >= 0, () => $"The {nameof(this.MaximumSize)} property cannot be set to a negative number.");

				if (this.MaximumSize == value) return;
				this.Settings.MaximumSize = value;

				if (this.IsInitialised) {
					this.Pool.MaximumSize = value;
				}
			}
		}

		/// <summary>
		/// Gets the number of objects currently contained by the pool.
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		/// <seealso cref="IsInitialised"/>
		/// <seealso cref="IsEmpty"/>
		/// <seealso cref="InitialSize"/>
		/// <seealso cref="MaximumSize"/>
		/// <seealso cref="CountChanged"/>
		public int Count {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Count)} property cannot be accessed until the pool has been initialised.");

				// If pooling is disabled, we pretend we don't have any objects.
				return this.Enabled ? this.Pool.Count : 0;
			}
		}

		/// <summary>
		/// Gets an object containing general operational statistics about the pool.
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		public PoolStatistics Statistics {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Statistics)} property cannot be accessed until the pool has been initialised.");
				return this.Pool.Statistics;
			}
		}

		/// <summary>
		/// Gets a value indicating whether the pool is empty and contains no objects.
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		/// <seealso cref="Count"/>
		public bool IsEmpty {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.IsEmpty)} property cannot be accessed until the pool has been initialised.");
				return this.Count == 0;
			}
		}

		/// <summary>
		/// <para>Gets a value indicating whether an instance can be acquired from the pool.</para>
		/// <para>An instance can be acquired when the pool contains at least one instance, or when <see cref="InstantiateWhenEmpty"/> is <see langword="true"/>.</para>
		/// </summary>
		/// <remarks>
		/// This property cannot be accessed until the pool has been initialised.
		/// </remarks>
		/// <seealso cref="IsEmpty"/>
		/// <seealso cref="InstantiateWhenEmpty"/>
		/// <seealso cref="CanAcquireChanged"/>
		public bool CanAcquire {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.CanAcquire)} property cannot be accessed until the pool has been initialised.");
				return !this.IsEmpty || this.InstantiateWhenEmpty;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to record pool statistics.
		/// </summary>
		/// <seealso cref="Statistics"/>
		public bool RecordStatistics {
			get => this.Settings.RecordStatistics;
			set {
				this.Settings.RecordStatistics = value;

				if (this.IsInitialised) {
					this.Pool.RecordStatistics = value;
				}
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to log a warning message when a poolable object is destroyed (either inside of the pool, or while in use).
		/// </summary>
		/// <remarks>
		/// <para>
		/// Poolable objects should be released to the pool and re-used, rather than being destroyed.
		/// This property ensures any destruction of the pooled objects is logged.
		/// </para>
		/// <para>
		/// Unfortunately, scene changes may also cause pooled objects to be destroyed. In this case, the warning message will be shown incorrectly,
		/// and can safely be ignored.
		/// </para>
		/// </remarks>
		public abstract bool WarnOnDestroy { get; set; }

		/// <summary>
		/// Gets a list of items currently contained by the pool.
		/// </summary>
		/// <remarks>
		/// <para>This property cannot be accessed until the pool has been initialised.</para>
		/// <para>
		/// This property always creates a new <see cref="List{T}"/> each time the property getter is accessed.
		/// For performance reasons the value should be cached where possible, to avoid the costs of object instantiation and garbage collection.
		/// </para>
		/// <para>See the <see cref="GetItems"/> method for a way to avoid the allocation of a new <see cref="List{T}"/> object.</para>
		/// </remarks>
		/// <seealso cref="GetItems"/>
		public IList<TInstance> Items {
			get {
				Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Items)} property cannot be accessed until the pool has been initialised.");
				return this.Pool.Items;
			}
		}

		/// <summary>
		/// Gets or sets the current settings used by the pool. Cannot be set once the pool has been initialised.
		/// </summary>
		/// <remarks>
		/// This property cannot be set once the pool has been initialised.
		/// </remarks>
		/// <seealso cref="Definition"/>
		internal TSettings Settings {
			get => this.currentSettings;
			set {
				Contract.RequiresMessage(!this.IsInitialised, () => $"The {nameof(this.Settings)} property cannot be set after the pool has been initialised.");
				this.currentSettings = value;
			}
		}
		#endregion

		#region Events.
		/// <summary>
		/// Occurs when the pool is initialised.
		/// </summary>
		public event EventHandler Initialised;

		/// <summary>
		/// Occurs when the pool is destroyed.
		/// </summary>
		public event EventHandler Destroyed;

		/// <summary>
		/// Occurs when a new instance of the source object is instantiated.
		/// </summary>
		public event EventHandler<PoolObjectEventArgs<TInstance>> ObjectInstantiated;

		/// <summary>
		/// Occurs when an instance of the source object is acquired from the pool.
		/// </summary>
		/// <remarks>
		/// This event will also be invoked for objects that are instantiated when the pool is empty, in addition to <see cref="ObjectInstantiated"/>.
		/// In this situation, the <see cref="PoolObjectAcquiredEventArgs{T}.Instantiated"/> property is set to <see langword="true"/> to indicate that the acquired object was instantiated.
		/// </remarks>
		public event EventHandler<PoolObjectAcquiredEventArgs<TInstance>> ObjectAcquired;

		/// <summary>
		/// Occurs when an instance of the source object is released back to the pool.
		/// </summary>
		/// <remarks>
		/// This event will also be invoked for objects that are released to a pool that has reached its maximum size.
		/// In this situation, the <see cref="PoolObjectReleasedEventArgs{T}.Destroying"/> property is set to <see langword="true"/> to indicate that the released object is about to be destroyed.
		/// </remarks>
		public event EventHandler<PoolObjectReleasedEventArgs<TInstance>> ObjectReleased;

		/// <summary>
		/// Occurs when an instance of the source object is destroyed.
		/// </summary>
		public event EventHandler<PoolObjectEventArgs<TInstance>> ObjectDestroyed;

		/// <summary>
		/// Occurs when the value of <see cref="CanAcquire"/> changes.
		/// </summary>
		/// <seealso cref="CanAcquire"/>
		public event EventHandler<PoolCanAcquireChangedEventArgs> CanAcquireChanged;

		/// <summary>
		/// Occurs when <see cref="Count"/> changes.
		/// </summary>
		/// <seealso cref="Count"/>
		public event EventHandler<PoolCountChangedEventArgs> CountChanged;
		#endregion

		#region Initialisation and shutdown methods.
		protected virtual void Start() {
			// Initialise the pool if required.
			if (this.InitialiseOnStart && !this.IsInitialised && this.CanInitialise()) {
				this.Initialise();
			}

			// Set up if the pool should remain in the scene after a new scene is loaded.
			// Provided the pooled objects are parented beneath this object, they will also remain in the scene.
			if (this.DontDestroyOnLoad) {
				Object.DontDestroyOnLoad(this.transform.root.gameObject);
			}
			
			// Listen for a new scene being loaded. This is used to destroy the pool if DontDestroyOnLoad is changed back from true to false, since that action can't be undone.
			SceneManager.sceneLoaded += this.SceneManagerOnSceneLoaded;
		}

		/// <summary>
		/// When overridden in a derived class, determines whether the pool can be initialised.
		/// </summary>
		/// <returns><see langword="true"/> if the pool can be initialised; otherwise, <see langword="false"/>.</returns>
		protected virtual bool CanInitialise() {
			return true;
		}

		protected virtual void OnDestroy() {
			if (this.IsInitialised) {
				// Destroy the objects in the pool. If only this component is removed, it would leave behind the pooled objects.
				this.SetSize(0);
			}

			// Let anyone interested know that the pool is being destroyed.
			this.OnDestroyed();
		}
		#endregion

		#region Initialise method.
		/// <summary>
		/// Initialises the pool, populating it with the initial number of objects.
		/// </summary>
		/// <param name="settings">The settings to use to initialise the pool.</param>
		/// <remarks>After <see cref="Initialise(TSettings)"/> has been called, the <see cref="Definition"/> property will contain the settings that were used to initialise the pool.</remarks>
		public void Initialise(TSettings settings) {
			Contract.RequiresNotNull(settings, nameof(settings));
			Contract.RequiresMessage(!this.IsInitialised, "Unable to initialise the pool as it's already been initialised. A pool can only be initialised once.");

			this.currentSettings = this.CreateSettingsClone(settings);
			this.Initialise();
		}

		/// <summary>
		/// Initialises the pool, populating it with the initial number of objects.
		/// </summary>
		/// <remarks>After <see cref="Initialise()"/> has been called, the <see cref="Definition"/> property will contain the settings that were used to initialise the pool.</remarks>
		public virtual void Initialise() {
			Contract.RequiresMessage(!this.IsInitialised, "Unable to initialise the pool as it's already been initialised. A pool can only be initialised once.");
			
			// Create a copy of the current settings, to keep as a record of how the pool was initially created.
			this.definition = this.CreateSettingsClone(this.currentSettings);
			this.definition.Freeze();

			// Construct the internal pool.
			this.Pool = this.CreateInternalPool();
			this.Pool.InitialSize = this.InitialSize;
			this.Pool.MaximumSize = this.MaximumSize;
			this.Pool.InstantiateWhenEmpty = this.InstantiateWhenEmpty;
			this.Pool.LogMessages = this.LogMessages;
			this.Pool.RecordStatistics = this.RecordStatistics;
			
			// Some of these events could occur before we mark the pool as being initialised. Handlers of the event should be aware of this.
			// These event handlers disappear after deserialisation, and are re-added in OnAfterDeserialize.
			this.SetUpEventHandlers();
			
			// Initialise the internal pool, populating it with the initial number of objects.
			this.Pool.Initialise();

			// Mark the pool as being initialised - this means the pool has started, and some variables may no longer be changed.
			this.isInitialised = true;

			// Raise the Initialised event.
			this.OnInitialised();
		}
		#endregion

		#region Acquire methods.
		/// <summary>
		/// Acquires an instance from the pool.
		/// </summary>
		/// <returns>An instance from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire(out TInstance)"/>
		/// <seealso cref="Release(TInstance)"/>
		public virtual TInstance Acquire() {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");
			
			return this.Pool.Acquire();
		}
		#endregion

		#region TryAcquire methods.
		/// <summary>
		/// Acquires an instance from the pool.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instance from the pool, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire()"/>
		/// <seealso cref="Release(TInstance)"/>
		public virtual bool TryAcquire(out TInstance instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(out instance);

			return this.Pool.TryAcquire(out instance);
		}
		#endregion

		#region Release method.
		/// <summary>
		/// Releases an instance back to the pool.
		/// </summary>
		/// <param name="instance">The instance to release to the pool.</param>
		public virtual void Release(TInstance instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Release)} method cannot be called until the pool has been initialised.");
			Contract.RequiresNotNull(instance, nameof(instance));

			// If pooling is not enabled, destroy the object instead of releasing it to the pool.
			if (!this.Enabled) {
				this.DestroyInstance(instance);
				return;
			}

			this.Pool.Release(instance);
		}

		/// <summary>
		/// Releases an instance back to the pool after a specified time delay.
		/// </summary>
		/// <param name="instance">The instance to release to the pool.</param>
		/// <param name="delay">The period of time to wait before releasing the instance to the pool.</param>
		/// <remarks>
		/// The delay is measured in scaled time, and is therefore affected by <see cref="Time.timeScale"/>.
		/// </remarks>
		public virtual void Release(TInstance instance, float delay) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Release)} method cannot be called until the pool has been initialised.");
			Contract.RequiresNotNull(instance, nameof(instance));

			this.StartCoroutine(this.ReleaseLater(instance, delay));
		}
		#endregion

		#region SetSize, Fill, Clear, Grow, Shrink methods.
		/// <summary>
		/// Sets the number of objects contained by the pool, either destroying excess pooled objects, or instantiating new ones.
		/// </summary>
		/// <param name="poolSize">The target number of objects the pool should contain.</param>
		/// <remarks>
		/// <paramref name="poolSize"/> cannot be a negative number, and cannot be larger than <see cref="MaximumSize"/>.
		/// </remarks>
		/// <seealso cref="Fill"/>
		/// <seealso cref="Clear"/>
		/// <seealso cref="Grow"/>
		/// <seealso cref="Shrink"/>
		public void SetSize(int poolSize) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.SetSize)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(poolSize >= 0, () => $"{nameof(poolSize)} cannot be a negative number.");
			Contract.RequiresMessage(poolSize <= this.MaximumSize, () => $"{nameof(poolSize)} cannot be larger than {nameof(this.MaximumSize)}.");

			this.Pool.SetSize(poolSize);
		}

		/// <summary>
		/// Fills the pool, populating it with pooled objects until it reaches the maximum pool size.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Clear"/>
		/// <seealso cref="MaximumSize"/>
		/// <seealso cref="Grow"/>
		public void Fill() {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Fill)} method cannot be called until the pool has been initialised.");
			
			this.Pool.Fill();
		}

		/// <summary>
		/// Clears the pool, emptying it of all pooled objects.
		/// </summary>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Fill"/>
		/// <seealso cref="Shrink"/>
		public void Clear() {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Clear)} method cannot be called until the pool has been initialised.");
			
			this.Pool.Clear();
		}

		/// <summary>
		/// Increases the number of objects contained by the pool by the specified amount.
		/// </summary>
		/// <param name="amount">The amount of new objects to add to the pool.</param>
		/// <remarks><paramref name="amount"/> cannot be a negative number.</remarks>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Shrink"/>
		/// <seealso cref="Fill"/>
		/// <seealso cref="Clear"/>
		public void Grow(int amount) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Grow)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(amount >= 0, () => $"{nameof(amount)} cannot be a negative number.");
			
			int newSize = this.Count + amount;

			// Ensure the new size is not greater than the maximum size.
			if (newSize > this.MaximumSize) {
				newSize = this.MaximumSize;
			}

			this.SetSize(newSize);
		}

		/// <summary>
		/// Decreases the number of objects contained by the pool by the specified amount.
		/// </summary>
		/// <param name="amount">The amount of objects to remove from the pool.</param>
		/// <remarks><paramref name="amount"/> cannot be a negative number.</remarks>
		/// <seealso cref="SetSize"/>
		/// <seealso cref="Grow"/>
		/// <seealso cref="Fill"/>
		/// <seealso cref="Clear"/>
		public void Shrink(int amount) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Shrink)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(amount >= 0, () => $"{nameof(amount)} cannot be a negative number.");

			int newSize = this.Count - amount;

			// Ensure the new size is not smaller than zero.
			if (newSize < 0) {
				newSize = 0;
			}

			this.SetSize(newSize);
		}
		#endregion

		#region GetItems method.
		/// <summary>
		/// Gets a list of items currently contained by the pool, and stores them in the specified <see cref="List{T}"/>.
		/// </summary>
		/// <param name="list">The existing list in which the items should be stored.</param>
		/// <seealso cref="Items"/>
		public void GetItems(List<TInstance> list) {
			Contract.RequiresNotNull(list, nameof(list));

			this.Pool.GetItems(list);
		}
		#endregion

		#region InternalTryInstantiate methods.
		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="InstantiateWhenEmpty"/> is <see langword="true"/>.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(out TInstance instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			return this.Pool.InternalTryInstantiate(out instance);
		}
		#endregion

		#region ISerializationCallbackReceiver implementation.
		/// <inheritdoc />
		void ISerializationCallbackReceiver.OnBeforeSerialize() {
			// Do nothing.
		}

		/// <inheritdoc />
		void ISerializationCallbackReceiver.OnAfterDeserialize() {
			// Re-add the event handlers, as they are not serialised and will disappear after deserialisation.
			this.SetUpEventHandlers();
		}
		#endregion

		#region Private methods.
		private IEnumerator ReleaseLater(TInstance instance, float delay) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.ReleaseLater)} method cannot be called until the pool has been initialised.");
			Contract.RequiresNotNull(instance, nameof(instance));

			yield return new WaitForSeconds(delay);

			this.Release(instance);
		}

		private void SetUpEventHandlers() {
			// Some of these events could occur before we mark the pool as being initialised. Handlers of the event should be aware of this.
			this.Pool.ObjectAcquired += (sender, args) => this.OnObjectAcquired(args.Instance, args.Instantiated);
			this.Pool.ObjectInstantiated += (sender, args) => this.OnObjectInstantiated(args.Instance);
			this.Pool.ObjectReleased += (sender, args) => this.OnObjectReleased(args.Instance, args.Destroying);
			this.Pool.ObjectDestroyed += (sender, args) => this.OnObjectDestroyed(args.Instance);
			this.Pool.CanAcquireChanged += (sender, args) => this.OnCanAcquireChanged(args.CanAcquire);
			this.Pool.CountChanged += (sender, args) => this.OnCountChanged(args.Count);
		}

		private void SceneManagerOnSceneLoaded(Scene scene, LoadSceneMode mode) {
			// Ensure this object hasn't been destroyed before we try to access its GameObject and scene.
			if (this == null || this.gameObject == null) return;

			// If the pool shouldn't be kept through scene changes, ensure it gets destroyed.
			// This is necessary as it's only possible to mark an object as persisting through scene changes - there's no way to undo it once it's been marked.
			if (!this.DontDestroyOnLoad && mode == LoadSceneMode.Single && this.gameObject.scene != scene) {
				Object.Destroy(this);

				// Unregister the callback.
				SceneManager.sceneLoaded -= this.SceneManagerOnSceneLoaded;
			}
		}
		#endregion
		
		#region Event raisers.
		/// <summary>
		/// Raises the <see cref="Initialised"/> event.
		/// </summary>
		protected virtual void OnInitialised() {
			this.Initialised?.Invoke(this, EventArgs.Empty);
		}

		/// <summary>
		/// Raises the <see cref="Destroyed"/> event.
		/// </summary>
		protected virtual void OnDestroyed() {
			this.Destroyed?.Invoke(this, EventArgs.Empty);
		}

		/// <summary>
		/// Raises the <see cref="ObjectInstantiated"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was instantiated.</param>
		protected virtual void OnObjectInstantiated(TInstance instance) {
			this.ObjectInstantiated.InvokeEventPooled(this, instance);
		}

		/// <summary>
		/// Raises the <see cref="ObjectAcquired"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was acquired from the pool.</param>
		/// <param name="instantiated">A value indicating whether the acquired object was instantiated specifically for this acquisition, rather than being taken from the pool.</param>
		protected virtual void OnObjectAcquired(TInstance instance, bool instantiated) {
			this.ObjectAcquired.InvokeEventPooled(this, instance, instantiated);
		}

		/// <summary>
		/// Raises the <see cref="ObjectReleased"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was released back to the pool.</param>
		/// <param name="destroying">A value indicating whether the released object is about to be destroyed.</param>
		protected virtual void OnObjectReleased(TInstance instance, bool destroying) {
			this.ObjectReleased.InvokeEventPooled(this, instance, destroying);
		}

		/// <summary>
		/// Raises the <see cref="ObjectDestroyed"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was destroyed.</param>
		protected virtual void OnObjectDestroyed(TInstance instance) {
			this.ObjectDestroyed.InvokeEventPooled(this, instance);
		}

		/// <summary>
		/// Raises the <see cref="CanAcquireChanged"/> event.
		/// </summary>
		/// <param name="canAcquire">The new value of <see cref="CanAcquire"/>.</param>
		protected virtual void OnCanAcquireChanged(bool canAcquire) {
			this.CanAcquireChanged.InvokeEventPooled(this, canAcquire);
		}

		/// <summary>
		/// Raises the <see cref="CountChanged"/> event.
		/// </summary>
		/// <param name="count">The new value of <see cref="Count"/>.</param>
		protected virtual void OnCountChanged(int count) {
			this.CountChanged.InvokeEventPooled(this, count);
		}
		#endregion

		#region Abstract methods.
		/// <summary>
		/// When implemented in a derived class, creates the internal object pool.
		/// </summary>
		/// <returns>The internal object pool to store instances in.</returns>
		protected abstract SerialisableObjectPool<TInstance> CreateInternalPool();

		/// <summary>
		/// When implemented in a derived class, creates a new instance of <typeparamref name="TSettings"/> that is an exact copy of the specified settings.
		/// </summary>
		/// <param name="settings">The settings to copy.</param>
		/// <returns>A new instance of <typeparamref name="TSettings"/> that is an exact copy of <paramref name="settings"/>.</returns>
		protected abstract TSettings CreateSettingsClone(TSettings settings);

		/// <summary>
		/// When implemented in a derived class, destroys the specified instance.
		/// </summary>
		/// <param name="instance">The instance to destroy.</param>
		protected abstract void DestroyInstance(TInstance instance);
		#endregion

	}

}