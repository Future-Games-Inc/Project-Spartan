﻿namespace Umbrace.Unity.PurePool.Editor {

	/// <summary>
	/// Specifies the way in which times are displayed.
	/// </summary>
	internal enum TimeDisplayMode {

		/// <summary>
		/// The frame count is displayed.
		/// </summary>
		FrameCount,

		/// <summary>
		/// The real-time since startup is displayed. This is not affected by pausing or time-scaling.
		/// </summary>
		RealtimeSinceStartup,

		/// <summary>
		/// The scaled game time since startup is displayed. This is affected by pausing and time-scaling.
		/// </summary>
		Time,

		/// <summary>
		/// The unscaled game time since startup is displayed. This is affected by pausing, but not by time-scaling.
		/// </summary>
		UnscaledTime

	}

}