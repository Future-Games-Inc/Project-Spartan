﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Specifies the ways in which pooling notifications can be sent to <see cref="MonoBehaviour"/> components.
	/// </summary>
	[Flags]
	public enum NotificationMode {

		/// <summary>
		/// A custom interface that is applied to any components that need to respond to the notification.
		/// </summary>
		/// <seealso cref="IPoolable"/>
		Interface = 1,

		/// <summary>
		/// The built-in Unity messaging system that sends notifications using the <see cref="UnityEngine.GameObject.SendMessage(string)"/> method.
		/// </summary>
		SendMessage = 2,

		/// <summary>
		/// The built-in Unity messaging system that sends notifications using the <see cref="UnityEngine.EventSystems.ExecuteEvents"/> class, using an interface applied to any components that need to respond to the notification.
		/// </summary>
		/// <seealso cref="IPoolable"/>
		UnityMessagingInterface = 4
		
	}

}