﻿using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Specifies the way in which <see cref="GameObjectPoolManager"/> responds to attempts to acquire an object for which no pool exists.
	/// </summary>
	public enum AcquireNoPoolMode {

		/// <summary>
		/// An exception is thrown and logged in Unity. No object is returned.
		/// </summary>
		Error,

		/// <summary>
		/// A new object is instantiated using <see cref="Object.Instantiate(UnityEngine.Object,UnityEngine.Vector3,UnityEngine.Quaternion)"/>. When released, the object is destroyed.
		/// </summary>
		Instantiate,

		/// <summary>
		/// A new pool is created using default settings, to contain instances of the object. An instance is returned from the pool.
		/// </summary>
		CreatePool
		
	}

}