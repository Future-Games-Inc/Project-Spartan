﻿using System;

using Umbrace.Unity.PurePool.ForEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	[DisallowMultipleComponent]
	[AddComponentMenu("")] // Hide this script in the Components menu of the editor.
	internal class GameObjectManagerEditorSettings : ManagerEditorSettings<GameObjectPool, GameObject, GameObject, GameObjectPoolSettings> {
		
	}

	[DisallowMultipleComponent]
	[AddComponentMenu("")] // Hide this script in the Components menu of the editor.
	internal class ComponentManagerEditorSettings : ManagerEditorSettings<ComponentPool, Type, Component, ComponentPoolSettings> {

	}

	[DisallowMultipleComponent]
	[AddComponentMenu("")] // Hide this script in the Components menu of the editor.
	internal abstract class ManagerEditorSettings<TPool, TSource, TInstance, TPoolSettings> : MonoBehaviour
		where TPool : PoolBase<TSource, TInstance, TPoolSettings>
		where TPoolSettings : SharedPoolSettings<TSource>, new() {

		#region Inner classes.
		[Serializable]
		private class ContainerToSettingsDictionary : SerialisableDictionary<GameObject, ContainerSettings> {

		}

		[Serializable]
		private class PoolToSettingsDictionary : SerialisableDictionary<TPool, PoolDisplaySettings> {

		}
		#endregion

		#region Fields.
		[SerializeField, HideInInspector] private ContainerToSettingsDictionary containerDisplaySettings = new ContainerToSettingsDictionary();
		[SerializeField, HideInInspector] private PoolToSettingsDictionary poolDisplaySettings = new PoolToSettingsDictionary();

		[SerializeField, HideInInspector] private BoolEditorChangeValue defaultSettingsExpanded = new BoolEditorChangeValue(false);
		[SerializeField, HideInInspector] private BoolEditorChangeValue poolViewExpanded = new BoolEditorChangeValue(true);
		[SerializeField, HideInInspector] private BoolEditorChangeValue loosePoolContainerExpanded = new BoolEditorChangeValue(true);
		[SerializeField, HideInInspector] private BoolEditorChangeValue sortAlphabetically = new BoolEditorChangeValue(false);
		[SerializeField, HideInInspector] private BoolEditorChangeValue showContainers = new BoolEditorChangeValue(true);

		[SerializeField, HideInInspector] private string loosePoolsContainerName = "Loose Pools";
		#endregion

		#region Properties.
		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the default settings should be shown in the inspector.
		/// </summary>
		public BoolEditorChangeValue DefaultSettingsExpanded => this.defaultSettingsExpanded;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the object pools should be shown in the inspector.
		/// </summary>
		public BoolEditorChangeValue PoolViewExpanded => this.poolViewExpanded;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the Loose Pools container should be shown in the inspector.
		/// </summary>
		public BoolEditorChangeValue LoosePoolContainerExpanded => this.loosePoolContainerExpanded;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the containers and pools should be sorted alphabetically.
		/// </summary>
		public BoolEditorChangeValue SortAlphabetically => this.sortAlphabetically;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the containers should be shown in the inspector.
		/// </summary>
		public BoolEditorChangeValue ShowContainers => this.showContainers;

		/// <summary>
		/// Gets or sets the name of the loose pools container - the container that displays pools that are not children of the manager.
		/// </summary>
		public string LoosePoolsContainerName {
			get { return this.loosePoolsContainerName; }
			set { this.loosePoolsContainerName = value; }
		}
		#endregion
		
		#region Methods.
		/// <summary>
		/// Gets the display settings for the specified container.
		/// </summary>
		/// <param name="container">The container whose display settings should be returned.</param>
		/// <returns>The display settings for the specified container.</returns>
		internal ContainerSettings GetDisplaySettings(GameObject container) {
			ContainerSettings settings;
			if (!this.containerDisplaySettings.TryGetValue(container, out settings)) {
				this.containerDisplaySettings[container] = settings = new ContainerSettings();
			}

			return settings;
		}

		/// <summary>
		/// Gets the display settings for the specified pool.
		/// </summary>
		/// <param name="pool">The pool whose display settings should be returned.</param>
		/// <returns>The display settings for the specified pool.</returns>
		internal PoolDisplaySettings GetDisplaySettings(TPool pool) {
			PoolDisplaySettings settings;
			if (!this.poolDisplaySettings.TryGetValue(pool, out settings)) {
				this.poolDisplaySettings[pool] = settings = new PoolDisplaySettings();
			}

			return settings;
		}

		/// <summary>
		/// Changes <see cref="EditorChangeValue{T}.CurrentValue"/> to <see cref="EditorChangeValue{T}.TargetValue"/> for all <see cref="EditorChangeValue{T}"/>.
		/// </summary>
		public void ChangeValues() {
			this.defaultSettingsExpanded.ChangeValue();
			this.poolViewExpanded.ChangeValue();
			this.loosePoolContainerExpanded.ChangeValue();
			this.sortAlphabetically.ChangeValue();
			this.showContainers.ChangeValue();

			foreach (var settings in this.containerDisplaySettings.Values) {
				settings.ChangeValues();
			}
			foreach (var settings in this.poolDisplaySettings.Values) {
				settings.ChangeValues();
			}
		}
		#endregion

	}

}