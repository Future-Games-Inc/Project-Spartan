﻿using System.Diagnostics.CodeAnalysis;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A component that allows pooling of multiple associated <see cref="AudioSource"/> components.
	/// </summary>
	//[DisallowMultipleComponent]
	[RequireComponent(typeof(AudioSource))]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	public class PoolableAudioSource : MonoBehaviour, IPoolable {

		[SerializeField]
		[Tooltip("The " + nameof(AudioSource) + " components that are to be reset. Leave blank to automatically find in children.")]
		private AudioSource[] audioSources;

		/// <summary>
		/// A value indicating whether the audio sources will automatically start playing when the instance is acquired from the pool.
		/// </summary>
		/// <remarks>
		/// Setting this property to <see langword="true"/> will automatically call <see cref="AudioSource.Play()"/> on the audio sources
		/// attached to this <see cref="GameObject"/>. This provides the same behaviour as <see cref="AudioSource.playOnAwake"/>, but
		/// for use with pooling.
		/// </remarks>
		public bool PlayOnAcquire = false;
		
		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private void Awake() {
			// Allow the audio sources to be set up in the inspector, or automatically find them if they weren't set up.
			if (this.audioSources == null || this.audioSources.Length == 0) {
				this.audioSources = this.GetComponentsInChildren<AudioSource>();
			}
		}

		/// <inheritdoc />
		void IPoolable.Acquire() {
			if (this.PlayOnAcquire) {
				foreach (var audioSource in this.audioSources) {
					// Skip any that have been destroyed.
					if (audioSource == null) continue;

					audioSource.Play();
				}
			}
		}

		/// <inheritdoc />
		void IPoolable.Release() {
			// Stop playback and reset playback time to the beginning.
			foreach (var audioSource in this.audioSources) {
				// Skip any that have been destroyed.
				if (audioSource == null) continue;

				audioSource.Stop();
				audioSource.timeSamples = 0;
			}
		}

	}

}