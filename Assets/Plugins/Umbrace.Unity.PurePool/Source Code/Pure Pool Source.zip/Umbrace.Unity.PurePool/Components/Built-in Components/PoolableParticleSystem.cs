﻿using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A component that allows pooling of multiple associated <see cref="ParticleSystem"/> components.
	/// </summary>
	[DisallowMultipleComponent]
	[RequireComponent(typeof(ParticleSystem))]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	public class PoolableParticleSystem : MonoBehaviour, IPoolable {

		[SerializeField]
		[Tooltip("The " + nameof(ParticleSystem) + " components that are to be reset. Leave blank to automatically find in children.")]
		private ParticleSystem[] particleSystems;

		/// <summary>
		/// A value indicating whether to set the particle systems into play mode and enable emitting when the instance is acquired from the pool.
		/// </summary>
		/// <remarks>
		/// Setting this property to <see langword="true"/> will automatically call <see cref="ParticleSystem.Play()"/> on the particle systems
		/// attached to this <see cref="GameObject"/>. This provides the same behaviour as <see cref="ParticleSystem.MainModule.playOnAwake"/>, but
		/// for use with pooling.
		/// </remarks>
		public bool PlayOnAcquire = false;

		/// <summary>
		/// A value indicating whether to remove all particles in the particle systems when the instance is released to the pool.
		/// </summary>
		/// <remarks>
		/// Setting this property to <see langword="true"/> will automatically call <see cref="ParticleSystem.Clear()"/> on the particle systems
		/// attached to this <see cref="GameObject"/>.
		/// </remarks>
		public bool ClearOnRelease = true;

		/// <summary>
		/// A value indicating whether to release the <see cref="GameObject"/> this component is attached to when the particle system is done.
		/// </summary>
		/// <remarks>
		/// When enabled, the <see cref="PoolableParticleSystem"/> will wait until the particle system has completed and all particles are dead,
		/// before automatically releasing the <see cref="GameObject"/> to the first <see cref="GameObjectPoolManager"/> found in the scene.
		/// </remarks>
		public bool AutoReleaseWhenDone = false;

		[SuppressMessage("ReSharper", "UnusedMember.Local")]
		private void Awake() {
			// Allow the particle systems to be set up in the inspector, or automatically find them if they weren't set up.
			if (this.particleSystems == null || this.particleSystems.Length == 0) {
				this.particleSystems = this.GetComponentsInChildren<ParticleSystem>();
			}
		}

		/// <inheritdoc />
		void IPoolable.Acquire() {
			// Begin playing the particle systems.
			if (this.PlayOnAcquire) {
				foreach (var particleSystem in this.particleSystems) {
					// Skip any that have been destroyed.
					if (particleSystem == null) continue;

					particleSystem.Play();
				}
			}

			if (this.AutoReleaseWhenDone) {
				this.StartCoroutine(this.ReleaseOnCompletion());
			}
		}

		/// <inheritdoc />
		void IPoolable.Release() {
			// Stop playback, and optionally clear the emitted particles.
			foreach (var particleSystem in this.particleSystems) {
				// Skip any that have been destroyed.
				if (particleSystem == null) continue;

				particleSystem.Stop();

				if (this.ClearOnRelease) {
					particleSystem.Clear();
				}
			}
		}

		private IEnumerator ReleaseOnCompletion() {
			// Wait until the last particle system is done.
			yield return new WaitForSeconds(this.particleSystems.Max(particleSystem => particleSystem.main.duration));

			// Ensure the particle systems have completed and all particles are dead, even though the duration has been reached.
			while (this.particleSystems.Any(particleSystem => particleSystem.IsAlive())) {
				yield return new WaitForSeconds(1);
			}

			GameObjectPoolManager.Instance.Release(this.gameObject);
		}

	}

}