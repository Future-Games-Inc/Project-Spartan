﻿using System;

using Umbrace.Unity.PurePool.ForEditor;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Editor {

	/// <summary>
	/// A container class that holds display-related settings for object pools.
	/// </summary>
	[Serializable]
	internal class PoolDisplaySettings {

		#region Fields.
		[SerializeField] private BoolEditorChangeValue showDetails = new BoolEditorChangeValue();
		[SerializeField] private BoolEditorChangeValue showStatistics = new BoolEditorChangeValue();
		[SerializeField] private BoolEditorChangeValue showDefinition = new BoolEditorChangeValue();

		[SerializeField] private BoolEditorChangeValue statisticsExpanded = new BoolEditorChangeValue();
		[SerializeField] private BoolEditorChangeValue definitionExpanded = new BoolEditorChangeValue();
		[SerializeField] private BoolEditorChangeValue eventsExpanded = new BoolEditorChangeValue();
		#endregion

		#region Properties.
		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the detailed/advanced pool settings should be displayed in the inspector.
		/// </summary>
		public BoolEditorChangeValue ShowDetails => this.showDetails;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the pool's runtime statistics should be displayed in the inspector.
		/// </summary>
		public BoolEditorChangeValue ShowStatistics => this.showStatistics;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the pool's definition (its settings at the time it was initialised) should be displayed in the inspector.
		/// </summary>
		public BoolEditorChangeValue ShowDefinition => this.showDefinition;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the pool's runtime statistics should be expanded in the inspector.
		/// </summary>
		public BoolEditorChangeValue StatisticsExpanded => this.statisticsExpanded;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the pool's definition (its settings at the time it was initialised) should be expanded in the inspector.
		/// </summary>
		public BoolEditorChangeValue DefinitionExpanded => this.definitionExpanded;

		/// <summary>
		/// Gets a <see cref="BoolEditorChangeValue"/> indicating whether the pool's UnityEvents foldout should be expanded in the inspector.
		/// </summary>
		public BoolEditorChangeValue EventsExpanded => this.eventsExpanded;
		#endregion

		#region Methods.
		/// <summary>
		/// Updates the <see cref="EditorChangeValue{T}"/> objects to their new value.
		/// This should be called at the start of the <see cref="EventType.Layout"/> pass.
		/// </summary>
		public void ChangeValues() {
			this.showDetails.ChangeValue();
			this.showStatistics.ChangeValue();
			this.showDefinition.ChangeValue();
			this.statisticsExpanded.ChangeValue();
			this.definitionExpanded.ChangeValue();
			this.eventsExpanded.ChangeValue();
		}
		#endregion

	}

}