﻿using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A component that will automatically be attached to an instance of a pooled object,
	/// to provide notifications when the object is acquired from, or released to, the pool.
	/// </summary>
	[DisallowMultipleComponent]
	[AddComponentMenu("")] // Hide this script in the Components menu of the editor.
	public class PoolableComponent : PoolableObject<SerialisableType> {
		
	}

}