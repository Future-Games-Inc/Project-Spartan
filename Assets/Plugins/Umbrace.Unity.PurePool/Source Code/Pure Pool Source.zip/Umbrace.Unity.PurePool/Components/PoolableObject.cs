﻿using System;
using System.Collections.Generic;

using Umbrace.Unity.PurePool.ForEditor;

using UnityEngine;
using UnityEngine.EventSystems;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A component that will automatically be attached to an instance of a pooled object,
	/// to provide notifications when the object is acquired from, or released to, the pool.
	/// </summary>
	/// <typeparam name="T">The type of object being pooled.</typeparam>
	public abstract class PoolableObject<T> : MonoBehaviour {

		// TODO: Create a custom Editor for PoolableObject to display some of its settings.
		// TODO: Add a property to allow a choice of SendMessage or BroadcastMessage, as well as IPoolable from only the root object (GetComponents) or from all children (GetComponentsInChildren).

		#region Constants.
		private const string OnAcquireMethodName = "OnAcquire";
		private const string OnReleaseMethodName = "OnRelease";
		#endregion

		#region Fields.
		[SerializeField, HideInInspector] private bool initialised;

		[SerializeField] private T sourceObject;
		[SerializeField] private NotificationMode notificationMode;
		
		[SerializeField, HideInInspector] private bool isInPool;

		[SerializeField, HideInInspector] private bool expectDestroy;
		[SerializeField, HideInInspector] private bool expectNoPool;
		[SerializeField, HideInInspector] private bool cacheComponents = true;

		private bool applicationQuit;
		private List<IPoolable> cachedPoolableComponents;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets or sets a value indicating whether to cache the components found on this <see cref="GameObject"/> that implement <see cref="IPoolable"/>.
		/// </summary>
		public bool CachePoolableComponents {
			get => this.cacheComponents;
			set {
				if (value == this.cacheComponents) return;
				this.cacheComponents = value;

				if (value) {
					this.RefreshCache();
				} else {
					this.ClearCache();
				}
			}
		}
		
		/// <summary>
		/// Gets the source object that this pooled object is a clone of.
		/// </summary>
		public T SourceObject {
			get => this.sourceObject;
			internal set {
				// Only allow the source object to be set once.
				if (this.sourceObject != null) return;
				this.sourceObject = value;
			}
		}

		/// <summary>
		/// Gets or sets the way in which pooled objects are notified about being acquired from, and returned to, the pool.
		/// </summary>
		public NotificationMode NotificationMode {
			get => this.notificationMode;
			set => this.notificationMode = value;
		}

		/// <summary>
		/// Gets a value indicating whether the pooled object is currently unacquired and contained by the object pool.
		/// </summary>
		public bool IsInPool {
			get => this.isInPool;
			internal set => this.isInPool = value;
		}

		/// <summary>
		/// Gets or sets a value indicating whether the poolable object has been initialised.
		/// </summary>
		/// <remarks>
		/// An initialised <see cref="PoolableObject{T}"/> has its <see cref="SourceObject"/> and <see cref="NotificationMode"/> properties set,
		/// as well as any other appropriate values.
		/// </remarks>
		internal bool Initialised {
			get => this.initialised;
			set => this.initialised = value;
		}

		/// <summary>
		/// Gets or sets a value indicating whether the destruction of the object or component was expected.
		/// </summary>
		/// <remarks>
		/// Destruction is most often expected when the object is being destroyed by the pool, because pooling has been disabled.
		/// The object is not released to the pool and not processed as if it is being released, but is simply destroyed instead.
		/// </remarks>
		internal bool ExpectDestroy {
			get => this.expectDestroy;
			set => this.expectDestroy = value;
		}

		/// <summary>
		/// Gets or sets a value indicating whether it is expected that there will be no pool for the instance to be returned to.
		/// </summary>
		internal bool ExpectNoPool {
			get => this.expectNoPool;
			set => this.expectNoPool = value;
		}

		/// <summary>
		/// Gets the components found on this <see cref="GameObject"/> that implement <see cref="IPoolable"/>.
		/// </summary>
		private List<IPoolable> PoolableComponents {
			get {
				// If caching is disabled, look up the components directly.
				if (!this.CachePoolableComponents) {
					this.cachedPoolableComponents.Clear();
					this.gameObject.GetComponents<IPoolable>(this.cachedPoolableComponents);
					return this.cachedPoolableComponents;
				}

				// If caching is enabled but the cache is empty, refresh the cache.
				if (this.cachedPoolableComponents == null) {
					this.RefreshCache();
				}

				return this.cachedPoolableComponents;
			}
		}
		#endregion

		#region Events.
		/// <summary>
		/// Occurs when the <see cref="PoolableObject{T}"/> is destroyed.
		/// </summary>
		public event EventHandler<DestroyedEventArgs> Destroyed;
		#endregion

		#region MonoBehaviour methods.
		private void Awake() {
			// Cache the IPoolable components.
			if (this.CachePoolableComponents) {
				this.RefreshCache();
			}
		}

//#if UNITY_EDITOR
//		private void OnValidate() {
//			// This is for the Editor only. OnValidate is not called in player builds.
//			// Cache the IPoolable components. The cache can't be serialised so it needs repopulating.
//			if (this.CachePoolableComponents && this.cachedPoolableComponents == null) {
//				this.RefreshCache();
//			}
//		}
//#endif

		private void OnDestroy() {
			// Inform the pool that owns this PoolableObject that it's been destroyed. The game object this component lives on might still exist, but it can't be returned to the pool.
			this.OnDestroyed();
		}

		private void OnApplicationQuit() {
			this.applicationQuit = true;
		}
		#endregion

		#region Public methods.
		/// <summary>
		/// Informs all poolable components that the object has been acquired from the pool.
		/// </summary>
		public void OnAcquire() {
			// Call the OnReinitialise method in all components on this object.
			if (this.SupportsMode(NotificationMode.SendMessage)) {
				this.gameObject.SendMessage(PoolableObject<T>.OnAcquireMethodName, SendMessageOptions.DontRequireReceiver);
			}

			// Call the Reinitialise method from IPoolable in all components on this object.
			if (this.SupportsMode(NotificationMode.Interface)) {
				foreach (var poolable in this.PoolableComponents) {
					// Ensure the component hasn't been destroyed.
					var monoBehaviour = (MonoBehaviour)poolable;
					if (monoBehaviour != null) {
						poolable.Acquire();
					}
				}
			}

			if (this.SupportsMode(NotificationMode.UnityMessagingInterface)) {
				// This only calls the Reinitialise method on the components on this game object, and not on those in child objects.
				ExecuteEvents.Execute<IPoolable>(this.gameObject, null, (obj, data) => obj.Acquire()); // Delegate doesn't capture any variables so the compiler should cache it.
			}
		}

		/// <summary>
		/// Informs all poolable components that the object has been released back to the pool.
		/// </summary>
		public void OnRelease() {
			// Call the OnRelease method in all components on this object and its descendants.
			if (this.SupportsMode(NotificationMode.SendMessage)) {
				this.gameObject.SendMessage(PoolableObject<T>.OnReleaseMethodName, SendMessageOptions.DontRequireReceiver);
			}

			// Call the Release method from IPoolable in all components on this object and its descendants.
			if (this.SupportsMode(NotificationMode.Interface)) {
				foreach (var poolable in this.PoolableComponents) {
					// Ensure the component hasn't been destroyed.
					var monoBehaviour = (MonoBehaviour)poolable;
					if (monoBehaviour != null) {
						poolable.Release();
					}
				}
			}

			if (this.SupportsMode(NotificationMode.UnityMessagingInterface)) {
				// This only calls the Release method on the components on this game object, and not on those in child objects.
				ExecuteEvents.Execute<IPoolable>(this.gameObject, null, (obj, data) => obj.Release());
			}
		}

		/// <summary>
		/// Refreshes the cache of poolable components.
		/// </summary>
		public void RefreshCache() {
			// Only refresh the cache if caching is enabled.
			if (!this.CachePoolableComponents) return;

			// Cache the IPoolable components.
			if (this.cachedPoolableComponents == null) {
				this.cachedPoolableComponents = new List<IPoolable>();
			}

			this.gameObject.GetComponents<IPoolable>(this.cachedPoolableComponents);
		}

		/// <summary>
		/// Adds a poolable component to the cache.
		/// </summary>
		/// <param name="component">The component that implements <see cref="IPoolable"/>.</param>
		public void AddToCache(IPoolable component) {
			// Only add to the cache if caching is enabled.
			if (!this.CachePoolableComponents) return;

			if (component != null && !this.cachedPoolableComponents.Contains(component)) {
				this.cachedPoolableComponents.Add(component);
			}
		}

		/// <summary>
		/// Adds a poolable component to the cache.
		/// </summary>
		/// <param name="component">The component to add to the cache.</param>
		public void AddToCache(Component component) {
			// Only add to the cache if caching is enabled.
			if (!this.CachePoolableComponents) return;

			var poolable = component as IPoolable;
			this.AddToCache(poolable);
		}

		/// <summary>
		/// Removes a poolable component from the cache.
		/// </summary>
		/// <param name="component">The component that implements <see cref="IPoolable"/> to remove.</param>
		public void RemoveFromCache(IPoolable component) {
			// Only remove from the cache if caching is enabled.
			if (!this.CachePoolableComponents) return;

			if (component != null) {
				this.cachedPoolableComponents.Remove(component);
			}
		}

		/// <summary>
		/// Removes a poolable component from the cache.
		/// </summary>
		/// <param name="component">The component to remove from the cache.</param>
		public void RemoveFromCache(Component component) {
			// Only remove from the cache if caching is enabled.
			if (!this.CachePoolableComponents) return;

			var poolable = component as IPoolable;
			this.RemoveFromCache(poolable);
		}
		#endregion

		#region Private methods.
		/// <summary>
		/// Clears the poolable components cache.
		/// </summary>
		private void ClearCache() {
			this.cachedPoolableComponents = null;
		}

		/// <summary>
		/// Raises the <see cref="Destroyed"/> event.
		/// </summary>
		private void OnDestroyed() {
			// Pool the EventArgs to prevent creating even more garbage.
			this.Destroyed.InvokeEventPooled(this, EditorState.IsEditorApplicationExitingPlayMode || this.applicationQuit, this.expectDestroy);
		}

		/// <summary>
		/// Determines whether the specified notification mode is supported.
		/// </summary>
		/// <param name="flag">The notification mode to check.</param>
		/// <returns><see langword="true"/> if the specified notification mode is supported; otherwise, <see langword="false"/>.</returns>
		private bool SupportsMode(NotificationMode flag) {
			return (this.notificationMode & flag) == flag;
		}
		#endregion

	}

}