﻿using System.Diagnostics.CodeAnalysis;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains data for object pooling events.
	/// </summary>
	/// <typeparam name="T">The type of the object that the event is about.</typeparam>
	[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
	public class PoolObjectAcquiredEventArgs<T> : PoolObjectEventArgs<T> {

		// This object purposefully allows properties to be set, to allow the object to be pooled.
		
		/// <summary>
		/// Gets or sets a value indicating whether the acquired object was instantiated specifically for this acquisition,
		/// rather than being taken from the pool.
		/// </summary>
		public bool Instantiated { get; set; }

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolObjectAcquiredEventArgs{T}"/> class.
		/// </summary>
		/// <param name="instance">The object that the event is about.</param>
		/// <param name="instantiated">A value indicating whether the acquired object was instantiated specifically for this acquisition, rather than being taken from the pool.</param>
		public PoolObjectAcquiredEventArgs(T instance, bool instantiated) : base(instance) {
			this.Instantiated = instantiated;
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolObjectAcquiredEventArgs{T}"/> class.
		/// </summary>
		public PoolObjectAcquiredEventArgs() {
			// Do nothing.
		}

		/// <inheritdoc />
		protected override void ReleaseInternal() {
			base.ReleaseInternal();

			// Reset the values.
			this.Instantiated = false;
		}

	}

}