﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains data for object pooling events.
	/// </summary>
	[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
	public class PoolCanAcquireChangedEventArgs : EventArgs {

		// This object purposefully allows CanAcquire to be changed, to allow the object to be pooled.

		/// <summary>
		/// Gets or sets a value indicating whether an instance can be acquired from the pool.
		/// </summary>
		public bool CanAcquire { get; set; }

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolCanAcquireChangedEventArgs"/> class.
		/// </summary>
		/// <param name="canAcquire">A value indicating whether an instance can be acquired from the pool.</param>
		public PoolCanAcquireChangedEventArgs(bool canAcquire) {
			this.CanAcquire = canAcquire;
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolCanAcquireChangedEventArgs"/> class.
		/// </summary>
		public PoolCanAcquireChangedEventArgs() {
			// Do nothing.
		}

	}

}