﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Contains event data for events involving an <see cref="IPoolBase"/>.
	/// </summary>
	/// <typeparam name="TPool">The type of pool that the event is about.</typeparam>
	[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
	public class PoolEventArgs<TPool> : EventArgs, IPoolable
		where TPool : IPoolBase {

		/// <summary>
		/// Gets or sets the pool that caused, or was affected by, the event.
		/// </summary>
		public TPool Pool { get; set; }

		/// <summary>
		/// Initialises a new instance of the <see cref="PoolEventArgs{TPool}"/> class.
		/// </summary>
		public PoolEventArgs() {
			// Do nothing.
		}

		void IPoolable.Acquire() {
			// Do nothing.
		}

		void IPoolable.Release() {
			// Reset the values.
			this.Pool = default(TPool);
		}

	}

}