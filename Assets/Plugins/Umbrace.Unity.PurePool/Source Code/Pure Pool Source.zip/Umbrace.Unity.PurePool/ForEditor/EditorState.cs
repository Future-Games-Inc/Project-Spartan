﻿namespace Umbrace.Unity.PurePool.ForEditor {

	/// <summary>
	/// Contains information about the editor application state.
	/// </summary>
	internal static class EditorState {

		/// <summary>
		/// Gets or sets a value indicating whether the editor application is exiting from play mode. 
		/// </summary>
		/// <remarks>
		/// Requires the Umbrace.Unity.PurePool.Editor library to be loaded for the value to be set.
		/// </remarks>
		internal static bool IsEditorApplicationExitingPlayMode { get; set; }

	}

}