﻿using System;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEngine;

using Object = UnityEngine.Object;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A <see cref="MonoBehaviour"/> component that provides pooling of many instances of a particular <see cref="Component"/>, allowing the components to be recycled and reused.
	/// </summary>
	/// <remarks>
	/// <para>
	/// By virtue of being serialisable, <see cref="ComponentPool"/> can survive an assembly reload caused by live recompilation inside of the Unity editor.
	/// </para>
	/// <para>
	/// To use the <see cref="ComponentPool"/>, add a new instance of the component to a <see cref="GameObject"/>, and then set the properties to appropriate values.
	/// Once all properties have been set, invoke the <see cref="ComponentPool.Initialise()"/> method. A pool cannot be used without being initialised.
	/// </para>
	/// <note type="caution">
	/// <para>
	/// Unlike prefabs, components are difficult to pool correctly. As the components may have been used for any other purpose previously,
	/// there is no simple way of knowing which properties should be reset, and no easy way of resetting all properties.
	/// </para>
	/// <para>
	/// It's therefore very important when you pool a component that you take great care to ensure all properties that you plan on changing are
	/// reset. If necessary, you should implement a component deriving from <see cref="MonoBehaviour"/> which implements the <see cref="IPoolable"/>
	/// interface, and use this component to reset built-in Unity components.
	/// </para>
	/// </note>
	/// </remarks>
	/// <example>
	/// <code language="cs">
	/// // Create the pool as a component on a game object.
	/// var pool = gameObject.AddComponent&lt;ComponentPool&gt;();
	/// 
	/// // Set up the pool's properties.
	/// pool.Source = typeof(AudioSource);
	/// pool.InitialSize = 50;
	/// pool.MaximumSize = 200;
	/// pool.InstantiateWhenEmpty = true;
	/// pool.NotificationMode = NotificationMode.Interface;
	/// pool.LogMessages = LogLevel.Warning;
	/// 
	/// // Initialise the pool. It will contain 50 objects.
	/// pool.Initialise();
	/// 
	/// // Acquire one of the 50 objects from the pool. The Acquire method can be used safely if InstantiateWhenEmpty is true, or if a check is made to CanAcquire beforehand.
	/// AudioSource instance = pool.Acquire&lt;AudioSource&gt;();
	/// 
	/// // Acquire one of the 49 remaining objects from the pool. TryAcquire can be used safely even when InstantiateWhenEmpty is false.
	/// AudioSource secondInstance;
	/// if (pool.TryAcquire(out secondInstance)) {
	/// 	// Release the object back to the pool. It now contains 49 objects again.
	/// 	pool.Release(secondInstance);
	///	}
	/// 
	/// // Release the object back to the pool. It now contains 50 objects.
	/// pool.Release(instance);
	/// </code>
	/// </example>
	/// <seealso cref="ComponentPoolManager"/>
	/// <seealso cref="SerialisableComponentPool"/>
	/// <seealso cref="IComponentPoolSettings"/>
	/// <seealso cref="IObjectPool{T}"/>
	public class ComponentPool : PoolBase<Type, Component, ComponentPoolSettings>, IComponentPoolSettings {

		#region Fields.
		[SerializeField, HideInInspector] private SerialisableComponentPool pool;
		#endregion

		#region Properties.
		/// <inheritdoc />
		protected override SerialisableObjectPool<Component> Pool {
			get => this.pool;
			set => this.pool = (SerialisableComponentPool)value;
		}

		/// <inheritdoc />
		public override NotificationMode NotificationMode {
			get => this.Settings.NotificationMode;
			set {
				this.Settings.NotificationMode = value;

				if (this.IsInitialised) {
					this.pool.NotificationMode = value;
				}
			}
		}

		/// <inheritdoc />
		public override bool ReparentPooledObjects {
			get => this.Settings.ReparentPooledObjects;
			set {
				this.Settings.ReparentPooledObjects = value;

				if (this.IsInitialised) {
					this.pool.ReparentPooledObjects = value;
				}
			}
		}

		/// <inheritdoc />
		public override bool WarnOnDestroy {
			get => this.Settings.WarnOnDestroy;
			set {
				this.Settings.WarnOnDestroy = value;

				if (this.IsInitialised) {
					this.pool.WarnOnDestroy = value;
				}
			}
		}

		/// <inheritdoc />
		public ComponentTypeCollection AdditionalComponentTypes => this.Settings.AdditionalComponentTypes;
		#endregion

		#region UnityEvents.
		/// <summary>
		/// Occurs when a new instance of the component is instantiated.
		/// </summary>
		[SerializeField, HideInInspector]
		public ComponentEvent ObjectInstantiatedEvent = new ComponentEvent();

		/// <summary>
		/// Occurs when an instance of the component is acquired from the pool.
		/// </summary>
		[SerializeField, HideInInspector]
		public ComponentEvent ObjectAcquiredEvent = new ComponentEvent();

		/// <summary>
		/// Occurs when an instance of the component is released back to the pool.
		/// </summary>
		[SerializeField, HideInInspector]
		public ComponentEvent ObjectReleasedEvent = new ComponentEvent();

		/// <summary>
		/// Occurs when an instance of the component is destroyed.
		/// </summary>
		[SerializeField, HideInInspector]
		public ComponentEvent ObjectDestroyedEvent = new ComponentEvent();
		#endregion

		#region Initialisation and shutdown methods.
		/// <inheritdoc />
		protected override bool CanInitialise() {
			if (this.Source != null) {
				return true;
			} else {
				DebugHelper.LogWarning($"Cannot initialise {nameof(ComponentPool)}. " +
										$"{nameof(this.Source)} must be set before {nameof(this.Start)} is called. " +
										$"Set {nameof(this.InitialiseOnStart)} to false if you wish to initialise the pool manually.{Environment.NewLine}" +
										$"{nameof(ComponentPool)} on {this.transform.GetPath()}.");
				return false;
			}
		}
		
		// ReSharper disable once RedundantOverriddenMember
		protected override void OnDestroy() {
			// TODO: Unregister the Destroyed event handler on acquired pool objects, otherwise they'll continue to hold a reference to this component. Though when the objects are eventually destroyed, the reference will be removed.
			// The PoolableObject component would have to sign up to the pool's Destroyed event, and then ask the pool to unregister.

			base.OnDestroy();
		}
		#endregion

		#region Initialise method.
		/// <inheritdoc />
		public override void Initialise() {
			Contract.RequiresMessage(!this.IsInitialised, "Unable to initialise the pool as it's already been initialised. A pool can only be initialised once.");
			Contract.RequiresMessage(this.Source != null, () => $"Unable to initialise the pool as the component type has not been set. Please set the {nameof(this.Source)} property prior to initialising.");

			base.Initialise();

			DebugHelper.Log(this.LogMessages, $"Object pool for '{this.Source.Name}' initialised with {this.InitialSize}/{this.MaximumSize} instances.");
		}
		#endregion

		#region Acquire methods.
		// ReSharper disable once RedundantOverriddenMember
		/// <summary>
		/// Acquires an instance of the component.
		/// </summary>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.TryAcquire"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public override Component Acquire() => base.Acquire();

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Transform, out T)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public Component Acquire(Transform parent) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.pool.Acquire(parent);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the components's transform to.</param>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Vector3, Quaternion, out T)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public Component Acquire(Vector3 position, Quaternion rotation) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.pool.Acquire(position, rotation);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Transform, Vector3, Quaternion, out T)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public Component Acquire(Transform parent, Vector3 position, Quaternion rotation) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.pool.Acquire(parent, position, rotation);
		}
		#endregion

		#region Acquire<T> methods.
		/// <summary>
		/// Acquires an instance of the component.
		/// </summary>
		/// <typeparam name="T">The type of the component.</typeparam>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(out T)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public T Acquire<T>() where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.pool.Acquire<T>();
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <typeparam name="T">The type of the component.</typeparam>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Transform, out T)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public T Acquire<T>(Transform parent) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.pool.Acquire<T>(parent);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the components's transform to.</param>
		/// <typeparam name="T">The type of the component.</typeparam>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Vector3, Quaternion, out T)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public T Acquire<T>(Vector3 position, Quaternion rotation) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.pool.Acquire<T>(position, rotation);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <typeparam name="T">The type of the component.</typeparam>
		/// <returns>An instance of the component from the pool.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.CanAcquire"/>
		/// <seealso cref="TryAcquire{T}(Transform, Vector3, Quaternion, out T)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public T Acquire<T>(Transform parent, Vector3 position, Quaternion rotation) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.Acquire)} method cannot be called until the pool has been initialised.");
			Contract.RequiresMessage(this.CanAcquire, () => $"Unable to acquire an instance from the pool. Always check {nameof(this.CanAcquire)} before calling {nameof(this.Acquire)}.");

			return this.pool.Acquire<T>(parent, position, rotation);
		}
		#endregion

		#region TryAcquire methods.
		// ReSharper disable once RedundantOverriddenMember
		/// <summary>
		/// Acquires an instance of the component.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Acquire"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public override bool TryAcquire(out Component instance) => base.TryAcquire(out instance);

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Transform)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire(Transform parent, out Component instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(parent, out instance);

			return this.pool.TryAcquire(parent, out instance);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Vector3, Quaternion)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire(Vector3 position, Quaternion rotation, out Component instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(position, rotation, out instance);

			return this.pool.TryAcquire(position, rotation, out instance);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">he transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(Transform, Vector3, Quaternion)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire(Transform parent, Vector3 position, Quaternion rotation, out Component instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");
			
			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(parent, position, rotation, out instance);

			return this.pool.TryAcquire(parent, position, rotation, out instance);
		}
		#endregion

		#region TryAcquire<T> methods.
		/// <summary>
		/// Acquires an instance of the component.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <typeparam name="T">The type of the component.</typeparam>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}()"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire<T>(out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(out instance);

			return this.pool.TryAcquire(out instance);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <typeparam name="T">The type of the component.</typeparam>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Transform)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire<T>(Transform parent, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(parent, out instance);

			return this.pool.TryAcquire(parent, out instance);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <typeparam name="T">The type of the component.</typeparam>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Vector3, Quaternion)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire<T>(Vector3 position, Quaternion rotation, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(position, rotation, out instance);

			return this.pool.TryAcquire(position, rotation, out instance);
		}

		/// <summary>
		/// Acquires an instance of the component, and sets the parent transform, position and rotation of its <see cref="GameObject"/>.
		/// </summary>
		/// <param name="parent">The transform to which the component's <see cref="GameObject"/> should be parented.</param>
		/// <param name="position">The position to set the component's transform to.</param>
		/// <param name="rotation">The rotation to set the component's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of the component, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <typeparam name="T">The type of the component.</typeparam>
		/// <returns><see langword="true"/> if an instance of the component was acquired from the pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire{T}(Transform, Vector3, Quaternion)"/>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.Release"/>
		public bool TryAcquire<T>(Transform parent, Vector3 position, Quaternion rotation, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.TryAcquire)} method cannot be called until the pool has been initialised.");

			// If pooling is not enabled, try to acquire an instance through instantiation.
			if (!this.Enabled) return this.InternalTryInstantiate(parent, position, rotation, out instance);

			return this.pool.TryAcquire(parent, position, rotation, out instance);
		}
		#endregion

		#region InternalTryInstantiate methods.
		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Transform parent, out Component instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.gameObject.Set(parent, false);
			}
			return result;
		}

		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Vector3 position, Quaternion rotation, out Component instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.gameObject.Set(position, rotation);
			}
			return result;
		}

		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate(Transform parent, Vector3 position, Quaternion rotation, out Component instance) {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.gameObject.Set(parent, position, rotation);
			}
			return result;
		}
		#endregion

		#region InternalTryInstantiate<T> methods.
		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>.
		/// </summary>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate<T>(out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");

			this.pool.CheckType<T>();

			Component baseInstance;
			bool result = base.InternalTryInstantiate(out baseInstance);

			instance = (T)baseInstance;
			return result;
		}

		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate<T>(Transform parent, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.gameObject.Set(parent, false);
			}
			return result;
		}

		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its position and rotation.
		/// </summary>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate<T>(Vector3 position, Quaternion rotation, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.gameObject.Set(position, rotation);
			}
			return result;
		}

		/// <summary>
		/// Instantiates a new instance of the source object if <see cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/> is <see langword="true"/>, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instantiated object, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an object was instantiated; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="PoolBase{TSource,TInstance,TSettings}.InstantiateWhenEmpty"/>
		internal bool InternalTryInstantiate<T>(Transform parent, Vector3 position, Quaternion rotation, out T instance) where T : Component {
			Contract.RequiresMessage(this.IsInitialised, () => $"The {nameof(this.InternalTryInstantiate)} method cannot be called until the pool has been initialised.");
			
			bool result = this.InternalTryInstantiate(out instance);
			if (result) {
				instance.gameObject.Set(parent, position, rotation);
			}
			return result;
		}
		#endregion

		#region Event raisers.
		/// <summary>
		/// Raises the <see cref="PoolBase{TSource,TInstance,TSettings}.ObjectInstantiated"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was instantiated.</param>
		protected override void OnObjectInstantiated(Component instance) {
			base.OnObjectInstantiated(instance);

			this.ObjectInstantiatedEvent?.Invoke(instance);
		}

		/// <summary>
		/// Raises the <see cref="PoolBase{TSource,TInstance,TSettings}.ObjectAcquired"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was acquired from the pool.</param>
		/// <param name="instantiated">A value indicating whether the acquired object was instantiated specifically for this acquisition, rather than being taken from the pool.</param>
		protected override void OnObjectAcquired(Component instance, bool instantiated) {
			base.OnObjectAcquired(instance, instantiated);

			this.ObjectAcquiredEvent?.Invoke(instance);
		}

		/// <summary>
		/// Raises the <see cref="PoolBase{TSource,TInstance,TSettings}.ObjectReleased"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was released back to the pool.</param>
		/// <param name="destroying">A value indicating whether the released object is about to be destroyed.</param>
		protected override void OnObjectReleased(Component instance, bool destroying) {
			base.OnObjectReleased(instance, destroying);

			this.ObjectReleasedEvent?.Invoke(instance);
		}

		/// <summary>
		/// Raises the <see cref="PoolBase{TSource,TInstance,TSettings}.ObjectDestroyed"/> event.
		/// </summary>
		/// <param name="instance">The instance of the source object that was destroyed.</param>
		protected override void OnObjectDestroyed(Component instance) {
			base.OnObjectDestroyed(instance);

			this.ObjectDestroyedEvent?.Invoke(instance);
		}
		#endregion

		#region PoolBase override methods.
		/// <inheritdoc />
		protected override ComponentPoolSettings CreateSettingsClone(ComponentPoolSettings settings) {
			return new ComponentPoolSettings(settings);
		}

		/// <inheritdoc />
		protected override SerialisableObjectPool<Component> CreateInternalPool() {
			// Construct the internal pool.
			return new SerialisableComponentPool(this.Source, this.transform, this.Settings.AdditionalComponentTypes.ToArray()) {
				NotificationMode = this.NotificationMode,
				ReparentPooledObjects = this.ReparentPooledObjects
			};
		}

		/// <inheritdoc />
		protected override void DestroyInstance(Component instance) {
			// We expect the PoolableComponent to be destroyed.
			var poolable = instance.GetComponent<PoolableComponent>();
			if (poolable != null) {
				poolable.ExpectDestroy = true;
			}
			Object.Destroy(instance.gameObject);
		}
		#endregion

	}

}