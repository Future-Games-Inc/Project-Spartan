﻿using System;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// A container class for the settings that a <see cref="ComponentPool"/> can have.
	/// </summary>
	[Serializable]
	public class ComponentPoolSettings : SharedPoolSettings<Type>, IComponentPoolSettings {

		#region Fields.
		private static readonly ComponentPoolSettings defaultSettings = new ComponentPoolSettings(null) {
			InitialSize = 10,
			InitialiseOnStart = true,
			Enabled = true,
			LogMessages = LogLevel.Information,
			NotificationMode = NotificationMode.Interface,
			DontDestroyOnLoad = false,
			InstantiateWhenEmpty = true,
			ReparentPooledObjects = true,
			MaximumSize = 20,
			RecordStatistics = true,
			WarnOnDestroy = true
		};

		[SerializeField, HideInInspector]
		private SerialisableType componentType;

		[SerializeField, HideInInspector]
		private ComponentTypeCollection additionalComponentTypes = new ComponentTypeCollection();
		#endregion

		#region Properties.
		/// <summary>
		/// Gets the default settings.
		/// </summary>
		public static ComponentPoolSettings DefaultSettings {
			get {
				if (!ComponentPoolSettings.defaultSettings.Frozen) {
					ComponentPoolSettings.defaultSettings.Freeze();
				}

				return ComponentPoolSettings.defaultSettings;
			}
		}

		/// <summary>
		/// Gets or sets the game object that the pool will be used for.
		/// </summary>
		/// <exception cref="InvalidOperationException">When setting the value of <see cref="Source"/>, if the <see cref="ComponentPoolSettings"/> has been frozen.</exception>
		public override Type Source {
			get => this.componentType?.Type;
			set {
				this.EnsureNotFrozen();
				this.componentType = new SerialisableType(value);
			}
		}

		/// <summary>
		/// Gets a list of additional component types that should be added to the same GameObject as the pooled component.
		/// </summary>
		public ComponentTypeCollection AdditionalComponentTypes => this.additionalComponentTypes;
		#endregion

		#region Constructors.
		/// <summary>
		/// Initialises a new instance of the <see cref="ComponentPoolSettings"/> class.
		/// </summary>
		public ComponentPoolSettings() : this(ComponentPoolSettings.DefaultSettings) {
			// Do nothing.
		}

		/// <summary>
		/// Initialises a new instance of the <see cref="ComponentPoolSettings"/> class, using the specified settings.
		/// </summary>
		/// <param name="settings">The settings to copy the values from.</param>
		public ComponentPoolSettings(ComponentPoolSettings settings) : base(settings) {
			if (settings != null) {
				this.componentType = settings.componentType;
				this.additionalComponentTypes = new ComponentTypeCollection(settings.additionalComponentTypes);
			}
		}
		#endregion

		#region Methods.
		/// <inheritdoc />
		public override void Freeze() {
			base.Freeze();

			this.additionalComponentTypes.Freeze();
		}
		#endregion

	}

}