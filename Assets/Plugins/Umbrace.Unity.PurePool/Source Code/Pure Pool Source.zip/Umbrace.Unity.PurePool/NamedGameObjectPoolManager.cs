﻿using System;
using System.Collections.Generic;
using System.Linq;

using Umbrace.Unity.Contracts;

using UnityEngine;

namespace Umbrace.Unity.PurePool {

	/// <summary>
	/// Provides named access to the pools of a <see cref="GameObjectPoolManager"/>.
	/// </summary>
	/// <remarks>
	/// Unlike <see cref="GameObjectPoolManager"/>, which uses object references to refer to the source object you
	/// wish to acquire an instance of, <see cref="NamedGameObjectPoolManager"/> instead uses a <see cref="string"/>
	/// name to refer to the source object.
	/// </remarks>
	/// <example>
	/// <code language="cs">
	/// // Create the component on a game object.
	///	var byName = gameObject.AddComponent&lt;NamedGameObjectPoolManager&gt;();
	/// 
	///	// Set up the properties.
	///	byName.Manager = manager;
	///	byName.AutoAddFromManager = true;
	/// 
	///	// Assign custom names to the objects being pooled.
	///	byName.SetName(prefab, "Asteroid_1");
	/// 
	///	// Acquire an instance of the "prefab" object, using its string name.
	///	var instance = byName.Acquire("Asteroid_1");
	/// 
	///	// Access the GameObjectPool that stores the "prefab" instances.
	///	GameObjectPool asteroidPool = byName["Asteroid_1"];
	/// 
	///	// Release the acquired instance back to the pool.
	///	byName.Release(instance);
	/// </code>
	/// </example>
	public class NamedGameObjectPoolManager : MonoBehaviour, ISerializationCallbackReceiver {

		// TODO: Use a two-way dictionary.
		// TODO: Move all settings to a serialisable class, and add import/export support?

		#region Fields.
		/// <summary>
		/// A dictionary that maps from a source object name to its corresponding source GameObject.
		/// </summary>
		[SerializeField, HideInInspector]
		private StringToGameObjectDictionary nameDictionary = new StringToGameObjectDictionary();

		/// <summary>
		/// The pool manager whose pools should be accessed by name.
		/// </summary>
		[SerializeField, HideInInspector]
		private GameObjectPoolManager manager;

		/// <summary>
		/// A value indicating whether to automatically provide named access to the pools attached to the manager.
		/// </summary>
		[SerializeField, HideInInspector]
		private bool autoAddFromManager;

		/// <summary>
		/// A value indicating whether to attempt to locate unrecognised names using <see cref="Resources.Load(string)"/>.
		/// </summary>
		[SerializeField, HideInInspector]
		private bool useResources;

		/// <summary>
		/// A value indicating whether the <see cref="PoolManagerBase{TManagerSettings,TPool,TPoolSettings,TSource,TInstance}.PoolAttached"/> event is being handled.
		/// </summary>
		private bool eventHandlerAttached;
		#endregion

		#region Properties.
		/// <summary>
		/// Gets or sets the pool manager whose pools should be accessed by name.
		/// </summary>
		public GameObjectPoolManager Manager {
			get => this.manager;
			set {
				if (this.manager == value) return;

				// Remove the PoolAttached handler from the current manager.
				if (this.manager != null && this.eventHandlerAttached) {
					this.Manager.PoolAttached -= this.ManagerOnPoolAttached;
					this.eventHandlerAttached = false;
				}

				this.manager = value;

				// Add the PoolAttached handler to the new manager.
				if (this.manager != null && this.AutoAddFromManager) {
					this.Manager.PoolAttached += this.ManagerOnPoolAttached;
					this.eventHandlerAttached = true;
				}
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to automatically provide named access to the pools attached to the manager.
		/// </summary>
		/// <remarks>
		/// When enabled, the <see cref="NamedGameObjectPoolManager"/> will listen for new pools being attached to its connected
		/// <see cref="GameObjectPoolManager"/>, and call <see cref="SetName"/> to assign a name for the new pool.
		/// The name is automatically generated from the name of the <see cref="GameObject"/> being pooled, which is the pool's source object.
		/// </remarks>
		public bool AutoAddFromManager {
			get => this.autoAddFromManager;
			set {
				if (this.autoAddFromManager == value) return;
				this.autoAddFromManager = value;

				// Either add or remove the PoolAttached handler to the current manager.
				if (this.autoAddFromManager && !this.eventHandlerAttached && this.Manager != null) {
					this.Manager.PoolAttached += this.ManagerOnPoolAttached;
					this.eventHandlerAttached = true;
				} else if (!this.autoAddFromManager && this.eventHandlerAttached && this.Manager != null) {
					this.Manager.PoolAttached -= this.ManagerOnPoolAttached;
					this.eventHandlerAttached = false;
				}
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether to attempt to locate unrecognised names using <see cref="Resources.Load(string)"/>.
		/// </summary>
		public bool UseResources {
			get => this.useResources;
			set => this.useResources = value;
		}

		/// <summary>
		/// Gets a list of the names currently assigned to game objects.
		/// </summary>
		public IEnumerable<KeyValuePair<string, GameObject>> AssignedNames => this.nameDictionary.ToList();
		#endregion

		#region Events.
		/// <summary>
		/// Occurs when the collection of named pools is changed.
		/// </summary>
		public event EventHandler Changed;
		#endregion

		#region Initialisation.
		private void Awake() {
			if (this.AutoAddFromManager) {
				if (this.Manager == null) {
					DebugHelper.LogWarning($"{nameof(this.AutoAddFromManager)} is true, but the {nameof(this.Manager)} property " +
											$"of {nameof(NamedGameObjectPoolManager)} has not been set.");
				} else {
					// Automatically set up the names of all pools already attached to the manager, using the name of the source object.
					foreach (var pool in this.Manager.Pools) {
						GameObject sourceObject = pool.Source;

						if (sourceObject != null) {
							// Check if a custom name is already assigned to this object.
							if (this.HasName(sourceObject)) {
								continue;
							}

							string name = sourceObject.name;

							// Check if the name is already in use for another object.
							GameObject existingObject;
							if (!this.TryGetGameObject(name, out existingObject)) {
								this.SetName(sourceObject, name);
							} else {
								DebugHelper.LogError($"{nameof(this.AutoAddFromManager)} encountered a duplicate object name ('{name}'). " +
													"You should set up a custom name that is unique to allow named access to this object.");
							}
						}
					}

					// Listen for newly-attached pools, to automatically map their source object's name to the pool.
					this.Manager.PoolAttached += this.ManagerOnPoolAttached; // This event handler cannot be serialised, so it's re-added in OnAfterDeserialize.
					this.eventHandlerAttached = true;
				}
			}
		}
		#endregion

		#region Acquire methods.
		/// <summary>
		/// Acquires an instance of the source object with the specified name, from an attached pool.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire(string, out GameObject)"/>
		/// <seealso cref="Release"/>
		public GameObject Acquire(string sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			this.EnsureManager();
			return this.Manager.Acquire(this.Locate(sourceObject));
		}

		/// <summary>
		/// Acquires an instance of the source object with the specified name from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire(string, Transform, out GameObject)"/>
		/// <seealso cref="Release"/>
		public GameObject Acquire(string sourceObject, Transform parent) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			this.EnsureManager();
			return this.Manager.Acquire(this.Locate(sourceObject), parent);
		}

		/// <summary>
		/// Acquires an instance of the source object with the specified name from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire(string, Transform, out GameObject)"/>
		/// <seealso cref="Release"/>
		public GameObject Acquire(string sourceObject, Transform parent, bool spawnInWorldSpace) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			this.EnsureManager();
			return this.Manager.Acquire(this.Locate(sourceObject), parent, spawnInWorldSpace);
		}
		
		/// <summary>
		/// Acquires an instance of the source object with the specified name from an attached pool, and sets its position and rotation.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire(string, Vector3, Quaternion, out GameObject)"/>
		/// <seealso cref="Release"/>
		public GameObject Acquire(string sourceObject, Vector3 position, Quaternion rotation) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			this.EnsureManager();
			return this.Manager.Acquire(this.Locate(sourceObject), position, rotation);
		}

		/// <summary>
		/// Acquires an instance of the source object with the specified name from an attached pool, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <returns>An instance of <paramref name="sourceObject"/> acquired from the pool.</returns>
		/// <seealso cref="CanAcquire"/>
		/// <seealso cref="TryAcquire(string, Vector3, Quaternion, Transform, out GameObject)"/>
		/// <seealso cref="Release"/>
		public GameObject Acquire(string sourceObject, Vector3 position, Quaternion rotation, Transform parent) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.Requires(this.CanAcquire(sourceObject));

			this.EnsureManager();
			return this.Manager.Acquire(this.Locate(sourceObject), position, rotation, parent);
		}
		#endregion

		#region TryAcquire(out GameObject) methods.
		/// <summary>
		/// Acquires an instance of the source object with the specified name, from an attached pool.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(string)"/>
		/// <seealso cref="Release"/>
		public bool TryAcquire(string sourceObject, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			GameObject source;
			instance = null;
			this.EnsureManager();
			return this.TryLocate(sourceObject, out source) && this.Manager.TryAcquire(source, out instance);
		}

		/// <summary>
		/// Acquires an instance of the source object with the specified name from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(string, Transform)"/>
		/// <seealso cref="Release"/>
		public bool TryAcquire(string sourceObject, Transform parent, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			GameObject source;
			instance = null;
			this.EnsureManager();
			return this.TryLocate(sourceObject, out source) && this.Manager.TryAcquire(source, parent, out instance);
		}

		/// <summary>
		/// Acquires an instance of the source object with the specified name from an attached pool, and sets its parent transform.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="spawnInWorldSpace"><see langword="true"/> if the original world position should be maintained when assigning the parent; otherwise, <see langword="false"/>.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(string, Transform)"/>
		/// <seealso cref="Release"/>
		public bool TryAcquire(string sourceObject, Transform parent, bool spawnInWorldSpace, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			GameObject source;
			instance = null;
			this.EnsureManager();
			return this.TryLocate(sourceObject, out source) && this.Manager.TryAcquire(source, parent, spawnInWorldSpace, out instance);
		}

		/// <summary>
		/// Acquires an instance of the source object with the specified name from an attached pool, and sets its position and rotation.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(string, Vector3, Quaternion)"/>
		/// <seealso cref="Release"/>
		public bool TryAcquire(string sourceObject, Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			GameObject source;
			instance = null;
			this.EnsureManager();
			return this.TryLocate(sourceObject, out source) && this.Manager.TryAcquire(source, position, rotation, out instance);
		}

		/// <summary>
		/// Acquires a disabled instance of the source object with the specified name from an attached pool, and sets its position and rotation.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(string, Vector3, Quaternion)"/>
		/// <seealso cref="Release"/>
		public bool TryAcquireDisabled(string sourceObject, Vector3 position, Quaternion rotation, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			GameObject source;
			instance = null;
			this.EnsureManager();
			return this.TryLocate(sourceObject, out source) && this.Manager.TryAcquireDisabled(source, position, rotation, out instance);
		}

		/// <summary>
		/// Acquires an instance of the source object with the specified name from an attached pool, and sets its parent transform, position and rotation.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to acquire an instance of.</param>
		/// <param name="position">The position to set the instance's transform to.</param>
		/// <param name="rotation">The rotation to set the instance's transform to.</param>
		/// <param name="parent">The transform to which the instance should be parented.</param>
		/// <param name="instance">When this method returns, contains the instance of <paramref name="sourceObject"/>, if one could be acquired; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> was acquired from an attached pool; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="Acquire(string, Vector3, Quaternion, Transform)"/>
		/// <seealso cref="Release"/>
		public bool TryAcquire(string sourceObject, Vector3 position, Quaternion rotation, Transform parent, out GameObject instance) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			GameObject source;
			instance = null;
			this.EnsureManager();
			return this.TryLocate(sourceObject, out source) && this.Manager.TryAcquire(source, position, rotation, parent, out instance);
		}
		#endregion

		#region Release(GameObject) method.
		/// <summary>
		/// Releases an instance of a game object that was previously acquired from a pool.
		/// </summary>
		/// <param name="instance">The instance to release back to the pool.</param>
		public void Release(GameObject instance) {
			Contract.RequiresNotNull(instance, nameof(instance));

			this.EnsureManager();
			this.Manager.Release(instance);
		}
		#endregion

		#region HasPool(string), GetPool(string), TryGetPool(string, out GameObjectPool) methods.
		/// <summary>
		/// Determines whether the manager has a pool that handles instances of the source object with the specified name.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to check.</param>
		/// <returns><see langword="true"/> if the manager has a pool that handles instances of <paramref name="sourceObject"/>; otherwise, <see langword="false"/>.</returns>
		public bool HasPool(string sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			this.EnsureManager();

			GameObject source;
			if (!this.TryLocate(sourceObject, out source)) return false;

			return this.Manager.HasPool(source);
		}

		/// <summary>
		/// Gets the pool that handles instances of the source object with the specified name.
		/// The manager must contain a matching pool to use this method.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to retrieve the pool for.</param>
		/// <returns>A <see cref="GameObjectPool"/> that handles instances of <paramref name="sourceObject"/>.</returns>
		public GameObjectPool GetPool(string sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));
			Contract.RequiresMessage(this.HasPool(sourceObject), _sourceObject => $"There are no pools that handle the specified object ({_sourceObject}) attached to the manager.", sourceObject);

			this.EnsureManager();

			GameObject source= this.Locate(sourceObject);

			return this.Manager.GetPool(source);
		}

		/// <summary>
		/// Gets the pool that handles instances of the source object with the specified name.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to retrieve the pool for.</param>
		/// <param name="pool">When this method returns, contains the pool that handles the specified game object, if one is found; otherwise, <see langword="null"/>. This parameter is passed uninitialised.</param>
		/// <returns><see langword="true"/> if the manager contains a pool that handles the specified game object; otherwise, <see langword="false"/>.</returns>
		public bool TryGetPool(string sourceObject, out GameObjectPool pool) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			this.EnsureManager();

			GameObject source;
			if (!this.TryLocate(sourceObject, out source)) {
				pool = null;
				return false;
			}

			return this.Manager.TryGetPool(source, out pool);
		}
		#endregion

		#region GetPooledCount(string), IsPoolEmpty(string), CanAcquire(string) methods.
		/// <summary>
		/// Gets the number of instances of the object with the specified name contained in the pool.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to check.</param>
		/// <returns>The number of instances of the specified object contained in the pool.</returns>
		public int GetPooledCount(string sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			this.EnsureManager();

			GameObject source;
			if (!this.TryLocate(sourceObject, out source)) return 0;

			return this.Manager.GetPooledCount(source);
		}

		/// <summary>
		/// Determines whether the pool is empty for instances of the object with the specified name.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to check.</param>
		/// <returns><see langword="true"/> if the pool is empty for instances of the specified object; otherwise, <see langword="false"/>.</returns>
		public bool IsPoolEmpty(string sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			this.EnsureManager();
			return this.GetPooledCount(sourceObject) == 0;
		}

		/// <summary>
		/// Determines whether an instance of the source object with the specified name can be acquired from its pool.
		/// </summary>
		/// <param name="sourceObject">The name of the game object to check.</param>
		/// <returns><see langword="true"/> if an instance of <paramref name="sourceObject"/> can be acquired from its pool; otherwise, <see langword="false"/>.</returns>
		/// <remarks>An instance can be acquired when its pool contains at least one instance, or when <see cref="IObjectPool.InstantiateWhenEmpty"/> is <see langword="true"/>.</remarks>
		public bool CanAcquire(string sourceObject) {
			Contract.RequiresNotNull(sourceObject, nameof(sourceObject));

			this.EnsureManager();

			GameObject source;
			if (!this.TryLocate(sourceObject, out source)) return false;

			return this.Manager.CanAcquire(source);
		}
		#endregion

		#region Name methods.
		/// <summary>
		/// Determines whether the specified name is currently assigned.
		/// </summary>
		/// <param name="name">The name to check.</param>
		/// <returns><see langword="true"/> if the specified name is currently assigned; otherwise, <see langword="false"/>.</returns>
		public bool HasName(string name) {
			Contract.RequiresNotNull(name, nameof(name));

			return this.nameDictionary.ContainsKey(name);
		}

		/// <summary>
		/// Determines whether the specified <see cref="GameObject"/> is currently assigned a name.
		/// </summary>
		/// <param name="gameObject">The <see cref="GameObject"/> to check.</param>
		/// <returns><see langword="true"/> if the specified <see cref="GameObject"/> is currently assigned a name; otherwise, <see langword="false"/>.</returns>
		public bool HasName(GameObject gameObject) {
			Contract.RequiresNotNull(gameObject, nameof(gameObject));

			string name;
			if (!this.TryGetName(gameObject, out name)) return false;
			return this.HasName(name);
		}

		/// <summary>
		/// Gets the <see cref="GameObject"/> that is currently assigned the specified name.
		/// </summary>
		/// <param name="name">The name that is currently assigned to a <see cref="GameObject"/>.</param>
		/// <returns>The <see cref="GameObject"/> that is currently assigned the specified name.</returns>
		/// <exception cref="KeyNotFoundException">If there is no <see cref="GameObject"/> currently assigned the specified name.</exception>
		/// <seealso cref="TryGetGameObject"/>
		public GameObject GetGameObject(string name) {
			Contract.RequiresNotNull(name, nameof(name));

			return this.nameDictionary[name];
		}

		/// <summary>
		/// Gets the <see cref="GameObject"/> that is currently assigned the specified name.
		/// </summary>
		/// <param name="name">The name that is currently assigned to a <see cref="GameObject"/>.</param>
		/// <param name="gameObject">
		/// When this method returns, contains the <see cref="GameObject"/> that is currently assigned the specified name,
		/// if one exists; otherwise, <see langword="null"/>. This parameter is passed uninitialised.
		/// </param>
		/// <returns><see langword="true"/> if a <see cref="GameObject"/> with the specified name was found; otherwise, <see langword="false"/>.</returns>
		/// <seealso cref="GetGameObject"/>
		public bool TryGetGameObject(string name, out GameObject gameObject) {
			Contract.RequiresNotNull(name, nameof(name));

			return this.nameDictionary.TryGetValue(name, out gameObject);
		}

		/// <summary>
		/// Gets the name that is currently assigned to the specified <see cref="GameObject"/>.
		/// </summary>
		/// <param name="gameObject">The <see cref="GameObject"/> that is currently assigned a name.</param>
		/// <returns>The name that is currently assigned to the specified <see cref="GameObject"/>.</returns>
		public string GetName(GameObject gameObject) {
			Contract.RequiresNotNull(gameObject, nameof(gameObject));

			return this.nameDictionary.Single(kvp => kvp.Value == gameObject).Key;
		}

		/// <summary>
		/// Gets the name that is currently assigned to the specified <see cref="GameObject"/>.
		/// </summary>
		/// <param name="gameObject">The <see cref="GameObject"/> that is currently assigned a name.</param>
		/// <param name="name">
		/// When this method returns, contains the name that is currently assigned to the specified <see cref="GameObject"/>,
		/// if one exists; otherwise, <see langword="null"/>. This parameter is passed uninitialised.
		/// </param>
		/// <returns><see langword="true"/> if a name assigned to the specified <see cref="GameObject"/> was found; otherwise, <see langword="false"/>.</returns>
		public bool TryGetName(GameObject gameObject, out string name) {
			Contract.RequiresNotNull(gameObject, nameof(gameObject));

			foreach (var kvp in this.nameDictionary) {
				if (kvp.Value == gameObject) {
					name = kvp.Key;
					return true;
				}
			}

			name = null;
			return false;
		}

		/// <summary>
		/// Assigns a name to the specified <see cref="GameObject"/>.
		/// </summary>
		/// <param name="gameObject">The <see cref="GameObject"/> whose name should be assigned.</param>
		/// <param name="name">The name to assign to the <see cref="GameObject"/>.</param>
		public void SetName(GameObject gameObject, string name) {
			Contract.RequiresNotNull(gameObject, nameof(gameObject));
			Contract.RequiresNotNull(name, nameof(name));

			// Check for an existing name for the game object.
			string oldName;
			if (this.TryGetName(gameObject, out oldName)) {
				// If the old name is the same as the new name, there's nothing more to do.
				if (oldName == name) return;

				// If the game object already has a different name, remove the old name.
				this.RemoveName(oldName);
			}

			this.nameDictionary[name] = gameObject;
			this.OnChanged();
		}

		/// <summary>
		/// Removes the named access to the specified <see cref="GameObject"/>.
		/// </summary>
		/// <param name="gameObject">The <see cref="GameObject"/> whose named access should be removed.</param>
		/// <returns><see langword="true"/> if the named access was removed; otherwise, <see langword="false"/>.</returns>
		public bool RemoveName(GameObject gameObject) {
			Contract.RequiresNotNull(gameObject, nameof(gameObject));

			string name;
			if (!this.TryGetName(gameObject, out name)) return false;
			return this.RemoveName(name);
		}

		/// <summary>
		/// Removes the specified named access.
		/// </summary>
		/// <param name="name">The named access to be removed.</param>
		/// <returns><see langword="true"/> if the named access was removed; otherwise, <see langword="false"/>.</returns>
		public bool RemoveName(string name) {
			Contract.RequiresNotNull(name, nameof(name));

			return this.nameDictionary.Remove(name);
		}
		#endregion

		#region Indexer.
		/// <summary>
		/// Gets the pool that handles instances of the source object with the specified name.
		/// The manager must contain a matching pool to use this method.
		/// </summary>
		/// <param name="name">The name of the game object to retrieve the pool for.</param>
		/// <returns>A <see cref="GameObjectPool"/> that handles instances of <paramref name="name"/>.</returns>
		public GameObjectPool this[string name] {
			get {
				Contract.RequiresNotNull(name, nameof(name));
				this.EnsureManager();
				return this.GetPool(name);
			}
		}
		#endregion

		#region Private methods.
		private GameObject Locate(string name) {
			GameObject go;
			if (this.TryLocate(name, out go)) return go;
			
			return null;
		}

		private bool TryLocate(string name, out GameObject go) {
			if (this.TryGetGameObject(name, out go)) return true;

			if (this.UseResources) {
				go = Resources.Load<GameObject>(name);
				return go != null;
			}

			return false;
		}

		/// <summary>
		/// Ensures the <see cref="Manager"/> property has been set.
		/// </summary>
		/// <exception cref="InvalidOperationException">When the <see cref="Manager"/> property has not been set.</exception>
		private void EnsureManager() {
			if (this.Manager == null) throw new InvalidOperationException($"The {nameof(this.Manager)} property must be set to a valid {nameof(GameObjectPoolManager)} reference.");
		}

		private void ManagerOnPoolAttached(object sender, PoolEventArgs<GameObjectPool> e) {
			if (this.AutoAddFromManager) {
				GameObject sourceObject = e.Pool?.Source;

				if (sourceObject != null) {
					this.SetName(sourceObject, sourceObject.name);
				}
			}
		}
		#endregion

		#region ISerializationCallbackReceiver implementation.
		/// <inheritdoc />
		void ISerializationCallbackReceiver.OnBeforeSerialize() {
			// Do nothing.
		}

		/// <inheritdoc />
		void ISerializationCallbackReceiver.OnAfterDeserialize() {
			// Restore the event handlers that aren't able to be serialised.
			if (this.AutoAddFromManager && this.Manager != null) {
				// Listen for newly-attached pools, to automatically map their source object's name to the pool.
				this.Manager.PoolAttached += this.ManagerOnPoolAttached;
				this.eventHandlerAttached = true;
			}
		}
		#endregion

		#region Event raisers.
		/// <summary>
		/// Raises the <see cref="Changed"/> event.
		/// </summary>
		protected virtual void OnChanged() {
			this.Changed?.Invoke(this, EventArgs.Empty);
		}
		#endregion

		#region Static access.
		private static NamedGameObjectPoolManager instance;
		
		/// <summary>
		/// Gets the <see cref="NamedGameObjectPoolManager"/> found in the scene.
		/// </summary>
		/// <remarks>
		/// <para>
		/// If more than one <see cref="NamedGameObjectPoolManager"/> exists in the scene, the instance returned by this property is undefined.
		/// </para>
		/// <para>
		/// If no <see cref="NamedGameObjectPoolManager"/> is found in the scene, a new root <see cref="GameObject"/> is
		/// created with the <see cref="NamedGameObjectPoolManager"/> component attached.
		/// </para>
		/// </remarks>
		public static NamedGameObjectPoolManager Instance {
			get {
				if (NamedGameObjectPoolManager.instance != null) return NamedGameObjectPoolManager.instance;

				// Look for the manager in the scene.
				NamedGameObjectPoolManager.instance = UnityEngine.Object.FindObjectOfType<NamedGameObjectPoolManager>();
				if (NamedGameObjectPoolManager.instance == null) {
					// Create a new manager.
					var container = new GameObject(nameof(NamedGameObjectPoolManager));
					NamedGameObjectPoolManager.instance = container.AddComponent<NamedGameObjectPoolManager>();
				}

				// If the named manager has no normal manager assigned, look for it in the scene or create a new one.
				if (NamedGameObjectPoolManager.instance.Manager == null) {
					NamedGameObjectPoolManager.instance.Manager = GameObjectPoolManager.Instance;
				}

				return NamedGameObjectPoolManager.instance;
			}
		}
		#endregion

	}

}