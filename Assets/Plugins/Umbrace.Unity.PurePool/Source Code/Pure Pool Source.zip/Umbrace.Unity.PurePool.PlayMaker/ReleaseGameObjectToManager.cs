﻿using HutongGames.PlayMaker;

using UnityEngine;

using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Releases an instance of a GameObject to its pool using a pool manager.")]
	public class ReleaseGameObjectToManager : FsmStateAction {

		[ObjectType(typeof(GameObjectPoolManager))]
		[Tooltip("The optional pool manager to which the instance of a GameObject should be released. If undefined, the first GameObjectPoolManager found in the scene is used.")]
		public FsmObject PoolManager;

		[RequiredField]
		[Tooltip("The instance that is being returned to the pool.")]
		public FsmOwnerDefault Instance;

		public override void OnEnter() {
			GameObjectPoolManager manager;
			GameObject instance;

			if (this.PoolManager.IsNone || this.PoolManager.Value == null) {
				manager = GameObjectPoolManager.Instance;
			} else {
				manager = (GameObjectPoolManager)this.PoolManager.Value;
			}

			if (manager == null) {
				this.LogWarning($"{nameof(this.PoolManager)} not set and no {nameof(GameObjectPoolManager)} could be found in the scene.");
			} else if ((instance = Fsm.GetOwnerDefaultTarget(this.Instance)) == null) {
				this.LogWarning($"{nameof(this.Instance)} not set or set to null.");
			} else {
				manager.Release(instance);
			}

			this.Finish();
		}

		public override void Reset() {
			this.PoolManager = null;
			this.Instance = null;
		}

	}

}