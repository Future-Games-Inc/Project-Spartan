﻿using HutongGames.PlayMaker;

using UnityEngine;

using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Acquires an instance of a GameObject from a GameObject pool manager.")]
	public class AcquireGameObjectFromManager : FsmStateAction {

		[ObjectType(typeof(GameObjectPoolManager))]
		[Tooltip("The optional pool manager from which to acquire an instance of a GameObject. If undefined, the first GameObjectPoolManager found in the scene is used.")]
		public FsmObject PoolManager;

		[RequiredField]
		[Tooltip("The GameObject prefab that should be acquired from the pool.")]
		public FsmOwnerDefault Prefab;

		[Tooltip("The optional parent transform that the acquired instance should be parented to.")]
		public FsmOwnerDefault Parent;

		[Tooltip("The optional position at which to place the acquired instance. If Parent is defined, this is used as a local offset from the Parent position.")]
		public FsmVector3 Position;

		[Tooltip("The optional rotation at which to place the acquired instance. NOTE: Overrides the rotation of the Parent.")]
		public FsmVector3 Rotation;

		[UIHint(UIHint.Variable)]
		[Tooltip("The instance that was acquired from the pool.")]
		public FsmGameObject Instance;

		public override void OnEnter() {
			GameObjectPoolManager manager;
			GameObject prefab;

			if (this.PoolManager.IsNone || this.PoolManager.Value == null) {
				manager = GameObjectPoolManager.Instance;
			} else {
				manager = (GameObjectPoolManager)this.PoolManager.Value;
			}

			if (manager == null) {
				this.LogWarning($"{nameof(this.PoolManager)} not set and no {nameof(GameObjectPoolManager)} could be found in the scene.");
			} else if ((prefab = Fsm.GetOwnerDefaultTarget(this.Prefab)) == null) {
				this.LogWarning($"{nameof(this.Prefab)} not set or set to null.");
			} else {
				GameObject parent;
				Transform parentTransform = null;
				var position = Vector3.zero;
				var rotation = Vector3.zero;

				if ((parent = Fsm.GetOwnerDefaultTarget(this.Parent)) != null) {
					parentTransform = parent.transform;
					position = parentTransform.position;

					if (!this.Position.IsNone) {
						position += this.Position.Value;
					}

					rotation = !this.Rotation.IsNone ? this.Rotation.Value : parentTransform.eulerAngles;
				} else {
					if (!this.Position.IsNone) {
						position = this.Position.Value;
					}

					if (!this.Rotation.IsNone) {
						rotation = this.Rotation.Value;
					}
				}

				GameObject go;
				if (manager.TryAcquire(prefab, position, Quaternion.Euler(rotation), parentTransform, out go)) {
					if (!this.Instance.IsNone) {
						this.Instance.Value = go;
					}
				} else {
					this.LogWarning($"Failed to acquire from pool manager, check the {nameof(GameObjectPoolManager.AcquireMode)} property or ensure a pool exists.");
				}
			}

			this.Finish();
		}

		public override void Reset() {
			this.PoolManager = null;
			this.Prefab = null;
			this.Parent = null;
			this.Position = null;
			this.Rotation = null;
			this.Instance = null;
		}

	}

}