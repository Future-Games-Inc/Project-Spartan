﻿using HutongGames.PlayMaker;

using UnityEngine;

using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Releases an array of GameObject instances to their pools using a pool manager.")]
	public class ReleaseGameObjectsToManager : FsmStateAction {

		[ObjectType(typeof(GameObjectPoolManager))]
		[Tooltip("The optional pool manager to which the array of GameObject instances should be released. If undefined, the first GameObjectPoolManager found in the scene is used.")]
		public FsmObject PoolManager;

		[RequiredField]
		[UIHint(UIHint.Variable)]
		[ArrayEditor(VariableType.GameObject)]
		[Tooltip("The instances that are being returned to their pools.")]
		public FsmArray Instances;

		public override void OnEnter() {
			GameObjectPoolManager manager;

			if (this.PoolManager.IsNone || this.PoolManager.Value == null) {
				manager = GameObjectPoolManager.Instance;
			} else {
				manager = (GameObjectPoolManager)this.PoolManager.Value;
			}

			if (manager == null) {
				this.LogWarning($"PoolManager not set and no GameObjectPoolManager could be found in the scene.");
			} else if (this.Instances.IsNone || this.Instances.Values == null) {
				this.LogWarning($"Instances array variable not set or set to null.");
			} else {
				for (int i = 0; i < this.Instances.Length; i++) {
					manager.Release((GameObject)this.Instances.Values[i]);
				}
			}

			this.Finish();
		}

		public override void Reset() {
			this.PoolManager = null;
			this.Instances = null;
		}

	}

}