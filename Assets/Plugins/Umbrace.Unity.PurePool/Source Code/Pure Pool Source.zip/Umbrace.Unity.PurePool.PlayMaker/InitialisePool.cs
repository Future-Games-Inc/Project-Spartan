﻿using HutongGames.PlayMaker;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Initialises a GameObject pool.")]
	public class InitialisePool : FsmStateAction {

		[RequiredField]
		[UIHint(UIHint.Variable)]
		[ObjectType(typeof(IPoolBase))]
		[Tooltip("The pool to initialise.")]
		public FsmObject Pool;
		
		public override void OnEnter() {
			if (!this.Pool.IsNone && this.Pool.Value != null) {
				var pool = (IPoolBase)this.Pool.Value;

				if (!pool.IsInitialised) {
					pool.Initialise();
				} else {
					this.LogWarning("The pool has already been initialised, and cannot be initialised again.");
				}
			}

			this.Finish();
		}

		public override void Reset() {
			this.Pool = new FsmObject { UseVariable = true };
		}

	}

}