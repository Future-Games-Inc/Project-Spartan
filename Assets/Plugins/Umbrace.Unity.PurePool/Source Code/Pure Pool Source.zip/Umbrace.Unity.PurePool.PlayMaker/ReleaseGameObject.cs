﻿using HutongGames.PlayMaker;

using UnityEngine;

using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace Umbrace.Unity.PurePool.PlayMaker {

	[ActionCategory("Pooling")]
	[Tooltip("Releases an instance of a GameObject to its pool.")]
	public class ReleaseGameObject : FsmStateAction {

		[RequiredField]
		[ObjectType(typeof(GameObjectPool))]
		[Tooltip("The pool to which an instance of a GameObject should be released.")]
		public FsmObject Pool;

		[RequiredField]
		[Tooltip("The instance that is being returned to the pool.")]
		public FsmOwnerDefault Instance;

		public override void OnEnter() {
			GameObject instance;

			if (!this.Pool.IsNone && this.Pool.Value != null && (instance = Fsm.GetOwnerDefaultTarget(this.Instance)) != null) {
				var pool = (GameObjectPool)this.Pool.Value;

				if (pool.IsInitialised) {
					pool.Release(instance);
				} else {
					this.LogError("The pool must be initialised before an object can be released to it.");
				}
			}

			this.Finish();
		}

		public override void Reset() {
			this.Pool = null;
			this.Instance = null;
		}

	}

}