﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Mirror {

	// Handles requests to spawn game objects on the client
	public delegate GameObject SpawnDelegate(Vector3 position, System.Guid assetId);

	// Handles requests to unspawn game objects on the client
	public delegate void UnSpawnDelegate(GameObject spawned);

	public static class ClientScene {

		public static Dictionary<Guid, GameObject> prefabs { get; }

		public static void UnregisterPrefab(GameObject prefab) { }

		public static void RegisterPrefab(GameObject prefab, SpawnDelegate spawn, UnSpawnDelegate unspawn) { }

		public static void RegisterSpawnHandler(Guid prefabId, SpawnDelegate spawn, UnSpawnDelegate unspawn) { }

	}

}