﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Mirror {

	public class NetworkIdentity : MonoBehaviour {

		public Guid assetId { get; }

	}

}