﻿using System;

using UnityEngine;

namespace Bolt {

	public class GlobalEventListener {

		public virtual void BoltStartDone() {

		}

	}

	public interface IPrefabPool {

		/// <summary>
		/// This is called when Bolt wants to destroy the instance of an entity prefab.
		/// </summary>
		/// <param name="gameObject">The instance to destroy</param>
		void Destroy(GameObject gameObject);

		/// <summary>
		/// This is called when bolt wants to create a new instance of an entity prefab.
		/// </summary>
		/// <param name="prefabId">The id of this prefab</param>
		/// <param name="position">The position we want the instance instantiated at</param>
		/// <param name="rotation">	The rotation we want the instance to take</param>
		/// <returns>The newly instantiate object, or null if a prefab with <paramref name="prefabId"/> was not found</returns>
		GameObject Instantiate(PrefabId prefabId, Vector3 position, Quaternion rotation);

		/// <summary>
		/// Called by Bolt to inspect a prefab before instantiating it.The object returned from this method can be the prefab itself, it does not have to be a unique instance.
		/// </summary>
		/// <param name="prefabId">The id of the prefab we are looking for</param>
		/// <returns>A game object representing the prefab or an instance of the prefab</returns>
		GameObject LoadPrefab(PrefabId prefabId);

	}

	public static class BoltNetwork {

		public static void SetPrefabPool(IPrefabPool pool) {

		}

	}

	public class BoltEntity : MonoBehaviour {
	}

	public struct PrefabId {

		public int Value { get; }

	}

	public static class PrefabDatabase {

		public static GameObject Find(PrefabId prefabId) {
			throw new NotImplementedException();
		}

	}

}