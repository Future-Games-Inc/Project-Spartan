﻿using System;
using System.Collections.Generic;

using Bolt;

using Umbrace.Unity.PurePool;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Photon {
	
	using PoolManagerBase = PoolManagerBase<GameObjectPoolManagerSettings,GameObjectPool,GameObjectPoolSettings,GameObject,GameObject>;

	/// <summary>
	/// A bridge class to allow object pooling to be used by Photon Bolt.
	/// </summary>
	/// <remarks>
	/// <para>
	/// To use this class for pooling with Photon Bolt, instantiate a new instance of it, set the <see cref="Manager"/> property, and pass the instance as a parameter to <c>BoltNetwork.SetPrefabPool</c>.
	/// </para>
	/// </remarks>
	[Serializable]
	public class PrefabPool : IPrefabPool {

		[SerializeField, HideInInspector]
		private GameObjectPoolManager manager;
		
		/// <summary>
		/// Gets or sets the pool manager to be used by Photon.
		/// </summary>
		/// <remarks>
		/// The <see cref="GameObjectPoolManager"/> assigned to this property must meet the following requirements:
		/// <list type="bullet">
		/// <item><description>The <see cref="PoolManagerBase.AcquireMode"/> property must be set to <see cref="AcquireNoPoolMode.Instantiate"/> or <see cref="AcquireNoPoolMode.CreatePool"/>.</description></item>
		/// <item><description>In the case of <see cref="AcquireNoPoolMode.CreatePool"/>, the <see cref="SharedPoolSettings{TSource}.InstantiateWhenEmpty"/> property of <see cref="PoolManagerBase.DefaultPoolSettings"/> must be set to true.</description></item>
		/// </list>
		/// </remarks>
		public GameObjectPoolManager Manager {
			get { return this.manager; }
			set {
				if (value == null) throw new ArgumentNullException();

				// Ensure an instance can always be acquired, even when no pool exists.
				if (value.AcquireMode == AcquireNoPoolMode.Error) throw new ArgumentException("The manager must be set to an AcquireMode that always allows instantiation. Set AcquireMode to CreatePool or Instantiate.");
				if (value.AcquireMode == AcquireNoPoolMode.CreatePool && !value.DefaultPoolSettings.InstantiateWhenEmpty) {
					throw new ArgumentException("The manager must be set to always allow instantiation." +
												"When using an AcquireMode of CreatePool, set DefaultPoolSettings.InstantiateWhenEmpty to true.");
				}

				this.manager = value;
			}
		}

		/// <inheritdoc />
		public void Destroy(GameObject gameObject) {
			this.manager.Release(gameObject);
		}

		/// <inheritdoc />
		public GameObject Instantiate(PrefabId prefabId, Vector3 position, Quaternion rotation) {
			GameObject instance;

			// Check the PrefabDatabase for the prefab with this identifier.
			GameObject prefab = this.LoadPrefab(prefabId);
			if (prefab != null) {
				if (this.manager.TryAcquire(prefab, position, rotation, out instance)) {
					BoltEntity boltEntityComponent = instance.GetComponent<BoltEntity>();
					if (boltEntityComponent != null) {
						boltEntityComponent.enabled = true;
					}

					return instance;
				}

				// This should never occur, as an instance should always be available.
				DebugHelper.LogError("Failed to instantiate prefab " + prefabId.Value + " \"" + prefabId + "\". PrefabDatabase knows the prefab, but the manager failed to acquire an instance of it.");
				return null;
			}

			// No instance could be acquired. This should only occur if the prefab ID is not valid (no matching prefab in the PrefabDatabase).
			DebugHelper.LogWarning("Failed to instantiate prefab with ID " + prefabId + ". No asset with this ID was found in PrefabDatabase.");
			return null;
		}

		/// <inheritdoc />
		public GameObject LoadPrefab(PrefabId prefabId) {
			return PrefabDatabase.Find(prefabId);
		}

	}

}