﻿using Bolt;

using Umbrace.Unity.PurePool;

using UnityEngine;

namespace Umbrace.Unity.PurePool.Photon {

	/// <summary>
	/// A component that will automatically set up the bridge between Photon Bolt and Pure Pool.
	/// </summary>
	// Optional attribute. Uncomment if you want Bolt to automatically find this class and create an instance of it.
	// When uncommented, you don't need to add this component to a GameObject in your scene - Bolt will take care of this for you.
	// When commented out, you should add the component to a GameObject in your scene, either directly in the Editor or through a script.
	//[BoltGlobalBehaviour]
	public class BoltPoolingSetup : GlobalEventListener {

		[SerializeField, HideInInspector]
		private PrefabPool boltPrefabPool;
		
		private void Start() {
			// Create the PrefabPool object, which is the bridge between Bolt and Pure Pool.
			this.boltPrefabPool = new PrefabPool();

			// Assign the manager, so it knows how to acquire and release from the pools.
			this.boltPrefabPool.Manager = GameObjectPoolManager.Instance;
		}

		public override void BoltStartDone() {
			// Set Bolt to use the PrefabPool object.
			BoltNetwork.SetPrefabPool(this.boltPrefabPool);
		}

	}

}