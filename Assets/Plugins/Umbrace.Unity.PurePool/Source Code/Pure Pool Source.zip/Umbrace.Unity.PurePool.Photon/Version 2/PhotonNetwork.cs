﻿using System;
using System.Collections.Generic;

using UnityEngine;
// ReSharper disable All

namespace Photon.Pun {

	/// <summary>
	/// <para>This is a non-functional template class. DO NOT USE.</para>
	/// <para>
	/// The main class to use the PhotonNetwork plugin.
	/// This class is static.
	/// </para>
	/// </summary>
	public static class PhotonNetwork {

		/// <summary>
		/// An Object Pool can be used to keep and reuse instantiated object instances. It replaced Unity's default Instantiate and Destroy methods.
		/// </summary>
		/// <remarks>
		/// To use a GameObject pool, implement IPunPrefabPool and assign it here.
		/// Prefabs are identified by name.
		/// </remarks>
		public static IPunPrefabPool PrefabPool {
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

	}


}