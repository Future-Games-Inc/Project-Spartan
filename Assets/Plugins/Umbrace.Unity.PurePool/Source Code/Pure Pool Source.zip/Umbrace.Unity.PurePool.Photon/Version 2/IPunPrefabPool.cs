﻿using UnityEngine;

namespace Photon.Pun {

	/// <summary>
	/// Defines an interface for object pooling, used in PhotonNetwork.Instantiate and PhotonNetwork.Destroy.
	/// </summary>
	/// <remarks>
	/// To apply your custom IPunPrefabPool, set PhotonNetwork.PrefabPool.
	/// 
	/// The pool has to return a valid, disabled GameObject when PUN calls Instantiate.Also, the position and rotation must be applied.
	/// 
	/// Note that Awake and Start are only called once by Unity, so scripts on re-used GameObjects should make use of OnEnable and or
	/// OnDisable.When OnEnable gets called, the PhotonView is already updated to the new values.
	/// 
	/// To be able to enable a GameObject, Instantiate must return an inactive object.
	/// 
	/// Before PUN "destroys" GameObjects, it will disable them.
	/// 
	/// If a component implements IPunInstantiateMagicCallback, PUN will call OnPhotonInstantiate when the networked object gets instantiated.
	/// If no components implement this on a prefab, PUN will optimize the instantiation and no longer looks up IPunInstantiateMagicCallback via GetComponents.
	/// </remarks>
	public interface IPunPrefabPool {

		/// <summary>
		/// Called to get an instance of a prefab. Must return valid, disabled GameObject with PhotonView.
		/// </summary>
		/// <param name="prefabId">The id of this prefab.</param>
		/// <param name="position">The position for the instance.</param>
		/// <param name="rotation">The rotation for the instance.</param>
		/// <returns>A disabled instance to use by PUN or <see langword="null"/> if the prefabId is unknown.</returns>
		GameObject Instantiate(string prefabId, Vector3 position, Quaternion rotation);

		/// <summary>
		/// Called to destroy (or just return) the instance of a prefab. It's disabled and the pool may reset and cache it for later use in Instantiate.
		/// </summary>
		/// <remarks>
		/// A pool needs some way to find out which type of GameObject got returned via Destroy().
		/// It could be a tag, name, a component or anything similar. 
		/// </remarks>
		/// <param name="gameObject">The instance to destroy.</param>
		void Destroy(GameObject gameObject);

	}

}